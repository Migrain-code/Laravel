<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>hst.world | Admin</title>
    <!--favicon-->
    <link rel="icon" href="<?php echo e(asset(config('settings.favicon'))); ?>" type="image/x-icon">
    <!-- Bootstrap core CSS-->
    <link href="/backend/css/bootstrap.min.css" rel="stylesheet" />
    <!-- animate CSS-->
    <link href="/backend/css/animate.css" rel="stylesheet" type="text/css" />
    <!-- Icons CSS-->
    <link href="/backend/css/icons.css" rel="stylesheet" type="text/css" />
    <!-- Custom Style-->
    <link href="/backend/css/app-style.css" rel="stylesheet" />

</head>

<body class="bg-dark">
<!-- Start wrapper-->
<div id="wrapper">
    <div class="card card-authentication1 mx-auto my-5">
        <div class="card-body">
            <div class="card-content p-2">
                <div class="text-center">
                    <img src="<?php echo e(asset(config('settings.logo'))); ?>" alt="logo icon">
                </div>
                <div class="card-title text-uppercase text-center py-3"> HST.WORLD</div>
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="exampleInputUsername" class="">E-Posta Adresi</label>
                        <div class="position-relative has-icon-right">
                            <input type="text" id="exampleInputUsername" class="form-control input-shadow" name="email" required value="<?php echo e(old('email')); ?>" placeholder="E-Posta Adresi">
                            <div class="form-control-position">
                                <i class="icon-user"></i>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword" class="">Parola</label>
                        <div class="position-relative has-icon-right">
                            <input type="password" id="exampleInputPassword" class="form-control input-shadow" name="password" required placeholder="Parolanızı Girin">
                            <div class="form-control-position">
                                <i class="icon-lock"></i>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6">
                            <div class="icheck-material-primary">
                                <input type="checkbox" id="user-checkbox" name="remember" checked="" />
                                <label for="user-checkbox">Beni Hatırla</label>
                            </div>
                        </div>

                    </div>
                    <button type="submit" class="btn btn-primary shadow-primary btn-block waves-effect waves-light">Giriş Yap</button>

                </form>
            </div>
        </div>

    </div>

    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
</div>
<!--wrapper-->

<!-- Bootstrap core JavaScript-->
<script src="/backend/js/jquery.min.js"></script>
<script src="/backend/js/popper.min.js"></script>
<script src="/backend/js/bootstrap.min.js"></script>

</body>



</html>
<?php /**PATH /home/u0833636/public_html/project/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>