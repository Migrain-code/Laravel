<?php $__env->startSection('title','Girişimci Kayıt'); ?>
<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/register/fonts/themify-icons/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/register/css/style.css')); ?>">
    <script nonce="e0185510-375f-43e2-97e5-1d24617ef902">(function (w, d) {
            !function (a, e, t, r) {
                a.zarazData = a.zarazData || {};
                a.zarazData.executed = [];
                a.zaraz = {deferred: []};
                a.zaraz.q = [];
                a.zaraz._f = function (e) {
                    return function () {
                        var t = Array.prototype.slice.call(arguments);
                        a.zaraz.q.push({m: e, a: t})
                    }
                };
                for (const e of ["track", "set", "ecommerce", "debug"]) a.zaraz[e] = a.zaraz._f(e);
                a.zaraz.init = () => {
                    var t = e.getElementsByTagName(r)[0], z = e.createElement(r), n = e.getElementsByTagName("title")[0];
                    n && (a.zarazData.t = e.getElementsByTagName("title")[0].text);
                    a.zarazData.x = Math.random();
                    a.zarazData.w = a.screen.width;
                    a.zarazData.h = a.screen.height;
                    a.zarazData.j = a.innerHeight;
                    a.zarazData.e = a.innerWidth;
                    a.zarazData.l = a.location.href;
                    a.zarazData.r = e.referrer;
                    a.zarazData.k = a.screen.colorDepth;
                    a.zarazData.n = e.characterSet;
                    a.zarazData.o = (new Date).getTimezoneOffset();
                    a.zarazData.q = [];
                    for (; a.zaraz.q.length;) {
                        const e = a.zaraz.q.shift();
                        a.zarazData.q.push(e)
                    }
                    z.defer = !0;
                    for (const e of [localStorage, sessionStorage]) Object.keys(e || {}).filter((a => a.startsWith("_zaraz_"))).forEach((t => {
                        try {
                            a.zarazData["z_" + t.slice(7)] = JSON.parse(e.getItem(t))
                        } catch {
                            a.zarazData["z_" + t.slice(7)] = e.getItem(t)
                        }
                    }));
                    z.referrerPolicy = "origin";
                    z.src = "../../../cdn-cgi/zaraz/sd0d9.js?z=" + btoa(encodeURIComponent(JSON.stringify(a.zarazData)));
                    t.parentNode.insertBefore(z, t)
                };
                ["complete", "interactive"].includes(e.readyState) ? zaraz.init() : a.addEventListener("DOMContentLoaded", zaraz.init)
            }(w, d, 0, "script");
        })(window, document);</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main" style="background-color: #f1f6ff">
        <div class="container">
            <h2>Girişimci Kayıt</h2>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form method="POST" id="signup-form" class="signup-form">
                <?php echo csrf_field(); ?>
                <h3>
                    <span class="icon"><i class="ti-user"></i></span>
                    <span class="title_text">Kişisel</span>
                </h3>
                <fieldset>
                    <legend>
                        <span class="step-heading">Kişisel Bilgiler: </span>
                        <span class="step-number">Step 1 / 3</span>
                    </legend>
                    <div class="form-group">
                        <label for="name" class="form-label required">İsim</label>
                        <input type="text" name="name" id="name"/>
                    </div>
                    <div class="form-group">
                        <label for="surname" class="form-label required">Soyisim</label>
                        <input type="text" name="surname" id="surname"/>
                    </div>

                    <div class="form-group">
                        <label for="email" class="form-label required">E-Posta</label>
                        <input type="email" name="email" id="emailemail"/>
                    </div>

                    <div class="form-group">
                        <label for="user_name" class="form-label required">Telefon Numarası</label>
                        <input type="text" name="phone" id="user_name"/>
                    </div>

                    <div class="form-group">
                        <label for="password" class="form-label required">Şifre</label>
                        <input type="password" name="password" id="password"/>
                    </div>
                </fieldset>
                <h3>
                    <span class="icon"><i class="ti-star"></i></span>
                    <span class="title_text">Girişim</span>
                </h3>
                <fieldset>
                    <legend>
                        <span class="step-heading">Girişim Bilgileri: </span>
                        <span class="step-number">Step 2 / 3</span>
                    </legend>
                    <div class="form-group">
                        <label for="employee_id" class="form-label required">Girişim Adı</label>
                        <input type="text" name="enterprise[name]" id="employee_id"/>
                    </div>
                    <div class="form-group">
                        <label for="designation" class="form-label required">Web Adresi</label>
                        <input type="text" name="enterprise[website]" id="designation"/>
                    </div>
                    <div class="form-group">
                        <label for="department" class="form-label required">Girşimin kısaca tanımı</label>
                        <textarea type="text" name="enterprise[short_detail]" id="department" cols="60" rows="10" style="width: 100%"></textarea>
                    </div>
                    <div class="form-select" >
                        <label for="purpose" class="form-label" style="text-align: left">Girişimin Yapım Amacı</label>
                        <div class="select-list">
                            <select name="enterprise[purpose][]" multiple id="purpose">
                                <option value="Fikir">Fikir</option>
                                <option value="Prototip">Prototip</option>
                                <option value="Kullanılabilir">Kullanılabilir</option>
                                <option value="Kullanılıyor">Kullanılıyor</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-date">
                            <label for="birth_date" class="form-label">Projeye Ne Zaman Başladınız</label>
                            <div class="form-date-group">
                                <div class="form-date-item">
                                    <select id="enterprise[date_month]" name="enterprise[start_month]">
                                        <option value="01">01</option>
                                        <option value="02">02</option>
                                        <option value="03">03</option>
                                        <option value="04">04</option>
                                        <option value="05">05</option>
                                        <option value="06">06</option>
                                        <option value="07">07</option>
                                        <option value="08">08</option>
                                        <option value="09">09</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                    </select>
                                    <span class="select-icon"><i class="ti-angle-down"></i></span>
                                </div>
                                <div class="form-date-item">
                                    <select id="enterprise[date_year]" name="enterprise[start_year]">
                                        <?php for($i=now()->year-20;$i<=now()->year;$i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <span class="select-icon"><i class="ti-angle-down"></i></span>
                                </div>
                            </div>
                    </div>
                    <div class="form-group">
                        <label for="degree" class="form-label required">Girişimdeki Ünvanınız</label>
                        <input type="text" name="enterprise[degree]" id="degree"/>
                    </div>
                    <div class="form-select" >
                        <label for="mission" class="form-label" style="text-align: left">Girişimdeki Göreviniz</label>
                        <div class="select-list">
                            <select name="enterprise[mission][]" multiple id="mission">
                                <option value="Kurucu">Kurucu</option>
                                <option value="Kurucu Ortağı">Kurucu Ortağı</option>
                                <option value="Çalışan">Çalışan</option>
                            </select>
                        </div>
                    </div>
                </fieldset>
                <h3>
                    <span class="icon"><i class="ti-info-alt"></i></span>
                    <span class="title_text">Bilgiler</span>
                </h3>
                <fieldset>
                    <legend>
                        <span class="step-heading">Bilgiler: </span>
                        <span class="step-number">Step 3 / 3</span>
                    </legend>
                    <div class="form-group">
                        <label for="biography" class="form-label required">KISA BİYOGRAFİ/ KENDİNİZİ TANITINIZ </label>
                        <textarea type="text" name="enterprise[biography]" id="biography" cols="60" rows="10" style="width: 100%;resize: none"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="detail" class="form-label required">GİRİŞİM HAKKINDA ÖZET BİLGİ VERİNİZ </label>
                        <textarea type="text" name="enterprise[detail]" id="detail" cols="60" rows="10" style="width: 100%;resize: none"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="detail" class="form-label required">NEDEN BAŞVURMAK İSTİYORSUNUZ ?</label>
                        <textarea type="text" name="enterprise[cause]" id="detail" cols="60" rows="10" style="width: 100%;resize: none"></textarea>
                    </div>

                </fieldset>
            </form>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/register/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/jquery-steps/jquery.steps.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/minimalist-picker/dobpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/js/main.js')); ?>"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194"
            integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw=="
            data-cf-beacon='{"rayId":"72d3315a3e725184","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2022.6.0","si":100}'
            crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istanbulyazilim/public_html/girisimphp/resources/views/promoter/auth/register.blade.php ENDPATH**/ ?>