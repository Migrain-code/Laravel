<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
<footer class="footer position-fixed">
    <div class="container">
        <div class="text-center">
            Copyright © 2022 <a href="https://istanbulyazilim.net/" target="_blank">İstanbul Yazılım</a>
        </div>
    </div>
</footer>
<!--End footer-->

<?php /**PATH D:\xampp\htdocs\girisim\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>