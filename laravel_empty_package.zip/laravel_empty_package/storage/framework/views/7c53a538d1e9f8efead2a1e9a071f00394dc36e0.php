<?php $__env->startSection('title','Kayıt Ol'); ?>
<?php $__env->startSection('links'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="site-content">
        <div data-elementor-type="wp-page" data-elementor-id="20125" class="elementor elementor-20125">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-a70c7ba elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="a70c7ba" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div
                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a80a4f6"
                        data-id="a80a4f6" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                                class="elementor-element elementor-element-e96d807 elementor-widget elementor-widget-radiant-custom-heading"
                                data-id="e96d807" data-element_type="widget"
                                data-widget_type="radiant-custom-heading.default">
                                <div class="elementor-widget-container">
                                    <div class="rt-hover-heading ">
                                        <h1 class="rt-title-heading">Kayıt Ol</h1>

                                    </div>
                                </div>
                            </div>
                            <div
                                class="elementor-element elementor-element-f353703 elementor-widget elementor-widget-text-editor"
                                data-id="f353703" data-element_type="widget" data-widget_type="text-editor.default">
                                <div class="elementor-widget-container">
                                    Kayıt olmak istediğiniz Yönteme Tıklayın
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-73d0c2e2 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                data-id="73d0c2e2" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div
                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5fe5a95f"
                        data-id="5fe5a95f" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-7a735bdc elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="7a735bdc" data-element_type="section">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div
                                        class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-61b46994"
                                        data-id="61b46994" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div
                                                class="elementor-element elementor-element-5a887af9 elementor-widget elementor-widget-radiant-portfolio"
                                                data-id="5a887af9" data-element_type="widget"
                                                data-settings="{&quot;_animation&quot;:&quot;none&quot;}"
                                                data-widget_type="radiant-portfolio.default">
                                                <div class="elementor-widget-container"></div>
                                                    <div class="rt-portfolio-box element-six row">
                                                       
                                                        <div class="col-lg-6">
                                                             <a class="radiantthemes-menu-custom-button-main" style="border-radius:15px;padding:10px;background-color: #0d66c2;color:white" href="<?php echo e(route('promoter.register')); ?>"><span>Girişimci Kayıt</span></a>
                                                        </div>
                                                        <div class="col-lg-6">
                                                           <a class="radiantthemes-menu-custom-button-main" style="border-radius:15px;padding:10px;background-color: #0d66c2;color:white" href="<?php echo e(route('investor.register')); ?>"><span>Yatırımcı Kayıt</span></a>
                                                        </div>
                                                        <div class="col-lg-12 mt-5" style="">
                                                            <img class="img-fluid" src="<?php echo e(asset('assets/wp-content/uploads/2022/02/blog-2-1.jpg')); ?>"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0833636/public_html/project/resources/views/register.blade.php ENDPATH**/ ?>