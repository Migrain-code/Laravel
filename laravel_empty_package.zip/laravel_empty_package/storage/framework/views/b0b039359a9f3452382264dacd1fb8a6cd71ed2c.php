<?php $__env->startSection('title','Girişimci Kayıt'); ?>
<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/register/fonts/themify-icons/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/register/css/style.css')); ?>">
    <script nonce="e0185510-375f-43e2-97e5-1d24617ef902">(function (w, d) {
            !function (a, e, t, r) {
                a.zarazData = a.zarazData || {};
                a.zarazData.executed = [];
                a.zaraz = {deferred: []};
                a.zaraz.q = [];
                a.zaraz._f = function (e) {
                    return function () {
                        var t = Array.prototype.slice.call(arguments);
                        a.zaraz.q.push({m: e, a: t})
                    }
                };
                for (const e of ["track", "set", "ecommerce", "debug"]) a.zaraz[e] = a.zaraz._f(e);
                a.zaraz.init = () => {
                    var t = e.getElementsByTagName(r)[0], z = e.createElement(r), n = e.getElementsByTagName("title")[0];
                    n && (a.zarazData.t = e.getElementsByTagName("title")[0].text);
                    a.zarazData.x = Math.random();
                    a.zarazData.w = a.screen.width;
                    a.zarazData.h = a.screen.height;
                    a.zarazData.j = a.innerHeight;
                    a.zarazData.e = a.innerWidth;
                    a.zarazData.l = a.location.href;
                    a.zarazData.r = e.referrer;
                    a.zarazData.k = a.screen.colorDepth;
                    a.zarazData.n = e.characterSet;
                    a.zarazData.o = (new Date).getTimezoneOffset();
                    a.zarazData.q = [];
                    for (; a.zaraz.q.length;) {
                        const e = a.zaraz.q.shift();
                        a.zarazData.q.push(e)
                    }
                    z.defer = !0;
                    for (const e of [localStorage, sessionStorage]) Object.keys(e || {}).filter((a => a.startsWith("_zaraz_"))).forEach((t => {
                        try {
                            a.zarazData["z_" + t.slice(7)] = JSON.parse(e.getItem(t))
                        } catch {
                            a.zarazData["z_" + t.slice(7)] = e.getItem(t)
                        }
                    }));
                    z.referrerPolicy = "origin";
                    z.src = "../../../cdn-cgi/zaraz/sd0d9.js?z=" + btoa(encodeURIComponent(JSON.stringify(a.zarazData)));
                    t.parentNode.insertBefore(z, t)
                };
                ["complete", "interactive"].includes(e.readyState) ? zaraz.init() : a.addEventListener("DOMContentLoaded", zaraz.init)
            }(w, d, 0, "script");
        })(window, document);</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main" style="background-color: #f1f6ff">
        <div class="container">
            <h2>Yatırımcı Kayıt</h2>
            <form method="POST" id="signup-form" class="signup-form">
                <h3>
                    <span class="icon"><i class="ti-user"></i></span>
                    <span class="title_text">Kişisel</span>
                </h3>
                <fieldset>
                    <legend>
                        <span class="step-heading">Kişisel Bilgiler: </span>

                    </legend>
                    <div class="form-group">
                        <label for="first_name" class="form-label required">İsim</label>
                        <input type="text" name="first_name" id="first_name"/>
                    </div>
                    <div class="form-group">
                        <label for="last_name" class="form-label required">Soyisim</label>
                        <input type="text" name="last_name" id="last_name"/>
                    </div>

                    <div class="form-group">
                        <label for="user_name" class="form-label required">Eposta</label>
                        <input type="text" name="user_name" id="user_name"/>
                    </div>
                    <div class="form-group">
                        <label for="password" class="form-label required">Şifre</label>
                        <input type="password" name="password" id="password"/>
                    </div>
                </fieldset>

            </form>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/register/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/jquery-steps/jquery.steps.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/vendor/minimalist-picker/dobpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/register/js/main.js')); ?>"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194"
            integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw=="
            data-cf-beacon='{"rayId":"72d3315a3e725184","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2022.6.0","si":100}'
            crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-project\evet\resources\views/investor_register.blade.php ENDPATH**/ ?>