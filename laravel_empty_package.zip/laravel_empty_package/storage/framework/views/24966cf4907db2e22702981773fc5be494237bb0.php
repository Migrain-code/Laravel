<?php $__env->startSection('title','Evet'); ?>
<?php $__env->startSection('content'); ?>
    <div data-elementor-type="wp-page" data-elementor-id="36153" class="elementor elementor-36153">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-1579348 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="1579348" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-93385a3"
                     data-id="93385a3" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-c4e5f53 elementor-icon-list--layout-inline elementor-hidden-tablet elementor-hidden-mobile elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet_extra elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                             data-id="c4e5f53" data-element_type="widget" data-widget_type="icon-list.default">
                            <div class="elementor-widget-container">
                                <ul class="elementor-icon-list-items elementor-inline-items">
                                    <li class="elementor-icon-list-item elementor-inline-item">
                                <span class="elementor-icon-list-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="89" height="2" viewBox="0 0 89 2" fill="none">
                                    <path d="M88 1L1 1"
                                       stroke="#060815"
                                       stroke-width="1.5"
                                       stroke-linecap="round"></path></svg> </span>
                                        <span class="elementor-icon-list-text">Hakkımızda</span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-97de031 elementor-widget elementor-widget-heading"
                             data-id="97de031" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h1
                                    class="elementor-heading-title elementor-size-default">Hakkımızda</h1></div>
                        </div>
                        <div class="elementor-element elementor-element-13e169b elementor-widget elementor-widget-heading"
                             data-id="13e169b" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default">İşinizi Büyütebiliriz</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4546be3 elementor-hidden-tablet elementor-hidden-mobile"
                     data-id="4546be3" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-c90f61e elementor-widget elementor-widget-image"
                             data-id="c90f61e" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="1035" height="819"
                                     src="../wp-content/uploads/2022/06/about-banner.png"
                                     class="attachment-full size-full" alt="about-banner" loading="lazy"
                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-banner.png 1035w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-banner-300x237.png 300w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-banner-1024x810.png 1024w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-banner-768x608.png 768w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-banner-600x475.png 600w"
                                     sizes="(max-width: 1035px) 100vw, 1035px"/></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-e6620b1 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="e6620b1" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a0e36c2"
                     data-id="a0e36c2" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-797ebe7 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="797ebe7" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-bd4d1c3"
                                     data-id="bd4d1c3" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-c7fa795 elementor-invisible elementor-widget elementor-widget-heading"
                                             data-id="c7fa795" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default">İşinizin Büyümesi İçin Neler Yapabiliriz
                                                </h2></div>
                                        </div>
                                        <div class="elementor-element elementor-element-b03c769 elementor-invisible elementor-widget elementor-widget-text-editor"
                                             data-id="b03c769" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Diam mattis quam condimentum of the lipsum leo ipsum turpis ut.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7cf66f7"
                                     data-id="7cf66f7" data-element_type="column">
                                    <div class="elementor-widget-wrap"></div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-6cf7688 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="6cf7688" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-9f1de1d img-box-hover-effect elementor-invisible"
                                     data-id="9f1de1d" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:100}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-947b0ac elementor-widget elementor-widget-image"
                                             data-id="947b0ac" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="../wp-content/uploads/2022/06/demo-six-section-two-sun-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-sun-icon.png 156w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-sun-icon-150x150.png 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-sun-icon-100x100.png 100w"
                                                     sizes="(max-width: 156px) 100vw, 156px"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-057c5e1 elementor-widget elementor-widget-heading"
                                             data-id="057c5e1" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    Yaratıcı Fikirler</h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-0a68893 elementor-widget elementor-widget-text-editor"
                                             data-id="0a68893" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Euismod amet amet quam est tempus tempus interdum quis in.
                                                Elementum mi vel magna eget vel pulvinar
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2e3f7ea img-box-hover-effect elementor-invisible"
                                     data-id="2e3f7ea" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:200}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-1b206e8 elementor-widget elementor-widget-image"
                                             data-id="1b206e8" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="../wp-content/uploads/2022/06/demo-six-section-two-flower-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-flower-icon.png 156w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-flower-icon-150x150.png 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-flower-icon-100x100.png 100w"
                                                     sizes="(max-width: 156px) 100vw, 156px"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-353d180 elementor-widget elementor-widget-heading"
                                             data-id="353d180" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    Harika Tasarımlar</h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-ebe3c18 elementor-widget elementor-widget-text-editor"
                                             data-id="ebe3c18" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Euismod amet amet quam est tempus tempus interdum quis in.
                                                Elementum mi vel magna eget vel pulvinar
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-38764bc elementor-widget elementor-widget-radiant-custom-button"
                                             data-id="38764bc" data-element_type="widget"
                                             data-settings="{&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                                             data-widget_type="radiant-custom-button.default">

                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6851577 img-box-hover-effect elementor-invisible"
                                     data-id="6851577" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:300}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-e7667b6 elementor-widget elementor-widget-image"
                                             data-id="e7667b6" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="../wp-content/uploads/2022/06/demo-six-section-two-stack-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-stack-icon.png 156w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-stack-icon-150x150.png 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-stack-icon-100x100.png 100w"
                                                     sizes="(max-width: 156px) 100vw, 156px"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-1c94f12 elementor-widget elementor-widget-heading"
                                             data-id="1c94f12" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    En iyi özellikler
                                                </h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-61d8d13 elementor-widget elementor-widget-text-editor"
                                             data-id="61d8d13" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Euismod amet amet quam est tempus tempus interdum quis in.
                                                Elementum mi vel magna eget vel pulvinar
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-9a08d3c elementor-widget elementor-widget-radiant-custom-button"
                                             data-id="9a08d3c" data-element_type="widget"
                                             data-settings="{&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                                             data-widget_type="radiant-custom-button.default">

                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-211183b img-box-hover-effect elementor-invisible"
                                     data-id="211183b" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:400}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-77baf39 elementor-widget elementor-widget-image"
                                             data-id="77baf39" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="../wp-content/uploads/2022/06/demo-six-section-two-cog-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-cog-icon.png 156w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-cog-icon-150x150.png 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-six-section-two-cog-icon-100x100.png 100w"
                                                     sizes="(max-width: 156px) 100vw, 156px"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-8733daa elementor-widget elementor-widget-heading"
                                             data-id="8733daa" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    Kolay Çözümler
                                                </h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-864b70d elementor-widget elementor-widget-text-editor"
                                             data-id="864b70d" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Euismod amet amet quam est tempus tempus interdum quis in.
                                                Elementum mi vel magna eget vel pulvinar
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-dc24a44 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="dc24a44" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-16f2111"
                     data-id="16f2111" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-607c075 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="607c075" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-b8955f9"
                                     data-id="b8955f9" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-4940da2 elementor-invisible elementor-widget elementor-widget-heading"
                                             data-id="4940da2" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default">
                                                    20+ Yıldan Fazla Pratik Pazarlama Tecrübemiz Var

                                                </h2>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-381c652 elementor-invisible elementor-widget elementor-widget-text-editor"
                                             data-id="381c652" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Egestas dictum lectus diam commodo. Et tristique nunc faucibus
                                                sit tortor commodo aliquet commodo quam. Id suspendisse vel in
                                                non arcu, interdum quis placerat accumsan.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-ada91ba elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="ada91ba" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5ac64bd"
                                     data-id="5ac64bd" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-38d2caf elementor-invisible elementor-widget elementor-widget-image"
                                             data-id="38d2caf" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:300}"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="773" height="693"
                                                     src="../wp-content/uploads/2022/06/about-img1.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img1.png 773w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img1-300x269.png 300w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img1-768x689.png 768w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img1-600x538.png 600w"
                                                     sizes="(max-width: 773px) 100vw, 773px"/></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d325549"
                                     data-id="d325549" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-a466396 elementor-position-left moving-image-left-right elementor-vertical-align-top elementor-invisible elementor-widget elementor-widget-image-box"
                                             data-id="a466396" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img"><img width="110"
                                                                                                 height="102"
                                                                                                 src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/demo-two-marketing-plan1.svg"
                                                                                                 class="attachment-full size-full"
                                                                                                 alt=""
                                                                                                 loading="lazy"/>
                                                    </figure>
                                                    <div class="elementor-image-box-content">
                                                        <h5 class="elementor-image-box-title">Misyonumuz & Vizyonumuz
                                                        </h5>
                                                        <p class="elementor-image-box-description">Euismod amet
                                                            amet quam est tempus quis ementm mi vel pulvinar</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-411e7a6 elementor-position-left moving-image-left-right elementor-vertical-align-top elementor-invisible elementor-widget elementor-widget-image-box"
                                             data-id="411e7a6" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img"><img width="110"
                                                                                                 height="102"
                                                                                                 src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/demo-two-latest-strategy-svg.svg"
                                                                                                 class="attachment-full size-full"
                                                                                                 alt=""
                                                                                                 loading="lazy"/>
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">
                                                            Son Strateji
                                                        </h5>
                                                        <p class="elementor-image-box-description">Euismod amet
                                                            amet quam est tempus quis ementm mi vel pulvinar</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-12f0128 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="12f0128" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-15a1efa"
                     data-id="15a1efa" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-7d1130f elementor-widget elementor-widget-radiant-client"
                             data-id="7d1130f" data-element_type="widget"
                             data-widget_type="radiant-client.default">
                            <div class="elementor-widget-container">
                                <div class="clients swiper-container allow-autoplay element-one"
                                     data-mobile-items="1" data-tab-items="3" data-desktop-items="5"
                                     data-spacer="30" data-autoplay="true">
                                    <div class="swiper-wrapper">
                                        <div class="clients-item swiper-slide">
                                            <div class="holder">
                                                <div class="table">
                                                    <div class="table-cell">
                                                        <div class="pic radiantthemes-retina"><img
                                                                loading="lazy" width="124" height="56"
                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-5-05.webp"
                                                                class="client-cover-img wp-post-image" alt=""/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clients-item swiper-slide">
                                            <div class="holder">
                                                <div class="table">
                                                    <div class="table-cell">
                                                        <div class="pic radiantthemes-retina"><img width="183"
                                                                                                   height="56"
                                                                                                   src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-4-04.webp"
                                                                                                   class="client-cover-img wp-post-image"
                                                                                                   alt=""
                                                                                                   loading="lazy"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clients-item swiper-slide">
                                            <div class="holder">
                                                <div class="table">
                                                    <div class="table-cell">
                                                        <div class="pic radiantthemes-retina"><img width="142"
                                                                                                   height="56"
                                                                                                   src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-3-03.webp"
                                                                                                   class="client-cover-img wp-post-image"
                                                                                                   alt=""
                                                                                                   loading="lazy"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clients-item swiper-slide">
                                            <div class="holder">
                                                <div class="table">
                                                    <div class="table-cell">
                                                        <div class="pic radiantthemes-retina"><img width="176"
                                                                                                   height="56"
                                                                                                   src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-2-02.webp"
                                                                                                   class="client-cover-img wp-post-image"
                                                                                                   alt=""
                                                                                                   loading="lazy"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clients-item swiper-slide">
                                            <div class="holder">
                                                <div class="table">
                                                    <div class="table-cell">
                                                        <div class="pic radiantthemes-retina"><img width="119"
                                                                                                   height="56"
                                                                                                   src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-1-01.webp"
                                                                                                   class="client-cover-img wp-post-image"
                                                                                                   alt=""
                                                                                                   loading="lazy"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-pagination3"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-fecf097 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="fecf097" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-e449118"
                     data-id="e449118" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-62e84cf moving-image-left-right elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image"
                             data-id="62e84cf" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="660" height="719" src="../wp-content/uploads/2022/06/about-img3.png"
                                     class="attachment-full size-full" alt="about-img3" loading="lazy"
                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img3.png 660w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img3-275x300.png 275w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img3-600x654.png 600w"
                                     sizes="(max-width: 660px) 100vw, 660px"/></div>
                        </div>
                        <div class="elementor-element elementor-element-0c2d320 moving-image-left-right elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet_extra elementor-widget elementor-widget-image"
                             data-id="0c2d320" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="660" height="718" src="../wp-content/uploads/2022/06/about-img4.png"
                                     class="attachment-full size-full" alt="about-img4" loading="lazy"
                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img4.png 660w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img4-276x300.png 276w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/about-img4-600x653.png 600w"
                                     sizes="(max-width: 660px) 100vw, 660px"/></div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-099aff1 elementor-hidden-tablet elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="099aff1" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-2ebef48"
                                     data-id="2ebef48" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-1b60d67 elementor-view-default elementor-widget elementor-widget-icon"
                                             data-id="1b60d67" data-element_type="widget"
                                             data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                             xmlns:xlink="http://www.w3.org/1999/xlink"
                                                             width="40" height="41" viewBox="0 0 40 41"
                                                             fill="none">
                                                            <rect y="0.756531" width="40" height="40"
                                                                  fill="url(#pattern0)"></rect>
                                                            <defs>
                                                                <pattern id="pattern0"
                                                                         patternContentUnits="objectBoundingBox"
                                                                         width="1" height="1">
                                                                    <use xlink:href="#image0_51_107"
                                                                         transform="scale(0.00195312)"></use>
                                                                </pattern>
                                                                <image id="image0_51_107" width="512"
                                                                       height="512"
                                                                       xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIAEAQAAAAO4cAyAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAAAGAAAABgAPBrQs8AAB/2SURBVHja7d3322VVeQbgtQdmiJKI5LosVyJqYsWumBgbyjBDEZBipdgbigU79m7EAnYQuyYq2EZBBTU2JICKgCWAqDR1ECmCQxX2mx+Ow6BTzv5mvnPevc+6739g1nrX3ut5vj3DR1MA4G9ERGSvgclakL0AAGD6FAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUqMleAAD0XbSLFpXm8MNL2W237LXMFwUAANZhFP5HHFHKrrtmr2U+KQAAsBaj8P/sZ0t5+MOz1zLfFAAAWINZDv9SFAAAWM0o/D/3uVJ22SV7LZOiAADADUS7ySaj8N955+y1TJICAAB/UUv4l1LKxtkLAIA+iLjRjUp86UulLF2avZZp8AUAgOqNwv/LXy7NkiXZa5kWvwkQgKpF3PjGtYV/Kb4AAFCxVeG/7bbZa5k2BQCAKo3C/8gjS7N4cfZaMigAAFSn9vAvRQEAoDIRm25aypFHlrLNNtlryaQAAFCNiE03LXHUUaV56EOz15JNAQCgCsL/rykAAMy80Wf/r3yllIc8JHstfeE3AQIw06K9yU1KOfroUu5//+y19IlfBATAzIp2s81KOeYY4b86fwUAwEy6Pvyb+90vey19pAAAMHOE/3j+CgCAmRKx+ealfPObwwj/ZcuyVwAAgxdx05tGnHhiDMJRR0W7ySZZf3r2WUFvRLtoUbSLFmWvA1g/Ef/4jxEnnZQd6520n/98tAsXjtadI/u8oBeiXbQo4otfjPjKV6LdZJPs9QBzE7H55tH+8IfZud7N5z63MvxHa8+RfWaQbhT+y5atei2UABiSYYX/Zz97w/AfrT9H9rlBqtXDfyUlAIYgYvPNI370o8xI72718B/tIUf22UGaUfh/6Utrfz2UAOizaG92s4hTT80K0Dlpjzgi2o3X+Nt3s5aUfX6QYnz4r6QEQB+Nwv8nP8kKz7k5/PC1hX8pCgBMzSj8v/zl7q+JEgB9Eu3Nbz4r4V+KAgBTMffwX0kJgD4Yhf9Pf5oVmnPzmc+MC/9SFACYuNEv3DjyyPV/XZQAyDSs8P/0p7uEfykKAEzUhof/SkoAZIj2FreI+NnPssJybrqHfykKAEzMKPyPOmr+XhslAKZpFP4//3lWUM7Npz4VsdFGc9pfkuxzhYmKuNGNov3GN+b/1VECYBqGFf4f+UjEgjn/T/ayVpt9tjAxkwv/lZQAmKSIW95yMOHffvjD6xP+o33myD5fmIiIG994suG/khIAkxDtrW4VceaZWeE4JxsQ/qUoADBvRuH/zW9O7zVSAmA+RbvFFoMJ//jQhzYk/EtRAGBejML/f/5n+q+SEgDzIdottoj2l7/MCsU5aT/4wQ0N/1IUANhgeeG/khIAG6LG8C9FAYANEnHjG0d861vZd4ISAOsn2lvfejjhf9hh8xX+pSgAsN76E/4rKQEwF6Pw/9Wvst/cTtrDDotomnndf5Lsc4cNErHppv0K/5WUAOgi2tvcJuLXv85+Y7v5wAfmO/xLUQBgziI23TTab387+0pYOyUA1mVY4X/ooZMI/1IUAJiT/of/SkoArMmwwv+QQyYV/qUoANDZ6LP/d76TfSV0pwTADUXc9rYRZ52V/WZ2c/DBkwz/0TxyZD8HMCej8P/ud7OvhLlTAqCUUqK9wx0izjsv+43spD3ooKnMJEn2swCdRbvZZtEef3z2nbD+lADqNgr/3/wm+03spH3HO6Y2lyTZzwN0MvzwX0kJoE7R3vGOwn8ts0mS/UzAWKPwP+GE7Dth/igB1GUU/r/9bfab10n79rdPfT5Jsp8LWKfZC/+VlADqEHGnOw0n/N/2tpwZ5ch+NmCtot1ss4gTT8y+EyZHCWC2DSv83/rWvDnlyH4+YI0ibnrT2Q7/lZQAZlPEne8c8bvfZb9hnSSG/2hWObKfEVhNPeG/khLAbBlU+MeBB+bPK0f2vuGvjML/Bz/IvhKmTwlgNkRsuWXE8uXZb1Q3b3lL9rxGM8uRvW+4Xr3hv5ISwLAJ//WdW47sfUMppZSIzTeP9oc/zL4S8ikBDFO097xntH/4Q/Yb1M1rXpM9r7+aXZLsfYPwX40SwLAMK/xf/ersea02vyTZ+6ZyEZtvHvGjH2VfCf2jBDAMEfe6l/Df0BnmyN43FYv2ZjeLOPXU7Cuhv5QA+i3iXveKuPDC7Delm1e9Kntea59jjux9U6lR+P/kJ9lXQv8pAfRTxL3vPZjwb1/5yux5rXuWObL3TYWE/1wpAfTLKPwvuij7zejmFa/Intf4eebI3jeVifbmNxf+60MJoB8i7nMf4T/fM82RvW8qMgr/n/40+0oYLiWAXBFbbTWc8H/5y7Pn1X2uObL3TSWE/3xRAsgxCv+LL85+A7p52cuy5zW32ebI3jcVEP7zTQlguiLuf/+ISy/NfvK7OeCA7HnNfb45svfNjIu45S0j/u//sq+Ebr74xYhly7JX0c2yZdEuWpR9vsy+iAc8YBjh37YR+++fPa/1m3GO7H0zw6K9xS0ifvaz7Guhm6OOinaTTaJduHBUBIbAlwAma1jh/7znZc9r/eecI3vfzKhR+P/859nXQift5z8f7cKFq9auBEDEAx8Ycdll2U/4eG0b7XOfmz2vDZt1jux9M4MGFf7xuc/dMPxX7UEJoF7RPuhBgwn/eM5zsue1wfNOkr1vZszo7/yHEv6f/eyawv/6vSgBVGhQ4d8++9nZ85qXmSfJ3jczZFj/4G/d4X/9npQAKhLtgx8c8ac/ZT/J481O+JeiADBw0d7qVhFnnpl9LXTSHnFEtBtv3H1vSgCzb1DhH/vtlz2veZ19kux9MwMGFf5x+OFzCf9Ve1QCmF3Rbr31cML/Wc/Knte8zz9J9r4ZuGi32GLWw3/VXpUAZk/EQx4S7YoV2U/seLMZ/qMzyJG9bwYs2i22iPaXv8y+Frr5zGc2JPxX7VkJYHZEu3RpxBVXZD+p47VtxDOfmT2viZ1Dkux9M1A1hv+qvSsBDF+02203nPDfd9/seU30LJJk75sBivbWtx5O+H/60/MZ/qtmoAQwXNFuv33ElVdmP5njXXddxBOfmD2viZ9Hkux9MzCj8P/Vr7KvhW4+/emIjTaa3CyUAIYnYocdhhP+T3hC9rymcyY5svfNgAwr/D/ykYgFCyY/EyWA4RhO+F97bS3hPzqXHNn7ZiCivc1tIn796+xroZvphP+q2SgB9F/EjjsOJvzbxz8+e17TPZsc2ftmAAYV/u2HPzzN8F81IyWA/hpW+D/ucdnzmv755MjeNz0n/OcyKyWA/ol42MMirroq+4kbr87wH51Rjux902MRt71txFlnZV8L3XzoQ5nhf/3MlAB6JGKnnYYT/vvskz2vvHPKkb1vempQ4d9+8IN9CP/rZ6cE0APCfziyJp+9b3oo2jvcIeK887KvhU7aww7rU/ivmqESQJ6IRzwi4pprsp+s8a69NmLvvbPnlS1r+tn7pmdG4f+b32RfC530NPxXzVIJYPqifeQjhxP+e+2VPa8+yDqB7H3TI4MK//jAByKaJntm42eqBDA9wwr/PffMnldfZJ1C9r7piWjveEfhP6nZKgFMXrSPelTEn/+c/QSNd801EXvskT2vPsk6iex90wOj8P/tb7OvhW4OPXRI4b9qxkoAkxPx6EcPJ/x33z17Xn2TdRrZ+yZZxJ3uNJzwP+SQIYb/9bNWApiAYYX/brtlzwsoQwv/gw8ecvhfP3MlgHkU8ZjHDCP8r75a+ENPjML/d7/LvhY6aQ86KHte8zp7JYB5EPHYxw4n/HfdNXteQCkl4s53Hk74v+Md2fOayBkoAWyAUfhfe232kzGe8IfeGFb4v/3t2fOa6FkoAayHiCc9KeK667KfiPGuvjri4Q/PnhdQVob/8uXZ10InMx7+15+JEsAcRDz5ycIfmJOILbccTvi/7W3Z85rq2SgBdDCo8G932SV7XkAZWvi/9a3Z80o5IyWAdYh4ylOGEf5XXRXtzjtnzwsopUR7z3tG+4c/ZF8L3Rx4YPa8cs9KCWB10T71qcIfmBPhPzxKADcU7dOeNozwv+KKaJcuzZ4XUEqJuNe9hhP+b3lL9rz6RAmglKGF/5Il2fMCyl/CPy68MPta6Eb4r4kSULeIpz89om2zT3a8yy8X/tATwwr/17wme159pgTUKdpnPGMw4R/bbps9L6CUEnHvew8n/F/96ux5DYESUJeIffcdTvgvXpw9L6AI/1mmBNQhYv/9hT8wJ6Pwv+ii7Guhm1e9KnteQ6QEzLaI5z8/+9S6ufzyiG22yZ4XUEqJuM99BhP+7StfmT2vIVMCZlPEC16QfVqdtCtWCH/oiUGFf7ziFdnzmgVKwGyJeOELs0+pk3bFioiHPjR7XkApJWKrrYR/nZSA2RDti16UfTqdCH/oj1H4X3xx9r3Qzctfnj2vWaQEDFu0L35x9ql00q5YEfGQh2TPCyilRNz//hGXXpp9L3Tzspdlz2uWKQHDFPGSl2SfRiftihXRbr119ryAMrTwP+CA7HnVQAkYlsGEf/zxjxH/8R/Z8wJKKREPeMAwwr9tI/bfP3teNVEChiHipS/Nnn43wh96YxT+l12WfS2M17YRz3te9rxqpAT026DCv73f/bLnBZRSIh74wMGEf/vc52bPq2ZKQD9FvPa12dPuRvhDbwwq/OM5z8meF0pA30S87nXZU+7mkkui/fd/z54XUEqJ9kEPEv6sDyWgHyJe//rs6XYj/KE3BhX+7bOfnT0vVqcEJM8/3vCG7Kl2c8kl0f7bv2XPCyilRPvgB0f86U/Z18J4bRux337Z82LtlICkuccb35g9zW6EP/TGsML/Wc/KnhfjKQFTnne86U3ZU+zm4oujve99s+cFlFKi3Xpr4c8kKAHTmvOb35w9vW6EP/TGsML/mc/MnhdzpwRMer4DCv/YaqvseQHlL+HfrliRfS2MJ/yHTgmYwEyjaSIOPjh7Wt1ccEG097hH9syAUkq0S5dGXHFF9rUwXttG7Ltv9rzYcErAPM4ymibine/MnlI3F1wQ7d3vnj0zoJQS7XbbDSP8r7su4olPzJ4X80cJmIcZRtNEvOtd2dPp5ve/F/7QE8MK/yc8IXtezD8lYANmF00T8e53Z0+lm9//Ptq73S17ZkApJdrtt4+48srsa2G8a68V/rNNCViPmUXTRLznPdnT6Eb4Q28MKvzbxz8+e15MnhIwh1lF00S8973ZU+jm/PMj7nrX7OcLKKVE7LDDcML/cY/LnhfTowR0mFE0TcT73pe9+26EP/TGsMJ/n32y58X0KQHrmM3gwv8ud8l+noBSSsSOOwp/hkAJWMNMomki3v/+7N12I/yhNwYV/rH33tnzIp8ScINZRNNEHHJI9i67Wb5c+ENPRDzsYRFXXZV9LYwn/PlrSkApEQsWRHz0o9m762b58ogtt8x+boAytPDfa6/sedE/NZeAiI02ivjYx7J31c1550V7+9tnPy9AKSVip52GE/577pk9L/qrxhIwCv+Pfzx7N92ce67wh54YTvhfc03EHntkz4v+q6kEDC7843a3y34+gFJKxB57jIK17665JmL33bPnxXDUUAJG4f+JT2SvvptzzhH+0BMRj3jEcMJ/t92y58XwzHIJGIX/Jz+Zvepuzjkn4l//Nft5AEop0T7ykcMI/6uvFv5siFksAaPw/6//yl5tN8IfemNY4b/rrtnzYvhmqQQML/z/5V+yzx8oK8P/z3/OvhbGu/rqiIc/PHtezI5ZKAGj8P/v/85eXTdnny38oSeifdSjhD81G3IJGIX/pz6VvapuhD/0RsSjHz2Y8G932SV7XsyuIZaA0Zq/8IXs1XRz1lkRt71t9jkDpZSIvfYa/QKdvrvyyogdd8yeF7Mv2kWLIpYty37iu1m2bDiF5cwzo73VrbLPFyilRDzmMcP4yf+qq6LdeefseVGPYX0JGIJf/CLin/85+1yBIvxhHCVgvgh/6I2Ixz52MOEfO+2UPS/qpQRsqDPOEP7QE8MJ/yuuiHbJkux5gRKwvs44I+Kf/in7/IBSSsSeew7jH/xdfrnwp0+UgLk6/XThDz0R8aQnRVx3Xfa1MN7ll0dsu232vOBvKQFdCX/yNNkL6JuIJz+5lA9+sJQFC7LXsm5XXFHKLrs0zbe+lb0SWJNoFy4szRFHlOL/QbFmZ5xRyjbbNM3y5dkrWZOIiOw11KJpmpQs7nnITZfwh/nTLPjzn0s8+tGlLFuWvZbeidNP73P4U4eeB930RDzlKcMJ/513Fv4MgRKwBnH66aVZvFj4k63nYTcdo/A/7LDeh39cfvko/L/97eylQFdKwA2ddlpp/ORPP/Q78KYg2qc+dTDh3wh/hkkJKKWU004rZfHipjn//OyVQCmVF4Bon/a00nzgA8MJ/+98J3spsL7qLgGnnlpi662FP33S7+CboFH4H3roMMJ/p52EP7OgzhJw6qkllixpFlx4YfZK4Ib6HX4TMqyf/HfaqWm++93spcB8qaoExCmnCH/6qrrfAxDx9KeXcuihpeT8d5fdXXZZKdtv3zQnnJC9EpiEmf89AXHKKaVZsqRpLrooeynrtXy/B2Bq/B6AKYj2Gc8YRvhfeqnwZ9bN9JeAgYc/daimAET7jGeU5pBDBhH+Ifypw0yWgDj5ZOHPEFRRACL23XdQ4b/gxBOzVwLTMlMlQPgzIDNfACL237+UoYT/dtsJf2o0GyXgxz8ehf/FF2evBLqY6QIQ8fznl3LwwdnrGO+PfxyF/w9+kL0SyDLsEnDSSaUsXSr8GZKZLQARL3hBKQcdlL2O8YQ/rDTMEiD8GaaZLACj8H/HO7LXMd7K8P/hD7NXAn0xrBKwMvwvuSR7JTBXM1cAIl74wuGE/9Klwh9WN4wScPzxJRYvFv7QA9G+6EUxCBdfHO1975s9L+i7aBcujPjiF7Pf2NUdd1y0N7lJ9nwmOnumJvusB29Q4R9bbZU9LxiK/pWA446L9h/+IXsuE587U5N91oMW7YtfnH2A3VxwQbT3uEf2vGBo+lMCvv/9GsK/FAVgmrLPerAiXvKS7MPr5oILor373bPnBUOVXwLqCf9SFIBpyj7rQRL+UJe8EnDssTWFfykKwDRln/XgRLz0pdmH1s3vfy/8Yf5MvwR873vR/v3fZ+976nNmarLPelCGFf53u1v2vGDWTK8E1Bn+pSgA05R91oMR8drXZh9WN8IfJmnyJeC73601/EtRAKYp+6wHYTjhf/75EXe9a/a8YNZNrgTUHf6lKADTlH3WvRfxutdlH1I3wh+maf5LwHe+E7Hpptn7ypZ9k9Yk+6x7LeL1r88+oG7OPz/iLnfJnhfUZt5KQPv1r0fc6EbZ++mD7Nu0Jtln3VvCH+hiw0vAMccI/1Wyb9SaZJ91L0W84Q3ZB9PN8uXCH/KtfwkQ/n8r+1atSfZZ907EG9+YfSjdLF8eseWW2fMCRuZeAo4+OuLv/i573X2TfbPWJPuse2U44X/eedHe/vbZ8wL+WvcS8LWvCf81y75da5J91r0R8aY3ZR9GN+eeK/yhv8aXAOG/Ltk3bE2yz7oXon3zm7MPoptzz4243e2y5wWs21pLQPvVrwr/dcu+ZWuSfdbphhP+55wj/GE4VisB7Ve/Gu0mm2Svq++yb9qaZJ1xk/2QjR60//zPUg44IHsd4517binbbNM0v/519kqA7qJduLA0RxxRyqJFJfbYo1lw9dXZa+q7zGCqTdM0KVmcWgAimqaUgw4qZf/9M9fRzdlnj8L/7LOzVwLMXbSLFpVSSrPgmmuy1zIECsD0VFcARuF/8MGlPO95WWvo7txzS3noQ5vmrLOyVwIwDQrA9GQVgAUZf+go/N/5zmGE/znnCH8AZs3G0/4DR+H/rneV8pznZG9+vHPOGX32F/4AzJapfgEYVviffbaf/AGYVVP7AjAK/3e/u5RnPzt70+P5B38AzLapfAEYhf973jOM8D/zzBIPfrDwB2CWTfwLwKrw32+/7M2Od+aZpWyzTbPgt7/NXgkATNJEvwCMwv+97x1G+P/iF6PP/sIfgNk3sS8Aq8L/Wc/K3uR4K8P/d7/LXgkATMNEvgCMwv997xtG+J9xhvAHoDbz/gVgFP7vf38p++6bvbnxzjijlMWLhT8AtZnXLwDCHwCGYd6+AEQsWFDKhz9cyhOfmL2p8Ys9/fTSLF7cNMuXZy8FADLMSwEYhf9HPlLKE56QvaHxixX+ALDBfwUQsdFGwwr/bbYR/gDUboMKwKDCv5x22ij8zz8/eyUAkG29C8Ao/D/60VIe//jsTYz3k5+U2Hpr4Q8AI+tVAFaF/+Mel72B8U49tcS22zYLLrwweyUA0Bdz/keAo/D/2MdK2Wef7MWPd+qpJZYsEf4A8Nfm9AVgUOEfp5wi/AFgzTp/ARiF/8c/Xsree2cvevxiTzmlNEuWNM1FF2UvBQD6qNMXgGGF/8knC38AWLexXwBG4f+JT5Sy117Zix0rTj65NEuXCn8AWLd1FoBR+H/yk6XsuWf2Qsf78Y9H4X/xxdkrYSQiInsNNWiapsleAzA8a/0rgMGFfxH+ANDVGr8ARLtwYSmHH17K7rtnL3C8k04qZbvthD8AdLdaAYh24cLSDCn8ly5tmksuyV4JAAzJ6n8F0DziEYMI/zjhhBLbbiv8AWDuVisATfOZz5RywAHZC1u3448vZfvtmwWXXpq9EgAYojX+I8CmOfDA/paA//3fEjvs0Cy47LLslQDAUK31vwLoZwkQ/gAwH9b5mwD7VQKOO24U/n/6U/ZKAGDoxv4q4H6UgOOOK7HjjsIfAOZHp/8XQG4J+P73hT8AzK/O/zvgnBIg/AFgEjoXgFKmXQKOPXYU/itWZAwGAGbZnApAKdMqAcceW+JhDxP+ADAZcy4ApUy6BHzve8IfACZrvQpAKZMqAd/7XinCHwAmbb0LQCnzXALiG98oZYcdmubyy7OHAgCzboMKQCnzVQK+/vXS7Lpr01x5ZfZAAKAGG1wAStnQEvD1r5ey227CHwCmZ14KQCnrWwKOOaYUP/kDwLTNWwEoZa4l4OijRz/5X3VV9hAAoDbzWgBK6VoCjj66lN13F/4AkGPeC0ApY0pAfO1rwh8Ack2kAJSylhIQX/taafbYQ/gDQK6JFYBS/rYEfPWrfvIHgH5opvGHRDz2sSW+8IVmwTXXZG+Y6YmIyF5DDZqmmcp7TF28v9OT9Q67OJgYF8h0KABMgvd3erLe4Yn+FQAA0E8KAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCG2cvABimiIjsNdSgaZomew3MJl8AAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqtHHWHxwRkb35WjRN02SvAYB+8QUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKNRER2YsAAKbLFwAAqJACAAAVUgAAoEIKAABUSAEAgAopAABQIQUAACqkAABAhRQAAKiQAgAAFVIAAKBCCgAAVEgBAIAKKQAAUCEFAAAqpAAAQIUUAACokAIAABVSAACgQgoAAFRIAQCACikAAFAhBQAAKqQAAECFFAAAqJACAAAVUgAAoEIKAABUSAEAgAr9P0owd8dK9rJoAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDIyLTA1LTIzVDA1OjQ2OjU2KzAwOjAwamqNdQAAACV0RVh0ZGF0ZTptb2RpZnkAMjAyMi0wNS0yM1QwNTo0Njo1NiswMDowMBs3NckAAAAASUVORK5CYII="></image>
                                                            </defs>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-50fd98c"
                                     data-id="50fd98c" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-29b16cc elementor-widget elementor-widget-counter"
                                             data-id="29b16cc" data-element_type="widget"
                                             data-widget_type="counter.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-counter">
                                                    <div class="elementor-counter-number-wrapper">
                                                        <span class="elementor-counter-number-prefix"></span>
                                                        <span class="elementor-counter-number"
                                                              data-duration="2000" data-to-value="79"
                                                              data-from-value="0" data-delimiter=",">0</span>
                                                        <span class="elementor-counter-number-suffix">%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="elementor-element elementor-element-18ad6ac elementor-hidden-mobile elementor-hidden-tablet elementor-widget elementor-widget-text-editor"
                             data-id="18ad6ac" data-element_type="widget"
                             data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                                Increased Productivity
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-cbf175f elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile icon-moverotate2 elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet_extra elementor-widget elementor-widget-image"
                             data-id="cbf175f" data-element_type="widget"
                             data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                             data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="10" height="10"
                                     src="../wp-content/uploads/2022/05/demo-four-Ellipse2.png"
                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                        </div>
                        <div class="elementor-element elementor-element-0f653bb elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile icon-moverotate2 elementor-widget elementor-widget-image"
                             data-id="0f653bb" data-element_type="widget"
                             data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                             data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="10" height="10" src="../wp-content/uploads/2022/05/Ellipse1.png"
                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                        </div>
                        <div class="elementor-element elementor-element-c5a46c0 elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile elementor-invisible elementor-widget elementor-widget-image"
                             data-id="c5a46c0" data-element_type="widget"
                             data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}"
                             data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="76" height="83"
                                     src="../wp-content/uploads/2022/05/demo-four-polygon.png"
                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                        </div>
                    </div>
                </div>
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-890d488"
                     data-id="890d488" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-196526f elementor-invisible elementor-widget elementor-widget-heading"
                             data-id="196526f" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}"
                             data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h2
                                    class="elementor-heading-title elementor-size-default">
                                    İşinizi Yapmak İçin Varız
                                </h2></div>
                        </div>
                        <div class="elementor-element elementor-element-24c2efa elementor-invisible elementor-widget elementor-widget-text-editor"
                             data-id="24c2efa" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:50}"
                             data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                                Aliqm lorem ante, dapibus in, viverra quis, feugiat Phasellus aut ms varius
                                laoreet srtrum aenean imperdiet. Etiam ult augue dapibus in, viverra quis srtrum
                                aenean.
                            </div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-45cb43a elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="45cb43a" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-03ddb6b elementor-invisible"
                                     data-id="03ddb6b" data-element_type="column"
                                     data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:100}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-a7d74b5 elementor-widget elementor-widget-heading"
                                             data-id="a7d74b5" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">69%</span>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-119ea1e elementor-absolute elementor-widget elementor-widget-heading"
                                             data-id="119ea1e" data-element_type="widget"
                                             data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container" style="padding-left: 10px;">
                                                <span class="elementor-heading-title elementor-size-default">Artan<br/>Verimlilik</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-f6fbd1a elementor-invisible"
                                     data-id="f6fbd1a" data-element_type="column"
                                     data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:150}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-f63412a elementor-widget elementor-widget-heading"
                                             data-id="f63412a" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">85%</span>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-ae37e94 elementor-absolute elementor-widget elementor-widget-heading"
                                             data-id="ae37e94" data-element_type="widget"
                                             data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container" style="padding-left: 10px;">
                                                <span class="elementor-heading-title elementor-size-default">Hedeflenen<br/>Kazanç</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-0b1be7b elementor-hidden-desktop elementor-hidden-laptop elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="0b1be7b" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4a70428"
                                     data-id="4a70428" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-5fc81c3 elementor-widget elementor-widget-heading"
                                             data-id="5fc81c3" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">69%</span>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-f35e91c elementor-widget elementor-widget-heading"
                                             data-id="f35e91c" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Increased<br/>Productivity</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-9c85b46"
                                     data-id="9c85b46" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-de91176 elementor-widget elementor-widget-heading"
                                             data-id="de91176" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">85%</span>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-b00745e elementor-widget elementor-widget-heading"
                                             data-id="b00745e" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Targeted<br/>Acquisition</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istanbulyazilim/public_html/girisim/resources/views/about.blade.php ENDPATH**/ ?>