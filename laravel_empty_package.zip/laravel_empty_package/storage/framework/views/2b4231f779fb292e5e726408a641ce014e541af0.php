<?php $__env->startSection('title','Anasayfa'); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet" href="<?php echo e(asset('assets/wp-content/litespeed/css/b14cc47a1668d578e19539f42e5be3c2b4b8.css?ver=d9e91')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div data-elementor-type="wp-page" data-elementor-id="30515" class="elementor elementor-30515">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-1686a2a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="1686a2a" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-01a62a6"
                    data-id="01a62a6" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-fbe17bd elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                            data-id="fbe17bd" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-12809dd"
                                    data-id="12809dd" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-1dc6e7e elementor-widget elementor-widget-heading"
                                            data-id="1dc6e7e" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Girişim Programı</span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-3918426 elementor-widget elementor-widget-heading"
                                            data-id="3918426" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h1
                                                    class="elementor-heading-title elementor-size-default">
                                                    İşinizi ileriye taşımak için yaratıcı çözümler
                                                </h1></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-dd9802e elementor-widget elementor-widget-heading"
                                            data-id="dd9802e" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Posuere semper ut donec vel. Ut egestas sit dui placerat volutpat consequat hac mattis.</span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-685206d elementor-widget elementor-widget-radiant-custom-button"
                                            data-id="685206d" data-element_type="widget"
                                            data-settings="{&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                                            data-widget_type="radiant-custom-button.default">
                                            <div class="elementor-widget-container">
                                                <div class="radiantthemes-custom-button element-one hover-style-five  "
                                                     data-button-direction="" data-button-fullwidth="false"
                                                     data-button-icon-position=""><a
                                                        class="radiantthemes-custom-button-main"
                                                        href="<?php echo e(route('investor_register')); ?>">
                                                        <div class="placeholder">Kayıt Ol</div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-958cbca elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet elementor-hidden-laptop elementor-hidden-tablet_extra elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="958cbca" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="41" height="47"
                                                             viewBox="0 0 41 47" fill="none">
                                                            <path
                                                                d="M6.23345 40.6684L3.42545 5.96068L34.5166 21.6404L6.23345 40.6684Z"
                                                                stroke="url(#paint0_linear_103_716)"
                                                                stroke-width="6"></path>
                                                            <defs>
                                                                <linearGradient id="paint0_linear_103_716"
                                                                                x1="0.00423016" y1="0.87539"
                                                                                x2="29.3981" y2="44.5662"
                                                                                gradientUnits="userSpaceOnUse">
                                                                    <stop stop-color="#68C9E8"></stop>
                                                                    <stop offset="1" stop-color="#252DEF"></stop>
                                                                </linearGradient>
                                                            </defs>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-b4a487c"
                                    data-id="b4a487c" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-2f2901e moving-image-left-right elementor-widget elementor-widget-image"
                                            data-id="2f2901e" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="823" height="858"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img5.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img5.png 823w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img5-288x300.png 288w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img5-768x801.png 768w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img5-600x626.png 600w"
                                                     sizes="(max-width: 823px) 100vw, 823px" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-d40c166 elementor-widget__width-auto elementor-absolute animated-fast elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-radiant-custom-image animated zoomIn"
                                            data-id="d40c166" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="radiant-custom-image.default">
                                            <div class="elementor-widget-container">
                                                <img alt="custom-image"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-ten-section-three-side-img-2.png"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-ten-section-three-side-img-2.png 1x, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-ten-section-three-side-img-2@2x.png 2x"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-e011f31 elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="e011f31" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26"
                                                             viewBox="0 0 26 26" fill="none">
                                                            <path
                                                                d="M0.486045 16.5207C1.09317 18.6786 2.24801 20.6429 3.8384 22.2227C5.42879 23.8026 7.40069 24.9443 9.56261 25.5371C11.7245 26.1299 14.003 26.1535 16.1768 25.6058C18.3505 25.058 20.3457 23.9574 21.9685 22.4109C23.5914 20.8644 24.7868 18.9246 25.4385 16.7797C26.0903 14.6348 26.1764 12.3579 25.6884 10.1699C25.2004 7.98194 24.155 5.95736 22.6535 4.29274C21.1521 2.62813 19.2457 1.38006 17.1195 0.669734L15.0231 6.94462C16.0673 7.29345 17.0035 7.90637 17.7409 8.72385C18.4782 9.54133 18.9916 10.5356 19.2313 11.6101C19.4709 12.6846 19.4287 13.8028 19.1086 14.8561C18.7885 15.9094 18.2014 16.8621 17.4045 17.6216C16.6075 18.381 15.6277 18.9215 14.5602 19.1905C13.4927 19.4595 12.3737 19.4479 11.312 19.1568C10.2503 18.8657 9.28193 18.305 8.5009 17.5291C7.71987 16.7533 7.15274 15.7886 6.85459 14.7289L0.486045 16.5207Z"
                                                                fill="#236BE9"></path>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-5bc3456 elementor-widget__width-auto elementor-absolute animated-fast elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-radiant-custom-image animated zoomIn"
                                            data-id="5bc3456" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:400}"
                                            data-widget_type="radiant-custom-image.default">
                                            <div class="elementor-widget-container">
                                                <img alt="custom-image"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img2.png"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img2.png 1x, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img2@2x.png 2x"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-a78326b elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="a78326b" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34"
                                                             viewBox="0 0 34 34" fill="#242879">
                                                            <circle cx="17" cy="17" r="17"></circle>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-83095b1 elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet_extra elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="83095b1" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:800}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34"
                                                             viewBox="0 0 34 34" fill="#242879">
                                                            <circle cx="17" cy="17" r="17"></circle>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4341d7a elementor-widget__width-auto elementor-absolute animated-fast elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-radiant-custom-image animated zoomIn"
                                            data-id="4341d7a" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="radiant-custom-image.default">
                                            <div class="elementor-widget-container">
                                                <img alt="custom-image"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img3.png"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img3.png 1x, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/hm9-banner-img3@2x.png 2x"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-34abe50 elementor-widget__width-initial elementor-absolute elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image"
                                            data-id="34abe50" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="260" height="260"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/dot.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/dot.png 260w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/dot-150x150.png 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/dot-100x100.png 100w"
                                                     sizes="(max-width: 260px) 100vw, 260px" data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-7f161a6 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="7f161a6" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-508f6de"
                    data-id="508f6de" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-b48bf93 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="b48bf93" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-355457a"
                                    data-id="355457a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-1e39913 elementor-widget elementor-widget-radiant-client"
                                            data-id="1e39913" data-element_type="widget"
                                            data-widget_type="radiant-client.default">
                                            <div class="elementor-widget-container">
                                                <div
                                                    class="clients swiper-container allow-autoplay element-one swiper-container-initialized swiper-container-horizontal"
                                                    data-mobile-items="1" data-tab-items="3" data-desktop-items="5"
                                                    data-spacer="30" data-autoplay="true">
                                                    <div class="swiper-wrapper"
                                                         style="transform: translate3d(-2640px, 0px, 0px); transition-duration: 0ms;">
                                                        <div class="clients-item swiper-slide swiper-slide-duplicate"
                                                             data-swiper-slide-index="0"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                loading="lazy" width="124" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-5-05.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt=""></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide swiper-slide-duplicate"
                                                             data-swiper-slide-index="1"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="183" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-4-04.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide swiper-slide-duplicate"
                                                             data-swiper-slide-index="2"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="142" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-3-03.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide swiper-slide-duplicate"
                                                             data-swiper-slide-index="3"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="176" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-2-02.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="clients-item swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev"
                                                            data-swiper-slide-index="4"
                                                            style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="119" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-1-01.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="clients-item swiper-slide swiper-slide-duplicate-active"
                                                            data-swiper-slide-index="0"
                                                            style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                loading="lazy" width="124" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-5-05.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt=""></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="clients-item swiper-slide swiper-slide-duplicate-next"
                                                            data-swiper-slide-index="1"
                                                            style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="183" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-4-04.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide"
                                                             data-swiper-slide-index="2"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="142" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-3-03.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide"
                                                             data-swiper-slide-index="3"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="176" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-2-02.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide swiper-slide-prev"
                                                             data-swiper-slide-index="4"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="119" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-1-01.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="clients-item swiper-slide swiper-slide-duplicate swiper-slide-active"
                                                            data-swiper-slide-index="0"
                                                            style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                loading="lazy" width="124" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-5-05.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt=""></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="clients-item swiper-slide swiper-slide-duplicate swiper-slide-next"
                                                            data-swiper-slide-index="1"
                                                            style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="183" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-4-04.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide swiper-slide-duplicate"
                                                             data-swiper-slide-index="2"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="142" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-3-03.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clients-item swiper-slide swiper-slide-duplicate"
                                                             data-swiper-slide-index="3"
                                                             style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="176" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-2-02.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="clients-item swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev"
                                                            data-swiper-slide-index="4"
                                                            style="width: 234px; margin-right: 30px;">
                                                            <div class="holder">
                                                                <div class="table">
                                                                    <div class="table-cell">
                                                                        <div class="pic radiantthemes-retina"><img
                                                                                width="119" height="56"
                                                                                src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/client-logo-1-01.webp"
                                                                                class="client-cover-img wp-post-image"
                                                                                alt="" loading="lazy"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-pagination3"></div>
                                                    <span class="swiper-notification" aria-live="assertive"
                                                          aria-atomic="true"></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-22c9241 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="22c9241" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-64ff10b"
                    data-id="64ff10b" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-ccf798e elementor-widget elementor-widget-heading"
                            data-id="ccf798e" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default">Nasıl Çalışırız</span></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-258fc0e elementor-widget elementor-widget-heading"
                            data-id="258fc0e" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h2
                                    class="elementor-heading-title elementor-size-default">
                                    Şirketimize Yatırım Yapın Ve Uzun Vadede Sağlıklı Kazançlar Sağlayın

                                </h2></div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-61b7bfd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="61b7bfd" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-9c7576c animated fadeIn"
                                    data-id="9c7576c" data-element_type="column"
                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:300}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b836618 elementor-widget elementor-widget-image"
                                            data-id="b836618" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="124" height="107"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/execution.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-88f5d75 elementor-widget elementor-widget-heading"
                                            data-id="88f5d75" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    İş Planlama Yürütme

                                                </h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-f3a5b83 elementor-widget elementor-widget-text-editor"
                                            data-id="f3a5b83" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Vulputate magna aliquam mauris vel hac condimentum massa faucibus.
                                                Luctus hendrerit orci egestas et.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7a056fa animated fadeIn"
                                    data-id="7a056fa" data-element_type="column"
                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:500}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b484fd5 elementor-widget elementor-widget-image"
                                            data-id="b484fd5" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="125" height="107"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-project.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-e13ad92 elementor-widget elementor-widget-heading"
                                            data-id="e13ad92" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Finansal Proje Analizi

                                                </h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-eaaad24 elementor-widget elementor-widget-text-editor"
                                            data-id="eaaad24" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Aliquam mauris vel hac condimentum massa faucibus. Luctus hendrerit
                                                tempor, posuere at leo pulvinar orci egestas et.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-003cc7f animated fadeIn"
                                    data-id="003cc7f" data-element_type="column"
                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:700}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b2e3830 elementor-widget elementor-widget-image"
                                            data-id="b2e3830" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="119" height="107"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-training-startegy.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-cbb9862 elementor-widget elementor-widget-heading"
                                            data-id="cbb9862" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Finansal Projeksiyon Analizi

                                                </h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-459a089 elementor-widget elementor-widget-text-editor"
                                            data-id="459a089" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container"><p>Mauris vel hac condimentum massa
                                                    faucibus. Luctus hendrerit tempor, posuere at leo pulvinar orci
                                                    egestas et.</p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-4e47c7a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="4e47c7a" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-667add9"
                    data-id="667add9" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-24c4545 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="24c4545" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1a4bbaa"
                                    data-id="1a4bbaa" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-4faa9d9 elementor-widget elementor-widget-image animated fadeIn"
                                            data-id="4faa9d9" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="603" height="696"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-main-img.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-main-img.png 603w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-main-img-260x300.png 260w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-main-img-600x693.png 600w"
                                                     sizes="(max-width: 603px) 100vw, 603px" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-0cab71f elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image"
                                            data-id="0cab71f" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="650" height="687"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-snake.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-snake.png 650w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-snake-284x300.png 284w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-snake-600x634.png 600w"
                                                     sizes="(max-width: 650px) 100vw, 650px" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-30d784e elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image animated zoomIn"
                                            data-id="30d784e" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="233" height="233"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-side-img-1.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-side-img-1.png 233w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-side-img-1-150x150.png 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-side-img-1-100x100.png 100w"
                                                     sizes="(max-width: 233px) 100vw, 233px" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-84c6c76 elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image animated zoomIn"
                                            data-id="84c6c76" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:100}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="174" height="185"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-3-side-img-2.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-56606ed"
                                    data-id="56606ed" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-71d1612 elementor-widget elementor-widget-heading"
                                            data-id="71d1612" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">PİYASAYI DEĞERLENDİRME</span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4524ca4 elementor-widget elementor-widget-heading"
                                            data-id="4524ca4" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default">
                                                    İşletmenizi Küresel Olarak Nasıl Yöneteceğinizi Biliyoruz

                                                </h2></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-a5dee70 elementor-widget elementor-widget-text-editor"
                                            data-id="a5dee70" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container"><p>Egestas dictum lectus diam
                                                    commodo. Et tristique nunc faucibus sit tortor commodo aliquet
                                                    commodo quam. Id suspendisse vel in nocumsan.</p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-161e33d elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box"
                                            data-id="161e33d" data-element_type="widget"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img"><img width="60" height="60"
                                                                                                 src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/business-solutions.svg"
                                                                                                 class="attachment-full size-full"
                                                                                                 alt="" loading="lazy"
                                                                                                 data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">İş Çözümleri</h5>
                                                        <p class="elementor-image-box-description">Leo id porttitor
                                                            lectus habitant at vitae in ac. Purus aliquam cursus in
                                                            risus nulla odio vitae interdum.ilisi diam diam.</p></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-ed8dd05 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box"
                                            data-id="ed8dd05" data-element_type="widget"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img"><img width="60" height="60"
                                                                                                 src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/markte-strategy.svg"
                                                                                                 class="attachment-full size-full"
                                                                                                 alt="" loading="lazy"
                                                                                                 data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">Pazarlama Stratejisi</h5>
                                                        <p class="elementor-image-box-description">Leo id porttitor
                                                            lectus habitant at vitae in ac. Purus aliquam cursus in
                                                            risus nulla odio vitae interdum.ilisi diam diam.</p></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-0c3f292 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="0c3f292" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-11bc34b animated fadeInUp"
                    data-id="11bc34b" data-element_type="column"
                    data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:100}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-880442b elementor-widget__width-initial elementor-widget elementor-widget-image"
                            data-id="880442b" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="82" height="82"
                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-ball.png"
                                     class="attachment-full size-full" alt="" loading="lazy" data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-fff95d0 elementor-widget__width-initial elementor-widget elementor-widget-counter"
                            data-id="fff95d0" data-element_type="widget" data-widget_type="counter.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-counter">
                                    <div class="elementor-counter-number-wrapper">
                                        <span class="elementor-counter-number-prefix"></span>
                                        <span class="elementor-counter-number" data-duration="2000" data-to-value="149"
                                              data-from-value="0" data-delimiter=",">149</span>
                                        <span class="elementor-counter-number-suffix">+</span></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-818fa73 elementor-widget__width-initial elementor-widget elementor-widget-text-editor"
                            data-id="818fa73" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container"><p>Ülke</p></div>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3433505 animated fadeInUp"
                    data-id="3433505" data-element_type="column"
                    data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:200}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-40ae0d4 elementor-widget__width-initial elementor-widget elementor-widget-image"
                            data-id="40ae0d4" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="72" height="63"
                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nien-profile.png"
                                     class="attachment-full size-full" alt="" loading="lazy" data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-f34411a elementor-widget__width-initial elementor-widget elementor-widget-counter"
                            data-id="f34411a" data-element_type="widget" data-widget_type="counter.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-counter">
                                    <div class="elementor-counter-number-wrapper">
                                        <span class="elementor-counter-number-prefix"></span>
                                        <span class="elementor-counter-number" data-duration="2000" data-to-value="25"
                                              data-from-value="0" data-delimiter=",">25</span>
                                        <span class="elementor-counter-number-suffix">M</span></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-96c3437 elementor-widget__width-initial elementor-widget elementor-widget-text-editor"
                            data-id="96c3437" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container"><p>Müşteri</p></div>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-a6f7f30 animated fadeInUp"
                    data-id="a6f7f30" data-element_type="column"
                    data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:300}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-1adef7e elementor-widget__width-initial elementor-widget elementor-widget-image"
                            data-id="1adef7e" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="70" height="63"
                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-bag.png"
                                     class="attachment-full size-full" alt="" loading="lazy" data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-e1beee8 elementor-widget__width-initial elementor-widget elementor-widget-counter"
                            data-id="e1beee8" data-element_type="widget" data-widget_type="counter.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-counter">
                                    <div class="elementor-counter-number-wrapper">
                                        <span class="elementor-counter-number-prefix"></span>
                                        <span class="elementor-counter-number" data-duration="2000" data-to-value="289"
                                              data-from-value="0" data-delimiter=",">289</span>
                                        <span class="elementor-counter-number-suffix"></span></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-528c6a3 elementor-widget__width-initial elementor-widget elementor-widget-text-editor"
                            data-id="528c6a3" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container"><p>Başarılı Proje</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-9e9830f elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="9e9830f" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-a070989"
                    data-id="a070989" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-2547c6d elementor-widget elementor-widget-heading animated fadeInUp"
                            data-id="2547c6d" data-element_type="widget"
                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                            data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default">İŞİNİZİ GÜÇLENDİRİN</span>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-87a5ee2 elementor-widget elementor-widget-heading animated fadeInUp"
                            data-id="87a5ee2" data-element_type="widget"
                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:150}"
                            data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h2
                                    class="elementor-heading-title elementor-size-default">
                                    İşinizin Büyümesi Için Neler Yapabiliriz

                                </h2></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-e3ceb88 elementor-widget elementor-widget-text-editor animated fadeInUp"
                            data-id="e3ceb88" data-element_type="widget"
                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                            data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                                Egestas dictum lectus diam commodo. Et tristique nunc faucibus sit tortor commodo
                                aliquet commodo quam. Id suspendisse vel in nocumsan.
                            </div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-4012b08 elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInUp"
                            data-id="4012b08" data-element_type="section"
                            data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:250}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-cb9a821"
                                    data-id="cb9a821" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b25e552 elementor-widget elementor-widget-image"
                                            data-id="b25e552" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="35" height="36"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/dotted-round-check.svg"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-000bf68"
                                    data-id="000bf68" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-3cbc816 elementor-widget elementor-widget-heading"
                                            data-id="3cbc816" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Günlük aktivitenizi takip edin.

                                                </h6></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-2fb415e elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInUp"
                            data-id="2fb415e" data-element_type="section"
                            data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:300}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-aafd00c"
                                    data-id="aafd00c" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-97d5dac elementor-widget elementor-widget-image"
                                            data-id="97d5dac" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="35" height="36"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/dotted-round-check.svg"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7de577a"
                                    data-id="7de577a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-3cdc148 elementor-widget elementor-widget-heading"
                                            data-id="3cdc148" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Küresel pazarlama stratejisi
                                                </h6></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-147cebd elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInUp"
                            data-id="147cebd" data-element_type="section"
                            data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:350}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-9281f08"
                                    data-id="9281f08" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-137d381 elementor-widget elementor-widget-image"
                                            data-id="137d381" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="35" height="36"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/dotted-round-check.svg"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-bc40fc8"
                                    data-id="bc40fc8" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-760eb94 elementor-widget elementor-widget-heading"
                                            data-id="760eb94" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Online Destek Ekibi
                                                </h6></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-005b2ad elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInUp"
                            data-id="005b2ad" data-element_type="section"
                            data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:400}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d7f4599"
                                    data-id="d7f4599" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-201c75a elementor-widget elementor-widget-image"
                                            data-id="201c75a" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="35" height="36"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/05/dotted-round-check.svg"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6fc014d"
                                    data-id="6fc014d" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-427681f elementor-widget elementor-widget-heading"
                                            data-id="427681f" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Online Yardım Ekibi
                                                </h6></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div
                    class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-11694e5"
                    data-id="11694e5" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-0f89054 animated-slow elementor-widget elementor-widget-image animated fadeIn"
                            data-id="0f89054" data-element_type="widget"
                            data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:300}"
                            data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img
                                    src="https://adventz.radiantthemes.com/wp-content/uploads/elementor/thumbs/demo-nine-section-4-main-img-7582ph3y6ummudslrf78txow3cvx6iudx1j72wkxn7e.png"
                                    title="demo-nine-section-4-main-img" alt="demo-nine-section-4-main-img"
                                    data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-c12e62c elementor-widget elementor-widget-image animated zoomIn"
                            data-id="c12e62c" data-element_type="widget"
                            data-settings="{&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:100}"
                            data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="506" height="465"
                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-4-side-img.png"
                                     class="attachment-full size-full" alt="" loading="lazy"
                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-4-side-img.png 506w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-4-side-img-300x276.png 300w"
                                     sizes="(max-width: 506px) 100vw, 506px" data-no-retina=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-11e82d3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="11e82d3" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5eb0672"
                    data-id="5eb0672" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-d5dd90d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="d5dd90d" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-282593a"
                                    data-id="282593a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-1ac56ef elementor-widget elementor-widget-heading animated fadeInUp"
                                            data-id="1ac56ef" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">İŞ İLERLEMESİ</span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-c5a153e elementor-widget elementor-widget-heading animated fadeInUp"
                                            data-id="c5a153e" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default">Yaratıcı Pazarlama Stratejisi Daha Fazla Iş Başarısı Elde Eder
                                                </h2></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-ac2bf6a"
                                    data-id="ac2bf6a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-452b920 elementor-widget elementor-widget-text-editor"
                                            data-id="452b920" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Egestas dictum lectus diam commodo. Et tristique nunc faucibus sit
                                                tortor commodo aliquet commodo quam. Id suspendisse vel in nocumsan.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-4859d71 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="4859d71" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-76a52d8"
                                    data-id="76a52d8" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-ec97270 elementor-widget elementor-widget-image animated fadeIn"
                                            data-id="ec97270" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:400}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="652" height="671"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-main-img.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-main-img.png 652w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-main-img-292x300.png 292w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-main-img-600x617.png 600w"
                                                     sizes="(max-width: 652px) 100vw, 652px" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-ce2ce75 elementor-widget__width-auto elementor-absolute elementor-hidden-mobile elementor-hidden-tablet elementor-widget elementor-widget-image animated zoomIn"
                                            data-id="ce2ce75" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="233" height="194"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-draw-megaphone.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-e387afb elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-image"
                                            data-id="e387afb" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="29" height="32"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-polygon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-c7d2ba4 elementor-widget__width-auto elementor-absolute elementor-hidden-mobile elementor-widget elementor-widget-image"
                                            data-id="c7d2ba4" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="15" height="15"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-circle.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-b361300 elementor-widget__width-auto elementor-absolute elementor-hidden-mobile elementor-widget elementor-widget-image animated zoomIn"
                                            data-id="b361300" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="144" height="144"
                                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-rocket.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-rocket.png 144w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-section-5-rocket-100x100.png 100w"
                                                     sizes="(max-width: 144px) 100vw, 144px" data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6b9b551"
                                    data-id="6b9b551" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-28ea863 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box animated fadeInUp"
                                            data-id="28ea863" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img"><img width="86" height="86"
                                                                                                 src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-discover.png"
                                                                                                 class="attachment-full size-full"
                                                                                                 alt="" loading="lazy"
                                                                                                 data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">
                                                            Yaratıcı Stratejiyi Keşfedin

                                                        </h5>
                                                        <p class="elementor-image-box-description">Feugiat Phasellus aut
                                                            ms varius laoreet srtrum aenean in lipsim imperdiet.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-0eeb553 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box animated fadeInUp"
                                            data-id="0eeb553" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img"><img width="86" height="86"
                                                                                                 src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-best-feature.png"
                                                                                                 class="attachment-full size-full"
                                                                                                 alt="" loading="lazy"
                                                                                                 data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title"> En Iyi Özellikler Geliştirme
                                                        </h5>
                                                        <p class="elementor-image-box-description">Feugiat Phasellus aut
                                                            ms varius laoreet srtrum aenean in lipsim imperdiet.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-82720df elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box animated fadeInUp"
                                            data-id="82720df" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:300}"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img width="86" height="86"
                                                             src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/demo-nine-solutionregeneratiing.png"
                                                             class="attachment-full size-full"
                                                             alt="" loading="lazy"
                                                             data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">solution &amp;
                                                            regenerating easily</h5>
                                                        <p class="elementor-image-box-description">Çözüm Ve Kolayca Yenilenme

                                                            ms varius laoreet srtrum aenean in lipsim imperdiet.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-project\evet\resources\views/index.blade.php ENDPATH**/ ?>