<?php $__env->startSection('title','Haberler'); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet"
          href="<?php echo e(asset('assets/wp-content/litespeed/css/6c771fb36b8b739154ed3e3b23d44849f15a.css?ver=76eeb')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wraper_blog_main style-one clasic-box-layout">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 order-lg-1 order-sm-1">
                    <div class="blog_main">
                        <div class="row blog-posts">
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="blog-item style-one post col-md-6">
                                    <div class="holder">
                                        <div class="pic">
                                            <a class="pic-main" href="<?php echo e(route('blog.detail',$row->slug)); ?>">
                                                <img src="<?php echo e(asset($row->image)); ?>" alt="<?php echo e($row->title); ?>" data-no-retina="">
                                            </a></div>
                                        <div class="data">
                                            <div class="post-meta">
                                                <span class="date"><?php echo e($row->created_at->format('d.m.Y H:i')); ?></span></div>
                                            <h4 class="title">
                                                <a href="<?php echo e(route('blog.detail',$row->slug)); ?>"><?php echo e($row->title); ?></a>
                                            </h4>
                                            <div class="entry-content"><p><?php echo e(str($row->detail)->stripTags()->limit(145)); ?></p>
                                                <div class="entry-extra-item text-left">
                                                    <div class="post-read-more">
                                                        <a class="btn" href="<?php echo e(route('blog.detail',$row->slug)); ?>" data-hover="Devamını Oku"><span>Devamını Oku</span></a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="pagination clearfix">
<!--                        <span class="page-numbers current">1</span>
                        <a class="page-numbers" href="page/2/index.html">2</a>
                        <a class="next page-numbers" href="page/2/index.html"><span class="lnr lnr-arrow-right"></span></a>-->
                        <?php echo $blogs->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/blog/index.blade.php ENDPATH**/ ?>