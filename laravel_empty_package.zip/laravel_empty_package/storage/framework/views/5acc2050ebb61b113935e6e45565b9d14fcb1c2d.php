<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
    <div class="brand-logo">
        <a href="<?php echo e(route('admin.home')); ?>">
            <img src="/backend/images/logo-icon.png" class="logo-icon" alt="logo icon">
            <h5 class="logo-text">İstanbul Yazılım</h5>
        </a>
    </div>
    <ul class="sidebar-menu do-nicescrol">
        <li class="sidebar-header">Menü</li>

        <li <?php if(request()->routeIs('admin.home')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.home')); ?>"><i
                    class="zmdi zmdi-star-outline"></i> Anasayfa</a></li>

        <li <?php if(request()->routeIs('admin.project-request.*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.project-request.index')); ?>"><i
                    class="zmdi zmdi-star-outline"></i> Girişim Talepleri</a></li>

        <li <?php if(request()->routeIs('admin.slider.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.slider.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Slider İşlemleri</span> <i
                    class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.slider.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Slider Listesi</a></li>
                <li><a href="<?php echo e(route('admin.slider.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Slider Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.blog.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.blog.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Blog İşlemleri</span> <i
                    class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.blog.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Blog Listesi</a></li>
                <li><a href="<?php echo e(route('admin.blog.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Blog Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.page.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.page.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Sayfa İşlemleri</span> <i
                    class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.page.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Sayfa Listesi</a></li>
                <li><a href="<?php echo e(route('admin.page.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Sayfa Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.faq.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.faq.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>S.S.S</span> <i
                    class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.faq.index')); ?>"><i class="zmdi zmdi-star-outline"></i> S.S.S Listesi</a></li>
                <li><a href="<?php echo e(route('admin.faq.create')); ?>"><i class="zmdi zmdi-star-outline"></i> S.S.S Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.portfolio.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.portfolio.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Portföy İşlemleri</span> <i
                    class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.portfolio.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Portföy Listesi</a></li>
                <li><a href="<?php echo e(route('admin.portfolio.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Portföy Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.user.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.user.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Kullanıcı İşlemleri</span> <i
                    class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.user.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Kullanıcı Listesi</a></li>
                <li><a href="<?php echo e(route('admin.user.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Kullanıcı Ekle</a></li>
            </ul>
        </li>


        <li <?php if(request()->routeIs('admin.contact.index')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.contact.index')); ?>"><i
                    class="zmdi zmdi-view-dashboard"></i> İletişim Mesajları</a></li>

        <li <?php if(request()->routeIs('admin.settings')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.settings')); ?>"><i
                    class="zmdi zmdi-view-dashboard"></i> Ayarlar</a></li>

        <li><a href="<?php echo e(route('admin.logout')); ?>"><i class="zmdi zmdi-star-outline"></i>Çıkış Yap</a></li>
    </ul>

</div>
<?php /**PATH D:\xampp\htdocs\girisim\resources\views/admin/layouts/menu.blade.php ENDPATH**/ ?>