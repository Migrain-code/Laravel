<div id="header" class="rt-dark rt-submenu-light">
    <div class="rt-header-inner">
        <div data-elementor-type="section" data-elementor-id="36630" class="elementor elementor-36630">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-ee87697 elementor-section-full_width elementor-section-stretched header-one header-eight elementor-section-height-default elementor-section-height-default"
                data-id="ee87697" data-element_type="section"
                data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                <div class="elementor-container elementor-column-gap-default">
                    <div
                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8236e64"
                        data-id="8236e64" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                                class="elementor-element elementor-element-f37d053 elementor-widget elementor-widget-radiant-header_custom_menu"
                                data-id="f37d053" data-element_type="widget"
                                data-widget_type="radiant-header_custom_menu.default">
                                <div class="elementor-widget-container">

                                    <!-- =================================================================  Fixed Navbar =============================================-->
                                    <?php echo $__env->make('layout.navs.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!-- =================================================================  Fixed Navbar End =============================================-->

                                    <!-- =================================================================  Static Navbar =============================================-->
                                    <?php echo $__env->make('layout.navs.desktop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!-- =================================================================  Static Navbar End=============================================-->

                                    <!-- =================================================================  Mobil Navbar =============================================-->
                                    <?php echo $__env->make('layout.navs.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!-- ================================================================= Mobil Navbar End=============================================-->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\girisim\resources\views/layout/navbar.blade.php ENDPATH**/ ?>