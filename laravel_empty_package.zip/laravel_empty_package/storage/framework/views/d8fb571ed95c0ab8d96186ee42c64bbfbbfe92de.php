<?php if(session()->has('message')): ?>
    <div class="my-4 border px-4 py-4 mx-4 text-sm font-light rounded text <?php if(session()->get('message')['type'] == 'success'): ?> text-green-700 bg-green-200 border-green-400 <?php else: ?> text-red-700 bg-red-200 border-red-400 <?php endif; ?>">
        <?php echo session()->get('message')['message']; ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\girisim\vendor\rezaamini-ir\migrator\src/../resources/views/message.blade.php ENDPATH**/ ?>