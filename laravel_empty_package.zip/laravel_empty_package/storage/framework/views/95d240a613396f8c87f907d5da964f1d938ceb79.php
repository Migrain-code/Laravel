<header class="rt-header mobile-header-style3 style3hover fixed">
    <div class="rt-header-holder mobile-logo-column">
        <div class="menu-icon rt-mobile-hamburger rt-column hidden-lg">
            <div class="rt-mobile-toggle-holder">
                <div class="rt-mobile-toggle">
                    <span></span><span></span><span></span></div>
            </div>
        </div>
        <div class="logo-holder">
            <div class="logo radiantthemes-retina"><a
                    href="<?php echo e(route('home')); ?>">
                    <span class="logo-default test-retina-three">
                        <img alt="logo" src="<?php echo e(asset(config('settings.logo'))); ?>" width="161" height="30">
                                 </span>
                </a>
            </div>
        </div>
        <!-- ================================================================= Sticky Navbar =============================================-->
        <div class="rt-navbar-menu menu-center-sticky">
            <nav
                class="apr-nav-menu--main apr-nav-menu--layout-horizontal hover-underline e--pointer-none">
                <ul id="menu-main-menu" class="mega-menu">
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="<?php echo e(route('home')); ?>" data-description="">Anasayfa<span
                                class="arrow"></span></a>
                    </li>
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5342 rt-dropdown">
                        <a href="#" data-description="">
                            Bize Ulaşın
                            <span class="arrow">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                     width="16" height="16"
                                     viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor"
                                     stroke-width="1.5"
                                     stroke-linecap="round"
                                     stroke-linejoin="round"
                                     class="feather feather-chevron-down">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </span>
                        </a>
                        <ul class="sub-menu  menu-odd  menu-depth-1">
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="<?php echo e(route('about')); ?>" data-description="">
                                    Hakkımızda
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="1.5" stroke-linecap="round"
                                             stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="<?php echo e(route('contact')); ?>" data-description="">
                                    İletişim
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="1.5" stroke-linecap="round"
                                             stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="<?php echo e(route('sss')); ?>" data-description="">
                                    SSS
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="1.5" stroke-linecap="round"
                                             stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>

                        </ul>
                    </li>

                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="<?php echo e(route('portfolio')); ?>" data-description="">Portföy<span
                                class="arrow"></span></a>
                    </li>

                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="#" data-description="">Yatırımcı<span
                                class="arrow"></span></a>
                    </li>
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="<?php echo e(route('home')); ?>" data-description="">Girişimci<span
                                class="arrow"></span></a>
                    </li>
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="<?php echo e(route('blog.index')); ?>" data-description="">Haberler<span
                                class="arrow"></span></a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- ================================================================= Sticky Navbar End=============================================-->

        <div class="rt-search-cart-holder">
            <div class="rt-search-cart-inner-holder"></div>
        </div>
        <div class="rt-right-menu-holder">
            <?php if(auth('promoter')->check()): ?>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button" ><a
                            class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                            href="<?php echo e(route('promoter.home')); ?>"><span>Panelim</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button "><a onclick="$('#logout-form').submit()"
                                                                      class="radiantthemes-menu-custom-button-main" style="padding: 10px;border: 1px solid #0d66c2"
                                                                      href="javascript:void(0)"><span>Çıkış Yap</span></a>
                    </div>
                </div>
                <form id="logout-form" method="post" action="<?php echo e(route('promoter.logout')); ?>"><?php echo csrf_field(); ?></form>
            <?php elseif(auth('investor')->check()): ?>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button" ><a
                                class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                                href="<?php echo e(route('investor.home')); ?>"><span>Panelim</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button "><a onclick="$('#logout-form').submit()"
                                                                      class="radiantthemes-menu-custom-button-main" style="padding: 10px;border: 1px solid #0d66c2"
                                                                      href="javascript:void(0)"><span>Çıkış Yap</span></a>
                    </div>
                </div>
                <form id="logout-form" method="post" action="<?php echo e(route('investor.logout')); ?>"><?php echo csrf_field(); ?></form>
            <?php else: ?>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button" ><a
                                class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                                href="<?php echo e(route('investor.login')); ?>"><span>Yatırımcı</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button" ><a
                            class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                            href="<?php echo e(route('promoter.login')); ?>"><span>Girişimci</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button "><a
                            class="radiantthemes-menu-custom-button-main" style="padding: 10px;border: 1px solid #0d66c2"
                            href="<?php echo e(route('register')); ?>"><span>Kayıt Ol</span></a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH /home/istanbulyazilim/public_html/girisimphp/resources/views/layout/navs/fixed.blade.php ENDPATH**/ ?>