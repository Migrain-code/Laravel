<?php $__env->startSection('title','Girişimci | Giriş Yap'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wraper_blog_main default-page">
        <div class="container page-container">
            <article id="post-2568" class="entry post-2568 page type-page status-publish hentry">
                <header class="entry-header">
                </header>
                <div class="entry-content">
                    <h2 class="entry-title">Girişimci Girişi</h2> <div class="woocommerce"><div class="woocommerce-notices-wrapper"></div>
                        <form class="woocommerce-form woocommerce-form-login login p-5" action="<?php echo e(route('promoter.login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                <label for="username">E-Posta Adresi&nbsp;<span class="required">*</span></label>
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="username" value="<?php echo e(old('email')); ?>"> </p>
                            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                <label for="password">Şifre&nbsp;<span class="required">*</span></label>
                                <span class="password-input">
                                    <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password">
                                </span>
                            </p>
                            <p class="form-row">
                                <button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="Log in">Giriş Yap</button>
                            </p>
                            <p class="woocommerce-LostPassword lost_password">
                                <a href="">Şifremi Unuttum</a>
                            </p>
                        </form>
                    </div>
                </div>
            </article>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/resources/views/promoter/auth/login.blade.php ENDPATH**/ ?>