<!-- Bootstrap core JavaScript-->
<script src="/backend/js/jquery.min.js"></script>
<script src="/backend/js/popper.min.js"></script>
<script src="/backend/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="/backend/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="/backend/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="/backend/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="/backend/js/app-script.js"></script>
<!-- Chart js -->
<script src="/backend/plugins/Chart.js/Chart.min.js"></script>
<!--Peity Chart -->
<script src="/backend/plugins/peity/jquery.peity.min.js"></script>
<!-- Index js -->
<!--<script src="/assets/js/index.js"></script>-->

<!--Data Tables js-->
<script src="/backend/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="/backend/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

<script>
    let csrf_token = '<?php echo e(csrf_token()); ?>';
</script>

<script src="/backend/js/custom.js?v=<?php echo e(time()); ?>"></script>

<?php echo $__env->yieldContent('page-scripts'); ?>
<?php /**PATH /home/istanbulyazilim/public_html/girisimphp/resources/views/admin/layouts/scripts.blade.php ENDPATH**/ ?>