</div>
</div>
<footer class="wraper_footer custom-footer">
    <div data-elementor-type="section" data-elementor-id="37333" class="elementor elementor-37333">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-f1c174b elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="f1c174b" data-element_type="section"
            data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-612681e"
                    data-id="612681e" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-aab0627 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="aab0627" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-14349fb footer-col"
                                    data-id="14349fb" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-d0a3d4d elementor-widget elementor-widget-image"
                                            data-id="d0a3d4d" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="162" height="30"
                                                     src="../wp-content/uploads/2022/06/white.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-5ab2fb3 elementor-widget elementor-widget-heading"
                                            data-id="5ab2fb3" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Vitae porttitor sapien nam ac. Tristique duis ultrices in elementum senectus mi non elementum.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-bd48ae6 footer-col"
                                    data-id="bd48ae6" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-0e4c45d elementor-widget elementor-widget-heading"
                                            data-id="0e4c45d" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Support</h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-932d924 elementor-widget elementor-widget-heading"
                                            data-id="932d924" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/contact/">Forum
                                                        Support</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4a1d69a elementor-widget elementor-widget-heading"
                                            data-id="4a1d69a" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/faq/">Help & FAQ
                                                    </a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-17c6739 elementor-widget elementor-widget-heading"
                                            data-id="17c6739" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/contact/">Contact Us</a>
                                                </p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4e64182 elementor-widget elementor-widget-heading"
                                            data-id="4e64182" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/pricing-plans/">Pricing
                                                        & Plans</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-6021d27 elementor-widget elementor-widget-heading"
                                            data-id="6021d27" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="#">Cookie Policy</a></p></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-965b857 footer-col"
                                    data-id="965b857" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-510c174 elementor-widget elementor-widget-heading"
                                            data-id="510c174" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Company</h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-97cc124 elementor-widget elementor-widget-heading"
                                            data-id="97cc124" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="index.html">About Us</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-7111ee8 elementor-widget elementor-widget-heading"
                                            data-id="7111ee8" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/my-account/">My
                                                        Account</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-0c3f87d elementor-widget elementor-widget-heading"
                                            data-id="0c3f87d" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/our-company/">Our
                                                        Company</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-382aa68 elementor-widget elementor-widget-heading"
                                            data-id="382aa68" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="https://adventz.radiantthemes.com/service/">Service</a>
                                                </p></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-0dc4407 footer-col"
                                    data-id="0dc4407" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b59c3d0 elementor-widget elementor-widget-heading"
                                            data-id="b59c3d0" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">Get In
                                                    Touch</h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-858a807 elementor-icon-list--layout-inline addrs-footer-two elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="858a807" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                    <span class="elementor-icon-list-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="17" viewBox="0 0 14 17" fill="none"><path
                                                            d="M13.3584 7.13636C13.3584 11.9091 7.1792 16 7.1792 16C7.1792 16 1 11.9091 1 7.13636C1 5.5089 1.65102 3.94809 2.80985 2.7973C3.96867 1.64651 5.54037 1 7.1792 1C8.81803 1 10.3897 1.64651 11.5486 2.7973C12.7074 3.94809 13.3584 5.5089 13.3584 7.13636Z"
                                                            stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path><path
                                                            d="M7.17927 9.18173C8.31683 9.18173 9.239 8.26595 9.239 7.13627C9.239 6.0066 8.31683 5.09082 7.17927 5.09082C6.04171 5.09082 5.11954 6.0066 5.11954 7.13627C5.11954 8.26595 6.04171 9.18173 7.17927 9.18173Z"
                                                            stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path></svg> </span>
                                                        <span class="elementor-icon-list-text">121 King St, Melbourne VIC, 3000,Australia</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-b367810 elementor-icon-list--layout-inline addrs-footer-two elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="b367810" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <span class="elementor-icon-list-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path
                                                                d="M8.55268 11.4968C10.2211 11.4968 11.5736 10.1537 11.5736 8.49682C11.5736 6.83997 10.2211 5.49683 8.55268 5.49683C6.88426 5.49683 5.53174 6.83997 5.53174 8.49682C5.53174 10.1537 6.88426 11.4968 8.55268 11.4968Z"
                                                                stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path><path
                                                                d="M11.5733 5.49953V9.24953C11.5733 9.84627 11.812 10.4186 12.2369 10.8405C12.6618 11.2625 13.2381 11.4995 13.839 11.4995C14.4399 11.4995 15.0162 11.2625 15.4411 10.8405C15.866 10.4186 16.1047 9.84627 16.1047 9.24953V8.49953C16.1046 6.8068 15.5279 5.16389 14.4683 3.83793C13.4088 2.51197 11.9287 1.58095 10.2687 1.19626C8.6088 0.811562 6.86662 0.995816 5.3255 1.71906C3.78438 2.4423 2.53494 3.662 1.78036 5.17982C1.02577 6.69765 0.810417 8.42433 1.16931 10.0791C1.5282 11.7339 2.44022 13.2195 3.75709 14.2942C5.07396 15.369 6.71822 15.9698 8.42251 15.9989C10.1268 16.028 11.7909 15.4837 13.1442 14.4545"
                                                                stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path></svg> </span>
                                                        <span class="elementor-icon-list-text"><a
                                                                href="https://adventz.radiantthemes.com/cdn-cgi/l/email-protection"
                                                                class="__cf_email__"
                                                                data-cfemail="1e777078715e7b667f736e727b307d7173">[email&#160;protected]</a> </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-7876669 elementor-icon-list--layout-inline addrs-footer-two elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="7876669" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                    <span class="elementor-icon-list-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path
                                                            d="M16.0743 12.2304V14.4885C16.0752 14.6981 16.0319 14.9056 15.9474 15.0977C15.8628 15.2898 15.7388 15.4622 15.5832 15.6039C15.4277 15.7456 15.244 15.8535 15.0441 15.9207C14.8441 15.9878 14.6322 16.0128 14.422 15.9939C12.0896 15.7422 9.84922 14.9508 7.88081 13.6831C6.04946 12.5274 4.49679 10.9855 3.33308 9.16689C2.05211 7.20324 1.25495 4.96756 1.00615 2.64096C0.987211 2.43282 1.01212 2.22303 1.0793 2.02497C1.14647 1.82691 1.25444 1.6449 1.39632 1.49055C1.53821 1.33619 1.7109 1.21287 1.90341 1.12843C2.09592 1.04398 2.30403 1.00027 2.51448 1.00007H4.78835C5.15619 0.996478 5.5128 1.12583 5.79171 1.36403C6.07061 1.60222 6.25278 1.93301 6.30426 2.29472C6.40024 3.01736 6.57823 3.72691 6.83483 4.40981C6.93681 4.67922 6.95888 4.97202 6.89843 5.2535C6.83798 5.53498 6.69754 5.79336 6.49375 5.99801L5.53115 6.95394C6.61014 8.83837 8.18131 10.3986 10.0789 11.4702L11.0415 10.5142C11.2476 10.3118 11.5078 10.1724 11.7912 10.1123C12.0746 10.0523 12.3695 10.0742 12.6408 10.1755C13.3285 10.4303 14.0429 10.6071 14.7706 10.7024C15.1388 10.754 15.4751 10.9381 15.7155 11.2199C15.9558 11.5016 16.0835 11.8612 16.0743 12.2304Z"
                                                            stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path></svg> </span>
                                                        <span class="elementor-icon-list-text">+1 (888) 123 4567</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-7398d57 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="7398d57" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4f00c68 footer-col-copyright"
                                    data-id="4f00c68" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-9fbb9b4 elementor-icon-list--layout-inline elementor-align-left elementor-tablet-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="9fbb9b4" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <span class="elementor-icon-list-icon">
                                                        <i aria-hidden="true" class="far fa-copyright"></i> </span>
                                                        <span class="elementor-icon-list-text">Copyright 2022<strong> İstanbulyazılım.com</strong></span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-34538dc footer-col-copyright"
                                    data-id="34538dc" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-56fcc1f elementor-icon-list--layout-inline elementor-align-right elementor-tablet-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="56fcc1f" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <a href="#"><span class="elementor-icon-list-text">Terms & Condition</span>
                                                        </a></li>
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <a href="#"><span
                                                                class="elementor-icon-list-text">Careers</span>
                                                        </a></li>
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <a href="#"><span class="elementor-icon-list-text">Privacy Policy</span>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
</footer>
</div>
<script data-cfasync="false" src="<?php echo e(asset('assets/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js')); ?>"></script>
<script>jQuery(document).ready(function ($) {
        $(document).on('click', '.plus', function (e) { // replace '.quantity' with document (without single quote)
            $input = $(this).prev('input.qty');
            var val = parseInt($input.val());
            var step = $input.attr('step');
            step = 'undefined' !== typeof (step) ? parseInt(step) : 1;
            $input.val(val + step).change();
        });
        $(document).on('click', '.minus',  // replace '.quantity' with document (without single quote)
            function (e) {
                $input = $(this).next('input.qty');
                var val = parseInt($input.val());
                var step = $input.attr('step');
                step = 'undefined' !== typeof (step) ? parseInt(step) : 1;
                if (val > 0) {
                    $input.val(val - step).change();
                }
            });
    });</script>
<script type="text/javascript">(function () {
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
    })();</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/53d76ed6fef9fc0d10e22704ddf135d9f423.js?ver=da491')); ?>'
        id='regenerator-runtime-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/afe284ffb0c1bc7cb7d3a4058afca64491b9.js?ver=f9992')); ?>'
        id='wp-polyfill-js'></script>
<script id='contact-form-7-js-extra'>var wpcf7 = {
        "api": {
            "root": "https:\/\/adventz.radiantthemes.com\/wp-json\/",
            "namespace": "contact-form-7\/v1"
        }, "cached": "1"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/96e6dfd27ddc2227039b4c97d96580c08781.js?ver=efe3d')); ?>'
        id='contact-form-7-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/726ef093ac7783763fb4be55e0a9a6c6351b.js?ver=55906')); ?>'
        id='jquery-blockui-js'></script>
<script id='wc-add-to-cart-js-extra'>var wc_add_to_cart_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "i18n_view_cart": "View cart",
        "cart_url": "https:\/\/adventz.radiantthemes.com\/cart\/",
        "is_cart": "",
        "cart_redirect_after_add": "no"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/9171701589e9fec0cddab703bedb7ea4f7dc.js?ver=aba1a')); ?>'
        id='wc-add-to-cart-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/3a290701a12896a384b0af7fb06faa59386c.js?ver=a8c97')); ?>'
        id='js-cookie-js'></script>
<script id='woocommerce-js-extra'>var woocommerce_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/624b9acd1c70d0fae35e65ac20ce99557667.js?ver=b809a')); ?>'
        id='woocommerce-js'></script>
<script id='wc-cart-fragments-js-extra'>var wc_cart_fragments_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "cart_hash_key": "wc_cart_hash_dbcb07ad4bd340567cad98451cf1a8f1",
        "fragment_name": "wc_fragments_dbcb07ad4bd340567cad98451cf1a8f1",
        "request_timeout": "5000"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/435309a4c7b0247b7bb9c2804ffc11917d7a.js?ver=43498')); ?>'
        id='wc-cart-fragments-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/c57259bee3cb7b833f5d8519107d3bef85aa.js?ver=df029')); ?>'
        id='adventz-custom-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/7330fd891f5b23370f5b25aa7cce8dd0dbfb.js?ver=b41a3')); ?>'
        id='swiper-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/04435fc4b23b426257b0464ffadc7e403318.js?ver=e46b2')); ?>'
        id='popper-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/4319fad931b41531fa3bc7ddb110e8dc364c.js?ver=1d34e')); ?>'
        id='bootstrap-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ce1f66f3e7929deb23ba1426d0951f8979a4.js?ver=67a8c')); ?>'
        id='vendor-menu-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/bcaaa8176d48f4cbb0fd14363ef74a526d1b.js?ver=91435')); ?>'
        id='underscore-js'></script>
<script id='wp-util-js-extra'>var _wpUtilSettings = {"ajax": {"url": "\/wp-admin\/admin-ajax.php"}};</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/b68017d9ce3759fb5e57a2e10525cb10241c.js?ver=44ef5')); ?>

        id='wp-util-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/5df0a1960883b9ff6d686224c6b67e1cc82e.js?ver=719ab')); ?>'
        id='adventz-app-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/d6ad2092f98b7afcd637cf1c57d437055f46.js?ver=b9b5b')); ?>'
        id='adventz-vertical-menu-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ab3b987cac59044e250cd479254d17a35715.js?ver=b4077')); ?>'
        id='jquery-matchheight-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/d773d01513206f15a9750f7bd06a95a2a8c1.js?ver=87365')); ?>'
        id='popup-video-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/61ed8508f7389591a237bc184caac7ea84a5.js?ver=e118a')); ?>'
        id='fancy-box-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/92529f94b83b88136b23bfc1cc1bfe6e6591.js?ver=4ef67')); ?>'
        id='sweetalert-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/7af1e075a6b4214534043128fd14a6c31471.js?ver=4bcc2')); ?>'
        id='ajax_add_to_cart-js'></script>
<script id='wc-add-to-cart-variation-js-extra'>var wc_add_to_cart_variation_params = {
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "i18n_no_matching_variations_text": "Sorry, no products matched your selection. Please choose a different combination.",
        "i18n_make_a_selection_text": "Please select some product options before adding this product to your cart.",
        "i18n_unavailable_text": "Sorry, this product is unavailable. Please choose a different combination."
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ad24f54091a861d93c24f399336e7370d8b5.js?ver=b68b1')); ?>

        id='wc-add-to-cart-variation-js'></script>
<script id='woo-variation-swatches-js-extra'>var woo_variation_swatches_options = {
        "is_product_page": "",
        "show_variation_label": "1",
        "variation_label_separator": ":",
        "wvs_nonce": "3357bc0602"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/a919b4c1e71d166104df4180e2ca344bcd0e.js?ver=aebef')); ?>'
        id='woo-variation-swatches-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/e1251313d3239b69cefd5ddaca8e1c46d989.js?ver=d38c6')); ?>'
        id='radiantthemes-addons-core-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/77a3c99ae5860dbb207cf5289fa0c90b4bd6.js?ver=4eb76')); ?>'
        id='radiantthemes-addons-custom-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ea90c9b2258f68de55964bae72a48549c114.js?ver=25540')); ?>'
        id='rt-vertical-menu-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/3968e3da9962d8d238a7a398defbe4d26188.js?ver=072df')); ?>'
        id='jquery-numerator-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ff1e375ae2ff605d9ed1cc938161a8d571f2.js?ver=abea9')); ?>'
        id='radiantthemes-client-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/dbd5021631b8884a9c2d0e2b98c84b16f93a.js?ver=27aef')); ?>'
        id='elementor-webpack-runtime-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/2aea062fc71a1e15353056a9a17d83f41282.js?ver=c5856')); ?>'
        id='elementor-frontend-modules-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/a7bd526cb51e5e8e8730904e30147171f3de.js?ver=be65b')); ?>'
        id='elementor-waypoints-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/87276c38fa53782ba8bb1861f2c102dba483.js?ver=3c974')); ?>'
        id='jquery-ui-core-js'></script>
<script id='elementor-frontend-js-before'>var elementorFrontendConfig = {
        "environmentMode": {"edit": false, "wpPreview": false, "isScriptDebug": false},
        "i18n": {
            "shareOnFacebook": "Share on Facebook",
            "shareOnTwitter": "Share on Twitter",
            "pinIt": "Pin it",
            "download": "Download",
            "downloadImage": "Download image",
            "fullscreen": "Fullscreen",
            "zoom": "Zoom",
            "share": "Share",
            "playVideo": "Play Video",
            "previous": "Previous",
            "next": "Next",
            "close": "Close"
        },
        "is_rtl": false,
        "breakpoints": {"xs": 0, "sm": 480, "md": 768, "lg": 1025, "xl": 1440, "xxl": 1600},
        "responsive": {
            "breakpoints": {
                "mobile": {
                    "label": "Mobile",
                    "value": 767,
                    "default_value": 767,
                    "direction": "max",
                    "is_enabled": true
                },
                "mobile_extra": {
                    "label": "Mobile Extra",
                    "value": 880,
                    "default_value": 880,
                    "direction": "max",
                    "is_enabled": false
                },
                "tablet": {
                    "label": "Tablet",
                    "value": 1024,
                    "default_value": 1024,
                    "direction": "max",
                    "is_enabled": true
                },
                "tablet_extra": {
                    "label": "Tablet Extra",
                    "value": 1200,
                    "default_value": 1200,
                    "direction": "max",
                    "is_enabled": true
                },
                "laptop": {
                    "label": "Laptop",
                    "value": 1366,
                    "default_value": 1366,
                    "direction": "max",
                    "is_enabled": true
                },
                "widescreen": {
                    "label": "Widescreen",
                    "value": 2400,
                    "default_value": 2400,
                    "direction": "min",
                    "is_enabled": false
                }
            }
        },
        "version": "3.6.7",
        "is_static": false,
        "experimentalFeatures": {
            "e_dom_optimization": true,
            "e_optimized_assets_loading": true,
            "e_optimized_css_loading": true,
            "a11y_improvements": true,
            "e_import_export": true,
            "additional_custom_breakpoints": true,
            "e_hidden_wordpress_widgets": true,
            "landing-pages": true,
            "elements-color-picker": true,
            "favorite-widgets": true,
            "admin-top-bar": true
        },
        "urls": {"assets": "https:\/\/adventz.radiantthemes.com\/wp-content\/plugins\/elementor\/assets\/"},
        "settings": {"page": [], "editorPreferences": []},
        "kit": {
            "active_breakpoints": ["viewport_mobile", "viewport_tablet", "viewport_tablet_extra", "viewport_laptop"],
            "global_image_lightbox": "yes",
            "lightbox_enable_counter": "yes",
            "lightbox_enable_fullscreen": "yes",
            "lightbox_enable_zoom": "yes",
            "lightbox_enable_share": "yes",
            "lightbox_title_src": "title",
            "lightbox_description_src": "description"
        },
        "post": {"id": 36153, "title": "About%20Us%20%E2%80%93%20Adventz", "excerpt": "", "featuredImage": false}
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/6425641c4ec00ecdb0a04a624b2923df66eb.js?ver=e444b')); ?>'
        id='elementor-frontend-js'></script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\Laravel-project\evet\resources\views/layout/footer.blade.php ENDPATH**/ ?>