<div id="header" class="rt-dark rt-submenu-light">
    <div class="rt-header-inner">
        <div data-elementor-type="section" data-elementor-id="36630" class="elementor elementor-36630">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-ee87697 elementor-section-full_width elementor-section-stretched header-one header-eight elementor-section-height-default elementor-section-height-default"
                data-id="ee87697" data-element_type="section"
                data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                <div class="elementor-container elementor-column-gap-default">
                    <div
                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8236e64"
                        data-id="8236e64" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                                class="elementor-element elementor-element-f37d053 elementor-widget elementor-widget-radiant-header_custom_menu"
                                data-id="f37d053" data-element_type="widget"
                                data-widget_type="radiant-header_custom_menu.default">
                                <div class="elementor-widget-container">

                                    <header class="rt-header  mobile-header-style3 style3hover fixed">
                                        <div class="rt-header-holder mobile-logo-column">
                                            <div class="menu-icon rt-mobile-hamburger rt-column hidden-lg">
                                                <div class="rt-mobile-toggle-holder">
                                                    <div class="rt-mobile-toggle">
                                                        <span></span><span></span><span></span></div>
                                                </div>
                                            </div>
                                            <div class="logo-holder">
                                                <div class="logo radiantthemes-retina"><a
                                                        href=""><span
                                                            class="logo-default test-retina-three">
                                                            <!--
                                                            <img alt="logo"
                                                                 src=""
                                                                 srcset=""
                                                                 width="161"
                                                                 height="30">
                                                                 -->
                                                                 <h4>Logo</h4>
                                                                 </span>
                                                                 </a>
                                                </div>
                                            </div>
                                            <!-- ================================================================= Sticky Navbar =============================================-->
                                            <div class="rt-navbar-menu menu-center-sticky">
                                                <nav
                                                    class="apr-nav-menu--main apr-nav-menu--layout-horizontal hover-underline e--pointer-none">
                                                    <ul id="menu-main-menu" class="mega-menu">
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('home')); ?>" data-description="">Anasayfa<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('contact')); ?>" data-description="">Hakkkında<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('contact')); ?>" data-description="">İletişim<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('portfoy')); ?>" data-description="">Portföy<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('faq')); ?>" data-description="">SSS<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="#" data-description="">Yatırımcı<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('home')); ?>" data-description="">Girişimci<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('news')); ?>" data-description="">Haberler<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                            <!-- ================================================================= Sticky Navbar End=============================================-->

                                            <div class="rt-search-cart-holder">
                                                <div class="rt-search-cart-inner-holder"></div>
                                            </div>
                                            <div class="rt-right-menu-holder">
                                                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                                                    <div class="radiantthemes-menu-custom-button" ><a
                                                            class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                                                            href="<?php echo e(route('login')); ?>"><span>Giriş Yap</span></a>
                                                    </div>

                                                </div>
                                                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                                                    <div class="radiantthemes-menu-custom-button "><a
                                                            class="radiantthemes-menu-custom-button-main" style="padding: 10px;border: 1px solid #0d66c2"
                                                            href="<?php echo e(route('register')); ?>"><span>Kayıt Ol</span></a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </header>
                                    <!-- =================================================================  Static Navbar =============================================-->
                                    <header class="rt-header logo-left  style3 mobile-header-style1" style="background-color: #f1f6ff">
                                        <div class="rt-header-holder mobile-logo-column">
                                            <div
                                                class="menu-icon rt-mobile-hamburger rt-column hidden-lg visible-md visible-sm visible-xs">
                                                <div class="rt-mobile-toggle-holder">
                                                    <div class="rt-mobile-toggle">
                                                        <span></span><span></span><span></span></div>
                                                </div>
                                            </div>
                                            <div class="logo-holder">
                                                <div class="logo radiantthemes-retina"><a
                                                        href=""><span
                                                            class="logo-default test-retina-three">
                                                            <!--
                                                            <img alt="logo"
                                                                                                        src="wp-content/uploads/2022/06/donen1logo.svg"
                                                                                                        srcset="wp-content/uploads/2022/06/donen1logo.svg 1x, wp-content/uploads/2022/06/donen1logo.svg 2x"
                                                                                                        width="161"
                                                                                                        height="30">
                                                            -->
                                                            <h4>Logo</h4>
                                                                                                        </span>
                                                                                                        </a>
                                                </div>
                                            </div>
                                            <div class="rt-navbar-menu menu-center">
                                                <nav
                                                    class="apr-nav-menu--main apr-nav-menu--layout-horizontal hover-underline e--pointer-none">
                                                    <ul id="menu-main-menu-1" class="mega-menu">
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('home')); ?>" data-description="">Anasayfa<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('about')); ?>" data-description="">Hakkında<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('contact')); ?>" data-description="">İletişim<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('portfoy')); ?>" data-description="">Portföy<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('faq')); ?>" data-description="">SSS<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="#" data-description="">Yatırımcı<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('home')); ?>" data-description="">Girişimci<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                        <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <a href="<?php echo e(route('news')); ?>" data-description="">Haberler<span
                                                                    class="arrow"></span></a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                            <div class="rt-search-cart-holder"></div>
                                            <div class="rt-right-menu-holder">
                                                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                                                    <div class="radiantthemes-menu-custom-button" ><a
                                                            class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                                                            href="<?php echo e(route('login')); ?>"><span>Giriş Yap</span></a>
                                                    </div>

                                                </div>
                                                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                                                    <div class="radiantthemes-menu-custom-button "><a
                                                            class="radiantthemes-menu-custom-button-main" style="padding: 10px;border: 1px solid #0d66c2"
                                                            href="<?php echo e(route('register')); ?>"><span>Kayıt Ol</span></a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </header>
                                    <!-- =================================================================  Static Navbar End=============================================-->

                                    <!-- =================================================================  Mobil Navbar =============================================-->

                                    <nav id="mobile-menu" class="side-panel">
                                        <header class="side-panel-header">
                                        <span>
                                        <img alt="logo"
                                             src="wp-content/uploads/2022/06/donen1logo.svg"
                                             srcset="wp-content/uploads/2022/06/donen1logo.svg 1x, wp-content/uploads/2022/06/donen1logo.svg 2x"
                                             width="161" height="30"> </span>
                                            <div class="rt-toggle-close rt-close-btn" title="Close">
                                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0" y="0"
                                                     width="12" height="12" viewBox="1.1 1.1 12 12"
                                                     enable-background="new 1.1 1.1 12 12" xml:space="preserve"><path
                                                        d="M8.3 7.1l4.6-4.6c0.3-0.3 0.3-0.8 0-1.2 -0.3-0.3-0.8-0.3-1.2 0L7.1 5.9 2.5 1.3c-0.3-0.3-0.8-0.3-1.2 0 -0.3 0.3-0.3 0.8 0 1.2L5.9 7.1l-4.6 4.6c-0.3 0.3-0.3 0.8 0 1.2s0.8 0.3 1.2 0L7.1 8.3l4.6 4.6c0.3 0.3 0.8 0.3 1.2 0 0.3-0.3 0.3-0.8 0-1.2L8.3 7.1z"></path></svg>
                                            </div>
                                        </header>
                                        <div class="side-panel-inner mobile-side-panel-inner">
                                            <div class="mobile-menu-top">
                                                <ul id="menu-main-menu-2" class="rt-mobile-menu">
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="<?php echo e(route('home')); ?>" data-description="">Anasayfa</a>
                                                    </li>
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="<?php echo e(route('about')); ?>" data-description="">Hakkında</a>
                                                    </li>
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="<?php echo e(route('contact')); ?>" data-description="">İletişim</a>
                                                    </li>
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="<?php echo e(route('portfoy')); ?>" data-description="">Portföy</a>
                                                    </li>
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="<?php echo e(route('faq')); ?>" data-description="">SSS</a>
                                                    </li>
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="#" data-description="">Yatırımcı</a>
                                                    </li>
                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                        <a href="<?php echo e(route('home')); ?>" data-description="">Girişimci</a>
                                                    </li>

                                                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                                                            <div class="radiantthemes-menu-custom-button" style="margin:15px auto">
                                                                <a
                                                                    class="radiantthemes-menu-custom-button-main" style="padding:10px;background-color: #0d66c2;color:white"
                                                                    href="<?php echo e(route('login')); ?>"><span>Giriş Yap</span></a>
                                                                <a
                                                                    class="radiantthemes-menu-custom-button-main" style="padding:10px;border:1px solid #0d66c2;"
                                                                    href="<?php echo e(route('register')); ?>"><span>Kayıt Ol</span></a>
                                                            </div>
                                                    </li>

                                                </ul>
                                                <div class="rt-search-cart-holder"></div>
                                            </div>
                                        </div>
                                    </nav>
                                    <!-- ================================================================= MobilNavbar End=============================================-->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php /**PATH /home/istanbulyazilim/public_html/girisim/resources/views/components/navbar.blade.php ENDPATH**/ ?>