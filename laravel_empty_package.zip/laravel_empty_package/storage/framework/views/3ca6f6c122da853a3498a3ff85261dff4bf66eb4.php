<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <script data-optimized="1" src="<?php echo e(asset('assets/wp-content/plugins/litespeed-cache/assets/js/webfontloader.min.js')); ?>"></script>
    <link data-optimized="2" rel="stylesheet" href="<?php echo e(asset('assets/wp-content/litespeed/css/ffb315fce0927bf36187c64a96fdf266b4b8.css?ver=d9e91')); ?>"/>
    <?php echo $__env->yieldContent('links'); ?>
    <script src='<?php echo e(asset('assets/wp-includes/js/jquery/jquery.minaf6c.js?ver=3.6.0')); ?>' id='jquery-core-js'></script>
    <script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/b74d23edc46548c55a05ee2e03b8c09a01b3.js?ver=5920e')); ?>' id='jquery-migrate-js'></script>
    <noscript>
        <style>.woocommerce-product-gallery {
                opacity: 1 !important;
            }</style>
    </noscript>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>

</head>
<body class="page-template page-template-elementor_header_footer page page-id-36153 wp-embed-responsive theme-adventz woocommerce-no-js woo-variation-swatches wvs-theme-adventz wvs-theme-child-adventz wvs-style-rounded wvs-attr-behavior-blur wvs-tooltip wvs-css wvs-show-label radiantthemes radiantthemes-adventz elementor-default elementor-template-full-width elementor-kit-6 elementor-page elementor-page-36153">
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script data-cfasync="false" src="<?php echo e(asset('assets/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js')); ?>"></script>
<script>jQuery(document).ready(function ($) {
        $(document).on('click', '.plus', function (e) { // replace '.quantity' with document (without single quote)
            $input = $(this).prev('input.qty');
            var val = parseInt($input.val());
            var step = $input.attr('step');
            step = 'undefined' !== typeof (step) ? parseInt(step) : 1;
            $input.val(val + step).change();
        });
        $(document).on('click', '.minus',  // replace '.quantity' with document (without single quote)
            function (e) {
                $input = $(this).next('input.qty');
                var val = parseInt($input.val());
                var step = $input.attr('step');
                step = 'undefined' !== typeof (step) ? parseInt(step) : 1;
                if (val > 0) {
                    $input.val(val - step).change();
                }
            });
    });</script>
<script type="text/javascript">(function () {
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
    })();</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/53d76ed6fef9fc0d10e22704ddf135d9f423.js?ver=da491')); ?>'
        id='regenerator-runtime-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/afe284ffb0c1bc7cb7d3a4058afca64491b9.js?ver=f9992')); ?>'
        id='wp-polyfill-js'></script>
<script id='contact-form-7-js-extra'>var wpcf7 = {
        "api": {
            "root": "https:\/\/adventz.radiantthemes.com\/wp-json\/",
            "namespace": "contact-form-7\/v1"
        }, "cached": "1"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/96e6dfd27ddc2227039b4c97d96580c08781.js?ver=efe3d')); ?>'
        id='contact-form-7-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/726ef093ac7783763fb4be55e0a9a6c6351b.js?ver=55906')); ?>'
        id='jquery-blockui-js'></script>
<script id='wc-add-to-cart-js-extra'>var wc_add_to_cart_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "i18n_view_cart": "View cart",
        "cart_url": "https:\/\/adventz.radiantthemes.com\/cart\/",
        "is_cart": "",
        "cart_redirect_after_add": "no"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/9171701589e9fec0cddab703bedb7ea4f7dc.js?ver=aba1a')); ?>'
        id='wc-add-to-cart-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/3a290701a12896a384b0af7fb06faa59386c.js?ver=a8c97')); ?>'
        id='js-cookie-js'></script>
<script id='woocommerce-js-extra'>var woocommerce_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/624b9acd1c70d0fae35e65ac20ce99557667.js?ver=b809a')); ?>'
        id='woocommerce-js'></script>
<script id='wc-cart-fragments-js-extra'>var wc_cart_fragments_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "cart_hash_key": "wc_cart_hash_dbcb07ad4bd340567cad98451cf1a8f1",
        "fragment_name": "wc_fragments_dbcb07ad4bd340567cad98451cf1a8f1",
        "request_timeout": "5000"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/435309a4c7b0247b7bb9c2804ffc11917d7a.js?ver=43498')); ?>'
        id='wc-cart-fragments-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/c57259bee3cb7b833f5d8519107d3bef85aa.js?ver=df029')); ?>'
        id='adventz-custom-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/7330fd891f5b23370f5b25aa7cce8dd0dbfb.js?ver=b41a3')); ?>'
        id='swiper-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/04435fc4b23b426257b0464ffadc7e403318.js?ver=e46b2')); ?>'
        id='popper-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/4319fad931b41531fa3bc7ddb110e8dc364c.js?ver=1d34e')); ?>'
        id='bootstrap-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ce1f66f3e7929deb23ba1426d0951f8979a4.js?ver=67a8c')); ?>'
        id='vendor-menu-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/bcaaa8176d48f4cbb0fd14363ef74a526d1b.js?ver=91435')); ?>'
        id='underscore-js'></script>
<script id='wp-util-js-extra'>var _wpUtilSettings = {"ajax": {"url": "\/wp-admin\/admin-ajax.php"}};</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/b68017d9ce3759fb5e57a2e10525cb10241c.js?ver=44ef5')); ?>

    id='wp-util-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/5df0a1960883b9ff6d686224c6b67e1cc82e.js?ver=719ab')); ?>'
        id='adventz-app-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/d6ad2092f98b7afcd637cf1c57d437055f46.js?ver=b9b5b')); ?>'
        id='adventz-vertical-menu-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ab3b987cac59044e250cd479254d17a35715.js?ver=b4077')); ?>'
        id='jquery-matchheight-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/d773d01513206f15a9750f7bd06a95a2a8c1.js?ver=87365')); ?>'
        id='popup-video-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/61ed8508f7389591a237bc184caac7ea84a5.js?ver=e118a')); ?>'
        id='fancy-box-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/92529f94b83b88136b23bfc1cc1bfe6e6591.js?ver=4ef67')); ?>'
        id='sweetalert-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/7af1e075a6b4214534043128fd14a6c31471.js?ver=4bcc2')); ?>'
        id='ajax_add_to_cart-js'></script>
<script id='wc-add-to-cart-variation-js-extra'>var wc_add_to_cart_variation_params = {
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "i18n_no_matching_variations_text": "Sorry, no products matched your selection. Please choose a different combination.",
        "i18n_make_a_selection_text": "Please select some product options before adding this product to your cart.",
        "i18n_unavailable_text": "Sorry, this product is unavailable. Please choose a different combination."
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ad24f54091a861d93c24f399336e7370d8b5.js?ver=b68b1')); ?>

    id='wc-add-to-cart-variation-js'></script>
<script id='woo-variation-swatches-js-extra'>var woo_variation_swatches_options = {
        "is_product_page": "",
        "show_variation_label": "1",
        "variation_label_separator": ":",
        "wvs_nonce": "3357bc0602"
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/a919b4c1e71d166104df4180e2ca344bcd0e.js?ver=aebef')); ?>'
        id='woo-variation-swatches-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/e1251313d3239b69cefd5ddaca8e1c46d989.js?ver=d38c6')); ?>'
        id='radiantthemes-addons-core-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/77a3c99ae5860dbb207cf5289fa0c90b4bd6.js?ver=4eb76')); ?>'
        id='radiantthemes-addons-custom-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ea90c9b2258f68de55964bae72a48549c114.js?ver=25540')); ?>'
        id='rt-vertical-menu-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/3968e3da9962d8d238a7a398defbe4d26188.js?ver=072df')); ?>'
        id='jquery-numerator-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/ff1e375ae2ff605d9ed1cc938161a8d571f2.js?ver=abea9')); ?>'
        id='radiantthemes-client-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/dbd5021631b8884a9c2d0e2b98c84b16f93a.js?ver=27aef')); ?>'
        id='elementor-webpack-runtime-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/2aea062fc71a1e15353056a9a17d83f41282.js?ver=c5856')); ?>'
        id='elementor-frontend-modules-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/a7bd526cb51e5e8e8730904e30147171f3de.js?ver=be65b')); ?>'
        id='elementor-waypoints-js'></script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/87276c38fa53782ba8bb1861f2c102dba483.js?ver=3c974')); ?>'
        id='jquery-ui-core-js'></script>
<script id='elementor-frontend-js-before'>var elementorFrontendConfig = {
        "environmentMode": {"edit": false, "wpPreview": false, "isScriptDebug": false},
        "i18n": {
            "shareOnFacebook": "Share on Facebook",
            "shareOnTwitter": "Share on Twitter",
            "pinIt": "Pin it",
            "download": "Download",
            "downloadImage": "Download image",
            "fullscreen": "Fullscreen",
            "zoom": "Zoom",
            "share": "Share",
            "playVideo": "Play Video",
            "previous": "Previous",
            "next": "Next",
            "close": "Close"
        },
        "is_rtl": false,
        "breakpoints": {"xs": 0, "sm": 480, "md": 768, "lg": 1025, "xl": 1440, "xxl": 1600},
        "responsive": {
            "breakpoints": {
                "mobile": {
                    "label": "Mobile",
                    "value": 767,
                    "default_value": 767,
                    "direction": "max",
                    "is_enabled": true
                },
                "mobile_extra": {
                    "label": "Mobile Extra",
                    "value": 880,
                    "default_value": 880,
                    "direction": "max",
                    "is_enabled": false
                },
                "tablet": {
                    "label": "Tablet",
                    "value": 1024,
                    "default_value": 1024,
                    "direction": "max",
                    "is_enabled": true
                },
                "tablet_extra": {
                    "label": "Tablet Extra",
                    "value": 1200,
                    "default_value": 1200,
                    "direction": "max",
                    "is_enabled": true
                },
                "laptop": {
                    "label": "Laptop",
                    "value": 1366,
                    "default_value": 1366,
                    "direction": "max",
                    "is_enabled": true
                },
                "widescreen": {
                    "label": "Widescreen",
                    "value": 2400,
                    "default_value": 2400,
                    "direction": "min",
                    "is_enabled": false
                }
            }
        },
        "version": "3.6.7",
        "is_static": false,
        "experimentalFeatures": {
            "e_dom_optimization": true,
            "e_optimized_assets_loading": true,
            "e_optimized_css_loading": true,
            "a11y_improvements": true,
            "e_import_export": true,
            "additional_custom_breakpoints": true,
            "e_hidden_wordpress_widgets": true,
            "landing-pages": true,
            "elements-color-picker": true,
            "favorite-widgets": true,
            "admin-top-bar": true
        },
        "urls": {"assets": "https:\/\/adventz.radiantthemes.com\/wp-content\/plugins\/elementor\/assets\/"},
        "settings": {"page": [], "editorPreferences": []},
        "kit": {
            "active_breakpoints": ["viewport_mobile", "viewport_tablet", "viewport_tablet_extra", "viewport_laptop"],
            "global_image_lightbox": "yes",
            "lightbox_enable_counter": "yes",
            "lightbox_enable_fullscreen": "yes",
            "lightbox_enable_zoom": "yes",
            "lightbox_enable_share": "yes",
            "lightbox_title_src": "title",
            "lightbox_description_src": "description"
        },
        "post": {"id": 36153, "title": "About%20Us%20%E2%80%93%20Adventz", "excerpt": "", "featuredImage": false}
    };</script>
<script data-optimized="1" src='<?php echo e(asset('assets/wp-content/litespeed/js/6425641c4ec00ecdb0a04a624b2923df66eb.js?ver=e444b')); ?>'
        id='elementor-frontend-js'></script>
</body>
</html>


<?php /**PATH /home/istanbulyazilim/public_html/girisimphp/resources/views/layout/master.blade.php ENDPATH**/ ?>