<nav id="mobile-menu" class="side-panel">
    <header class="side-panel-header">
        <span>
            <img alt="logo" src="<?php echo e(asset(config('settings.logo'))); ?>" width="161" height="30">
         </span>
        <div class="rt-toggle-close rt-close-btn" title="Close">
            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0" y="0"
                 width="12" height="12" viewBox="1.1 1.1 12 12"
                 enable-background="new 1.1 1.1 12 12" xml:space="preserve"><path
                    d="M8.3 7.1l4.6-4.6c0.3-0.3 0.3-0.8 0-1.2 -0.3-0.3-0.8-0.3-1.2 0L7.1 5.9 2.5 1.3c-0.3-0.3-0.8-0.3-1.2 0 -0.3 0.3-0.3 0.8 0 1.2L5.9 7.1l-4.6 4.6c-0.3 0.3-0.3 0.8 0 1.2s0.8 0.3 1.2 0L7.1 8.3l4.6 4.6c0.3 0.3 0.8 0.3 1.2 0 0.3-0.3 0.3-0.8 0-1.2L8.3 7.1z"></path></svg>
        </div>
    </header>
    <div class="side-panel-inner mobile-side-panel-inner">
        <div class="mobile-menu-top">
            <ul id="menu-main-menu-2" class="rt-mobile-menu">
                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="<?php echo e(route('home')); ?>" data-description="">Anasayfa</a>
                </li>

                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="<?php echo e(route('about')); ?>" data-description="">Hakkında</a>
                </li>
                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="<?php echo e(route('contact')); ?>" data-description="">İletişim</a>
                </li>
                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="<?php echo e(route('portfolio')); ?>" data-description="">Portföy</a>
                </li>
                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="<?php echo e(route('sss')); ?>" data-description="">SSS</a>
                </li>
                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="#" data-description="">Yatırımcı</a>
                </li>
                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <a href="<?php echo e(route('home')); ?>" data-description="">Girişimci</a>
                </li>

                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                    <?php if(auth('promoter')->check()): ?>
                        <div class="radiantthemes-menu-custom-button" style="margin:15px auto">
                            <a
                                class="radiantthemes-menu-custom-button-main"
                                style="padding:10px;background-color: #0d66c2;color:white"
                                href="<?php echo e(route('promoter.login')); ?>"><span>Panelim</span></a>
                            <a onclick="$('#logout-form').submit()"
                               class="radiantthemes-menu-custom-button-main"
                               style="padding:10px;border:1px solid #0d66c2;"
                               href="javascript:void(0)"><span>Çıkış Yap</span></a>
                        </div>

                        <form id="logout-form" method="post"
                              action="<?php echo e(auth('promoter')->check() ? route('promoter.logout') : route('promoter.logout')); ?>"><?php echo csrf_field(); ?></form>
                    <?php else: ?>
                        <div class="radiantthemes-menu-custom-button d-flex flex-column" style="margin:15px auto">
                            <div class="mb-4 mt-3">
                                <a
                                    class="radiantthemes-menu-custom-button-main"
                                    style="padding:10px;background-color: #0d66c2;color:white"
                                    href="<?php echo e(route('promoter.login')); ?>"><span>Girişimci</span></a>
                                <a
                                    class="radiantthemes-menu-custom-button-main"
                                    style="padding:10px;background-color: #461acb;color:white"
                                    href="<?php echo e(route('promoter.login')); ?>"><span>Yatırımcı</span></a>
                            </div>
                            <div class="mt-3">
                                <a onclick="$('#logout-form').submit()"
                                   class="radiantthemes-menu-custom-button-main mb-4"
                                   style="padding:10px;border:1px solid #0d66c2;"
                                   href="<?php echo e(route('register')); ?>"><span>Kayıt Ol</span></a>
                            </div>
                        </div>
                    <?php endif; ?>
                </li>

            </ul>
            <div class="rt-search-cart-holder"></div>
        </div>
    </div>
</nav>
<?php /**PATH /home/istanbulyazilim/public_html/girisimphp/resources/views/layout/navs/mobile.blade.php ENDPATH**/ ?>