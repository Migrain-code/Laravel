<?php $__env->startSection('title',$projectRequest->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Girişim Talepleri</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Girişim Talepleri</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Girişim Talepleri</li>
                    </ol>
                </div>
            </div>
            <!-- End Breadcrumb-->


            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title text-success">Girişim Talebi Bilgileri</div>
                            <div class="alert alert-<?php echo e($projectRequest->status == 2 ? 'danger' : 'info'); ?>  px-4 py-3">
                                <b>Başvuru Tarihi:</b> <?php echo e($projectRequest->created_at->format('d.m.Y H:i')); ?><br>
                                <b>Başvuru Durumu:</b> <?php echo e($projectRequest->getStatus('text')); ?><br>
                                <?php if($projectRequest->status == 2): ?>
                                    <b>Ret Nedeni:</b> <?php echo e($projectRequest->admin_message); ?><br>
                                <?php endif; ?>
                            </div>
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="form-group col-md-6 col-12">
                                        <label for="name">Project Adı</label>
                                        <input type="text" disabled name="name" value="<?php echo e($projectRequest->name); ?>"
                                               class="form-control" id="name">
                                    </div>
                                    <div class="form-group col-md-6 col-12">
                                        <label for="website">Websitesi</label>
                                        <input type="text" disabled name="website" value="<?php echo e($projectRequest->website); ?>"
                                               class="form-control" id="website">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12 col-12">
                                        <label for="short_detail">Girşimin kısaca tanımı</label>
                                        <textarea type="text" disabled name="short_detail" class="form-control"
                                                  id="short_detail" cols="60"
                                                  rows="5"><?php echo e($projectRequest->short_detail); ?></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-12 col-md-6">
                                        <label for="mission">Girişimdeki Göreviniz</label>
                                        <select name="mission[]" disabled class="form-control" multiple id="mission">
                                            <option
                                                    <?php if(in_array(
                                            'Kurucu',$projectRequest->mission)): echo 'selected'; endif; ?> value="Kurucu">
                                            Kurucu
                                            </option>
                                            <option
                                                    <?php if(in_array(
                                            'Kurucu Ortağı',$projectRequest->mission)): echo 'selected'; endif; ?> value="Kurucu Ortağı">
                                            Kurucu Ortağı
                                            </option>
                                            <option
                                                    <?php if(in_array(
                                            'Çalışan',$projectRequest->mission)): echo 'selected'; endif; ?> value="Çalışan">
                                            Çalışan
                                            </option>
                                        </select>
                                    </div>
                                    <div class="form-group col-12 col-md-6">
                                        <label for="purpose">Girişimin Yapım Amacı</label>
                                        <select name="purpose[]" disabled class="form-control" multiple id="purpose">
                                            <option <?php if(in_array(
                                            'Fikir',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Fikir">
                                            Fikir
                                            </option>
                                            <option
                                                    <?php if(in_array(
                                            'Prototip',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Prototip">
                                            Prototip
                                            </option>
                                            <option
                                                    <?php if(in_array(
                                            'Kullanılabilir',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Kullanılabilir">
                                            Kullanılabilir
                                            </option>
                                            <option
                                                    <?php if(in_array(
                                            'Kullanılıyor',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Kullanılıyor">
                                            Kullanılıyor
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4 col-12">
                                        <label for="degree">Girişimdeki Ünvanınız</label>
                                        <input type="text" disabled class="form-control" name="degree"
                                               value="<?php echo e($projectRequest->degree); ?>" id="degree"/>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="start_month">Projeye Ne Zaman Başladınız (Ay)</label>
                                        <select name="start_month" disabled="" class="form-control" id="start_month">
                                            <option value="01" <?php if($projectRequest->start_month == '01'): echo 'selected'; endif; ?>>01
                                            </option>
                                            <option value="02" <?php if($projectRequest->start_month == '02'): echo 'selected'; endif; ?>>02
                                            </option>
                                            <option value="03" <?php if($projectRequest->start_month == '03'): echo 'selected'; endif; ?>>03
                                            </option>
                                            <option value="04" <?php if($projectRequest->start_month == '04'): echo 'selected'; endif; ?>>04
                                            </option>
                                            <option value="05" <?php if($projectRequest->start_month == '05'): echo 'selected'; endif; ?>>05
                                            </option>
                                            <option value="06" <?php if($projectRequest->start_month == '06'): echo 'selected'; endif; ?>>06
                                            </option>
                                            <option value="07" <?php if($projectRequest->start_month == '07'): echo 'selected'; endif; ?>>07
                                            </option>
                                            <option value="08" <?php if($projectRequest->start_month == '08'): echo 'selected'; endif; ?>>08
                                            </option>
                                            <option value="09" <?php if($projectRequest->start_month == '09'): echo 'selected'; endif; ?>>09
                                            </option>
                                            <option value="10" <?php if($projectRequest->start_month == '10'): echo 'selected'; endif; ?>>10
                                            </option>
                                            <option value="11" <?php if($projectRequest->start_month == '11'): echo 'selected'; endif; ?>>11
                                            </option>
                                            <option value="12" <?php if($projectRequest->start_month == '12'): echo 'selected'; endif; ?>>12
                                            </option>
                                        </select>
                                    </div>
                                    <div class="form-group col-12 col-md-4">
                                        <label for="start_year">Projeye Ne Zaman Başladınız (Yıl)</label>
                                        <select name="start_year" disabled class="form-control" id="start_year">
                                            <?php for($i=now()->year-20;$i<=now()->year;$i++): ?>
                                                <option
                                                        value="<?php echo e($i); ?>" <?php if($projectRequest->start_year ==
                                                    $i): echo 'selected'; endif; ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-6 col-12">
                                        <label for="biography">KISA BİYOGRAFİ/ KENDİNİZİ TANITINIZ </label>
                                        <textarea type="text" disabled class="form-control" name="biography"
                                                  id="biography" cols="60" rows="10"
                                                  style="width: 100%;resize: none"><?php echo e($projectRequest->biography); ?></textarea>
                                    </div>
                                    <div class="form-group col-md-6 col-12">
                                        <label for="detail">NEDEN BAŞVURMAK İSTİYORSUNUZ ?</label>
                                        <textarea type="text" disabled class="form-control" name="cause" id="detail"
                                                  cols="60" rows="10"
                                                  style="width: 100%;resize: none"><?php echo e($projectRequest->cause); ?></textarea>
                                    </div>

                                    <div class="form-group col-12">
                                        <label for="detail">GİRİŞİM HAKKINDA ÖZET BİLGİ VERİNİZ </label>
                                        <textarea type="text" disabled class="form-control" name="detail" id="detail"
                                                  cols="60" rows="10"
                                                  style="width: 100%;resize: none"><?php echo e($projectRequest->detail); ?></textarea>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">

                                                <div class="row">
                                                    <?php if($projectRequest->video): ?>
                                                        <a type="button" href="<?php echo e(asset($projectRequest->video)); ?>"
                                                           target="_blank" class="btn btn-primary mr-3 text-white">Videoyu
                                                            Göster</a>
                                                    <?php endif; ?>
                                                    <?php if($projectRequest->slide): ?>
                                                        <a type="button" href="<?php echo e(asset($projectRequest->slide)); ?>"
                                                           target="_blank" class="btn btn-primary mr-3 text-white">Sunumu
                                                            Göster</a>
                                                    <?php endif; ?>
                                                    <?php if($projectRequest->document): ?>
                                                        <a type="button" href="<?php echo e(asset($projectRequest->document)); ?>"
                                                           target="_blank" class="btn btn-primary text-white">Belgeyi
                                                            Göster</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="form-group mt-3">
                                    <?php if($projectRequest->status == 0): ?>
                                        <a href="<?php echo e(route('admin.project-request.approve',$projectRequest->id)); ?>"
                                           class="btn btn-success btn-round shadow-success px-5">Onayla </a>
                                        <a href="<?php echo e(route('admin.project-request.reject',$projectRequest->id)); ?>"
                                           class="btn btn-danger btn-round shadow-danger px-5">Reddet </a>
                                    <?php endif; ?>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Row-->


        </div>
        <!-- End container-fluid-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/admin/project-request/show.blade.php ENDPATH**/ ?>