<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('content'); ?>
    <div class="wraper_blog_main style-one clasic-box-layout" style="padding-top: 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 blog-content">
                    <div class="blog_single">
                        <article id="post-5643" class="single-post post-5643 post type-post status-publish format-standard has-post-thumbnail hentry category-business category-design category-technology tag-design">
                            <div class="entry-blog-content">
                                <div class="post-meta">
                                    <header class="entry-header"><h2 class="entry-title"><?php echo e($title); ?></h2></header>
                                </div>
                            </div>
                            <div class="entry-main">
                                <div class="entry-content default-page">
                                    <div data-elementor-type="wp-post" data-elementor-id="5643" class="elementor elementor-5643">
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-2287f72d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="2287f72d"
                                            data-element_type="section"
                                        >
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5c32e669" data-id="5c32e669" data-element_type="column">
                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                        <section
                                                            class="elementor-section elementor-inner-section elementor-element elementor-element-2e5dbead elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                            data-id="2e5dbead"
                                                            data-element_type="section"
                                                        >
                                                            <div class="elementor-container elementor-column-gap-default">
                                                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-57b0f6e7" data-id="57b0f6e7" data-element_type="column">
                                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                                        <div
                                                                            class="elementor-element elementor-element-771fb3e4 elementor-widget elementor-widget-text-editor"
                                                                            data-id="771fb3e4"
                                                                            data-element_type="widget"
                                                                            data-widget_type="text-editor.default"
                                                                        >
                                                                            <div class="elementor-widget-container">
                                                                                <?php echo $detail; ?>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </section>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </article>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/detail-page.blade.php ENDPATH**/ ?>