<?php $__env->startSection('title',$project->name); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet"
          href="<?php echo e(asset('assets/wp-content/litespeed/css/d9606e2bbe5e87b3fe42a224ec1a16fbcd5d.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div data-elementor-type="wp-page" data-elementor-id="4950" class="elementor elementor-4950">
        <style>
        .elementor-4950 .elementor-element.elementor-element-6b50823 {
            padding: 118px 40px;
            z-index: 2;
            background: #f1fbff;
            margin: 30px 142px;
            border-radius: 54px;
          }
          .elementor-4950 .elementor-element.elementor-element-6b50823 {
              margin: 0px 142px;
              border-radius: 54px;
          }
          .elementor-4950 .elementor-element.elementor-element-242badc5 {
              background: #f1fbff;
              margin: 121px 142px;
              border-radius: 54px;
            }
        </style>
        <section
                class="elementor-section elementor-top-section elementor-element elementor-element-0cf6f9d elementor-section-boxed elementor-section-height-default mt-5 mb-2 elementor-section-height-default"
                data-id="0cf6f9d" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-fead6e9"
                     data-id="fead6e9" data-element_type="column"
                     data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-background-overlay"></div>
                        <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-7c35a51 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="7c35a51" data-element_type="section">
                            <div class="elementor-background-overlay"></div>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-0503eb0"
                                     data-id="0503eb0" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-a09cad4 elementor-widget elementor-widget-heading animated fadeInUp"
                                             data-id="a09cad4" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Proje Detayları</span>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-6b2c5bc elementor-widget elementor-widget-heading animated fadeInUp"
                                             data-id="6b2c5bc" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5>Proje Adı </h5><h2
                                                        class="elementor-heading-title elementor-size-default">
                                                      <?php echo e($project->name); ?>

                                                      </h2></div>
                                        </div>
                                        <div class="elementor-element elementor-element-ff547e6 elementor-widget elementor-widget-text-editor animated fadeInUp"
                                             data-id="ff547e6" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container"><p><h5>Proje detayı:</h5><br> <?php echo e($project->detail); ?></p>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-0056fb2 animated-slow animated fadeIn"
                                     data-id="0056fb2" data-element_type="column"
                                     data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:400}">

                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <img src="<?php echo e(asset($project->cover_image)); ?>" style="border-radius:15px">
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
                class="elementor-section elementor-top-section elementor-element elementor-element-6b50823 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="6b50823" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-5e19fdb"
                     data-id="5e19fdb" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-a8db983 elementor-widget elementor-widget-heading animated fadeInUp"
                             data-id="a8db983" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:50}"
                             data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default">Proje Hakkında</span></div>
                        </div>
                        <div class="elementor-element elementor-element-2a4e7ea elementor-widget elementor-widget-heading animated fadeInUp"
                             data-id="2a4e7ea" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                             data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h2
                                        class="elementor-heading-title elementor-size-default"><?php echo e($project->cause); ?></h2></div>
                        </div>
                        <div class="elementor-element elementor-element-06ed078 elementor-widget elementor-widget-text-editor animated fadeInUp"
                             data-id="06ed078" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:150}"
                             data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                                <?php echo e($project->short_detail); ?>

                            </div>
                        </div>
                        <div class="elementor-element elementor-element-29d5df9 elementor-widget elementor-widget-radiant-custom-button animated fadeInUp"
                             data-id="29d5df9" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200,&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                             data-widget_type="radiant-custom-button.default">
                            <div class="elementor-widget-container">
                                <div class="radiantthemes-custom-button element-one hover-style-five  "
                                     data-button-direction="" data-button-fullwidth="false"
                                     data-button-icon-position="">
                                     <?php if($project->interests()->where('investor_id',auth('investor')->id())->exists()): ?>
                                         <div class="elementor-widget-container alert alert-success" style="margin:15px 15px;text-align: center">
                                             Bu girişim ile ilgileniyorsunuz
                                         </div>
                                     <?php else: ?>
                                       <a class="radiantthemes-custom-button-main"
                                           href="<?php echo e(route('project.interest',$project->id)); ?>"
                                           target="_blank" rel="nofollow">
                                          <div class="placeholder">İlgileniyorum</div>
                                      </a>
                                     <?php endif; ?>

                                  </div>
                            </div>
                        </div>
                    </div>
                </div>
                <style>
                    .purposeTitle{
                      color: #fb5850;
                      font-family: "Outfit",Sans-serif;
                      font-size: 17px;
                      font-weight: 500;
                      text-transform: uppercase;
                      line-height: 15px;
                      letter-spacing: 1.76px;
                    }
                    .elementor-4950 .elementor-element.elementor-element-e47bcb4 {
                        margin-top: 24px;
                        margin-bottom: 0;

                        padding: 0 0 15px;
                    }
                </style>
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ad1e101"
                     data-id="ad1e101" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-widget-container">
                        <span class="purposeTitle" style="margin-bottom:30px">Projenin Yapım Amaçları</span>
                      </div>
                        <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-e47bcb4 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="e47bcb4" data-element_type="section" style="">

                            <div class="w-100">

                              <?php $__currentLoopData = $project->purpose; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purpose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-e32dee5 animated fadeInUp" style="float:left;margin-bottom:10px"
                                   data-id="e32dee5" data-element_type="column"
                                   data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:100}">
                                  <div class="elementor-widget-wrap elementor-element-populated">
                                      <div class="elementor-element elementor-element-ee42a31 elementor-widget elementor-widget-image"
                                           data-id="ee42a31" data-element_type="widget"
                                           data-widget_type="image.default">
                                          <div class="elementor-widget-container">
                                              <img width="70" height="70"
                                                   src="/assets/wp-content/uploads/2022/06/creative-ideas-svg-noshadow.png"
                                                   class="attachment-full size-full" alt="" loading="lazy"
                                                   data-no-retina=""></div>
                                      </div>
                                      <div class="elementor-element elementor-element-97ee0a2 elementor-widget elementor-widget-heading"
                                           data-id="97ee0a2" data-element_type="widget"
                                           data-widget_type="heading.default">
                                          <div class="elementor-widget-container">
                                            <h5 class="elementor-heading-title elementor-size-default">
                                              <?php echo e($purpose); ?>

                                            </h5>
                                          </div>
                                      </div>
                                      <div class="elementor-element elementor-element-8fb122f elementor-widget elementor-widget-text-editor"
                                           data-id="8fb122f" data-element_type="widget"
                                           data-widget_type="text-editor.default">

                                      </div>
                                  </div>
                              </div>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </section>

                    </div>
                </div>
            </div>
        </section>

        <section
                class="elementor-section elementor-top-section elementor-element elementor-element-242badc5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="242badc5" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7a21c00"
                     data-id="7a21c00" data-element_type="column"
                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-966a16b animated-slow elementor-widget elementor-widget-image animated fadeIn"
                             data-id="966a16b" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:400}"
                             data-widget_type="image.default">
                            <div class="elementor-widget-container">
                              <?php if($project->video!=""): ?>
                              <video width="774" height="686"
                                   src="<?php echo e(asset($project->video)); ?>"
                                   autoplay loop muted
                                   class="attachment-full size-full" alt="" loading="lazy"></video>
                              <?php else: ?>
                              <div class="elementor-widget-container alert alert-info" style="margin:15px 15px;text-align: center">
                                Proje videosu bulunamadı.
                              </div>
                              <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-6b7de123"
                     data-id="6b7de123" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-a5e83c3 elementor-widget elementor-widget-heading animated fadeInUp"
                             data-id="a5e83c3" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                             data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default">Biyografi</span>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-40fcb29 elementor-widget elementor-widget-heading animated fadeInUp"
                             data-id="40fcb29" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:150}"
                             data-widget_type="heading.default">
                            <div class="elementor-widget-container"></div>
                        </div>
                        <div class="elementor-element elementor-element-23072bb elementor-widget elementor-widget-text-editor animated fadeInUp"
                             data-id="23072bb" data-element_type="widget"
                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                             data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                                <?php echo e($project->biography); ?>

                            </div>
                        </div>
                        <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-cd2cb33 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="cd2cb33" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default" style="float: left;margin-left: -86px;">
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-cab53e2"
                                     data-id="cab53e2" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-829a0f5 elementor-widget elementor-widget-image"
                                             data-id="829a0f5" data-element_type="widget"
                                             data-widget_type="image.default">
                                                  <span class="purposeTitle">
                                                    Slide
                                                    <div class="radiantthemes-menu-custom-button">
                                                      <a class="radiantthemes-menu-custom-button-main" href="<?php echo e(asset($project->slide)); ?>" target="_blank" style="border-radius: 15px;font-size: 0.7rem;padding:10px;background-color: #0d66c2;color:white" href="">
                                                        <span>Göster</span>
                                                      </a>
                                                    </div>
                                                  </span><br>
                                        </div>
                                        <div class="elementor-element elementor-element-829a0f5 elementor-widget elementor-widget-image"
                                             data-id="829a0f5" data-element_type="widget"
                                             data-widget_type="image.default">
                                                  <span class="purposeTitle">
                                                    Dosya
                                                    <div class="radiantthemes-menu-custom-button">
                                                      <a class="radiantthemes-menu-custom-button-main" href="<?php echo e(asset($project->document)); ?>" target="_blank" style="border-radius: 15px;font-size: 0.7rem;padding:10px;background-color: #0d66c2;color:white" href="">
                                                        <span>Göster</span>
                                                      </a>
                                                    </div>
                                                  </span><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/project/detail.blade.php ENDPATH**/ ?>