<?php $__env->startSection('title','Ayarlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Ayarlar</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Haber Listesi</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Ayarlar</li>
                    </ol>
                </div>
            </div>
            <!-- End Breadcrumb-->


            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title text-success">Ayarlar</div>
                            <form action="" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="name">Site Başlığı</label>
                                        <input type="text" class="form-control form-control-rounded" name="title" value="<?php echo e(config('settings.title')); ?>"
                                                id="title" placeholder="Site Başlığı">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">Site Açıklaması</label>
                                        <input type="text" class="form-control form-control-rounded" name="description" value="<?php echo e(config('settings.description')); ?>"
                                                id="title" placeholder="Site Açıklaması">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="name">Logo</label><br>
                                        <img src="<?php echo e(asset(config('settings.logo'))); ?>" style="width: 90px" alt="">
                                        <input type="file" class="form-control form-control-rounded" name="logo"
                                                id="title" placeholder="">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="name">Favicon</label><br>
                                        <img src="<?php echo e(asset(config('settings.favicon'))); ?>" style="width: 90px" alt="">
                                        <input type="file" class="form-control form-control-rounded" name="favicon"
                                                id="title" placeholder="">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-3">
                                        <label for="phone">Telefon</label>
                                        <input type="text" class="form-control form-control-rounded" name="phone" value="<?php echo e(config('settings.phone')); ?>"
                                                id="phone" placeholder="Telefon">
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="whatsapp_number">Whatsapp Numarası</label>
                                        <input type="text" class="form-control form-control-rounded" name="whatsapp_number" value="<?php echo e(config('settings.whatsapp_number')); ?>"
                                                id="whatsapp_number" placeholder="Telefon">
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="fax">Fax</label>
                                        <input type="text" class="form-control form-control-rounded" name="fax" value="<?php echo e(config('settings.fax')); ?>"
                                                id="fax" placeholder="Fax">
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="email">E-Posta Adresi</label>
                                        <input type="email" class="form-control form-control-rounded" name="email" value="<?php echo e(config('settings.email')); ?>"
                                                id="email" placeholder="Fax">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="address">Adres</label>
                                        <input type="text" class="form-control form-control-rounded" name="address"
                                               id="address" placeholder="Adres" value="<?php echo e(config('settings.address')); ?>">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="map">Google Map Kodu</label>
                                        <textarea name="map" id="map" class="form-control" cols="30"
                                                  rows="10"><?php echo e(config('settings.map')); ?></textarea>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="map">Footer Hakkımızda</label>
                                        <textarea name="footer_about" id="footer_about" class="form-control" cols="30"
                                                  rows="10"><?php echo e(config('settings.footer_about')); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-success btn-round shadow-success px-5">Kaydet
                                    </button>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Row-->


        </div>
        <!-- End container-fluid-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/admin/settings.blade.php ENDPATH**/ ?>