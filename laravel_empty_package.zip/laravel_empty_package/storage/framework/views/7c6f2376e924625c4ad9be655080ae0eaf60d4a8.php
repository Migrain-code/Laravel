</div>
</div>
<footer class="wraper_footer custom-footer">
    <div data-elementor-type="section" data-elementor-id="37333" class="elementor elementor-37333">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-f1c174b elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="f1c174b" data-element_type="section"
            data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-612681e"
                    data-id="612681e" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-aab0627 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="aab0627" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-14349fb footer-col"
                                    data-id="14349fb" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-d0a3d4d elementor-widget elementor-widget-image"
                                            data-id="d0a3d4d" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="162" height="30"
                                                     src="<?php echo e(asset(config('settings.logo'))); ?>"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-5ab2fb3 elementor-widget elementor-widget-heading"
                                            data-id="5ab2fb3" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default"><?php echo e(config('settings.footer_about')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-bd48ae6 footer-col"
                                    data-id="bd48ae6" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-0e4c45d elementor-widget elementor-widget-heading"
                                            data-id="0e4c45d" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Destek</h6></div>
                                        </div>

                                        <div
                                            class="elementor-element elementor-element-4a1d69a elementor-widget elementor-widget-heading"
                                            data-id="4a1d69a" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('sss')); ?>">Bilgi Bankası
                                                    </a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-17c6739 elementor-widget elementor-widget-heading"
                                            data-id="17c6739" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('contact')); ?>">İletişim</a>
                                                </p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4e64182 elementor-widget elementor-widget-heading"
                                            data-id="4e64182" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('portfolio')); ?>">Portföy
                                                      </a></p></div>
                                        </div>

                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-965b857 footer-col"
                                    data-id="965b857" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-510c174 elementor-widget elementor-widget-heading"
                                            data-id="510c174" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    Şirket</h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-97cc124 elementor-widget elementor-widget-heading"
                                            data-id="97cc124" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('home')); ?>">Anasayfa</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-97cc124 elementor-widget elementor-widget-heading"
                                            data-id="97cc124" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('about')); ?>">Hakkımızda</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-7111ee8 elementor-widget elementor-widget-heading"
                                            data-id="7111ee8" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('page.promoter')); ?>">Girişimci</a></p></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-0c3f87d elementor-widget elementor-widget-heading"
                                            data-id="0c3f87d" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><p
                                                    class="elementor-heading-title elementor-size-default"><a
                                                        href="<?php echo e(route('page.investor')); ?>">Yatırımcı
                                                        </a></p></div>
                                        </div>

                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-0dc4407 footer-col"
                                    data-id="0dc4407" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b59c3d0 elementor-widget elementor-widget-heading"
                                            data-id="b59c3d0" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">İletişim</h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-858a807 elementor-icon-list--layout-inline addrs-footer-two elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="858a807" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                    <span class="elementor-icon-list-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="17" viewBox="0 0 14 17" fill="none"><path
                                                            d="M13.3584 7.13636C13.3584 11.9091 7.1792 16 7.1792 16C7.1792 16 1 11.9091 1 7.13636C1 5.5089 1.65102 3.94809 2.80985 2.7973C3.96867 1.64651 5.54037 1 7.1792 1C8.81803 1 10.3897 1.64651 11.5486 2.7973C12.7074 3.94809 13.3584 5.5089 13.3584 7.13636Z"
                                                            stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path><path
                                                            d="M7.17927 9.18173C8.31683 9.18173 9.239 8.26595 9.239 7.13627C9.239 6.0066 8.31683 5.09082 7.17927 5.09082C6.04171 5.09082 5.11954 6.0066 5.11954 7.13627C5.11954 8.26595 6.04171 9.18173 7.17927 9.18173Z"
                                                            stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path></svg> </span>
                                                        <span class="elementor-icon-list-text"><?php echo e(config('settings.address')); ?></span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-b367810 elementor-icon-list--layout-inline addrs-footer-two elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="b367810" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <span class="elementor-icon-list-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path
                                                                d="M8.55268 11.4968C10.2211 11.4968 11.5736 10.1537 11.5736 8.49682C11.5736 6.83997 10.2211 5.49683 8.55268 5.49683C6.88426 5.49683 5.53174 6.83997 5.53174 8.49682C5.53174 10.1537 6.88426 11.4968 8.55268 11.4968Z"
                                                                stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path><path
                                                                d="M11.5733 5.49953V9.24953C11.5733 9.84627 11.812 10.4186 12.2369 10.8405C12.6618 11.2625 13.2381 11.4995 13.839 11.4995C14.4399 11.4995 15.0162 11.2625 15.4411 10.8405C15.866 10.4186 16.1047 9.84627 16.1047 9.24953V8.49953C16.1046 6.8068 15.5279 5.16389 14.4683 3.83793C13.4088 2.51197 11.9287 1.58095 10.2687 1.19626C8.6088 0.811562 6.86662 0.995816 5.3255 1.71906C3.78438 2.4423 2.53494 3.662 1.78036 5.17982C1.02577 6.69765 0.810417 8.42433 1.16931 10.0791C1.5282 11.7339 2.44022 13.2195 3.75709 14.2942C5.07396 15.369 6.71822 15.9698 8.42251 15.9989C10.1268 16.028 11.7909 15.4837 13.1442 14.4545"
                                                                stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path></svg> </span>
                                                        <span class="elementor-icon-list-text"><a
                                                                href="mailto:<?php echo e(config('settings.email')); ?>"
                                                                class="__cf_email__"
                                                                data-cfemail="1e777078715e7b667f736e727b307d7173"><?php echo e(config('settings.email')); ?></a> </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-7876669 elementor-icon-list--layout-inline addrs-footer-two elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="7876669" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                    <span class="elementor-icon-list-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path
                                                            d="M16.0743 12.2304V14.4885C16.0752 14.6981 16.0319 14.9056 15.9474 15.0977C15.8628 15.2898 15.7388 15.4622 15.5832 15.6039C15.4277 15.7456 15.244 15.8535 15.0441 15.9207C14.8441 15.9878 14.6322 16.0128 14.422 15.9939C12.0896 15.7422 9.84922 14.9508 7.88081 13.6831C6.04946 12.5274 4.49679 10.9855 3.33308 9.16689C2.05211 7.20324 1.25495 4.96756 1.00615 2.64096C0.987211 2.43282 1.01212 2.22303 1.0793 2.02497C1.14647 1.82691 1.25444 1.6449 1.39632 1.49055C1.53821 1.33619 1.7109 1.21287 1.90341 1.12843C2.09592 1.04398 2.30403 1.00027 2.51448 1.00007H4.78835C5.15619 0.996478 5.5128 1.12583 5.79171 1.36403C6.07061 1.60222 6.25278 1.93301 6.30426 2.29472C6.40024 3.01736 6.57823 3.72691 6.83483 4.40981C6.93681 4.67922 6.95888 4.97202 6.89843 5.2535C6.83798 5.53498 6.69754 5.79336 6.49375 5.99801L5.53115 6.95394C6.61014 8.83837 8.18131 10.3986 10.0789 11.4702L11.0415 10.5142C11.2476 10.3118 11.5078 10.1724 11.7912 10.1123C12.0746 10.0523 12.3695 10.0742 12.6408 10.1755C13.3285 10.4303 14.0429 10.6071 14.7706 10.7024C15.1388 10.754 15.4751 10.9381 15.7155 11.2199C15.9558 11.5016 16.0835 11.8612 16.0743 12.2304Z"
                                                            stroke="#F2543F" stroke-linecap="round" stroke-linejoin="round"></path></svg> </span>
                                                        <span class="elementor-icon-list-text"><?php echo e(config('settings.phone')); ?></span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-7398d57 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="7398d57" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4f00c68 footer-col-copyright"
                                    data-id="4f00c68" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-9fbb9b4 elementor-icon-list--layout-inline elementor-align-left elementor-tablet-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="9fbb9b4" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">

                                                    <li class="elementor-icon-list-item elementor-inline-item">
                                                        <span class="elementor-icon-list-icon">&copy;</span>
                                                        <span class="elementor-icon-list-text"><a href="https://www.hst.world/" class="text-white"> Copyright 2022<strong style="margin-left:10px"> www.hst.world</strong> </a></span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-34538dc footer-col-copyright"
                                    data-id="34538dc" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-56fcc1f elementor-icon-list--layout-inline elementor-align-right elementor-tablet-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="56fcc1f" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items elementor-inline-items">
                                                    <?php $__currentLoopData = $globalData['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="elementor-icon-list-item elementor-inline-item">
                                                            <a href="<?php echo e(route('page.detail',$row->slug)); ?>"><span class="elementor-icon-list-text"><?php echo e($row->title); ?></span>
                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
</footer>
</div>
<?php /**PATH /home/u0782468/public_html/project/resources/views/layout/footer.blade.php ENDPATH**/ ?>