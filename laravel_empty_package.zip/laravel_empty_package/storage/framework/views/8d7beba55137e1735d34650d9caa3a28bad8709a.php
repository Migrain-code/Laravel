<?php $__env->startSection('title','faq'); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet" href="<?php echo e(asset('assets/wp-content/litespeed/css/a8dafa7557f83c028b7cb1a15cd4e0c4f15a.css?ver=76eeb')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div data-elementor-type="wp-page" data-elementor-id="19495" class="elementor elementor-19495">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-57afee6 elementor-section-full_width elementor-section-stretched elementor-section-height-default elementor-section-height-default"
            data-id="57afee6" data-element_type="section"
            data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}"
            style="width: 1903px; left: 0px;">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-73a3535"
                    data-id="73a3535" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-4df7abd elementor-widget elementor-widget-image"
                             data-id="4df7abd" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="866" height="988"
                                     src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/faq-img-2.0.png"
                                     class="attachment-full size-full" alt="" loading="lazy"
                                     srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/faq-img-2.0.png 866w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/faq-img-2.0-263x300.png 263w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/faq-img-2.0-768x876.png 768w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/faq-img-2.0-600x685.png 600w"
                                     sizes="(max-width: 866px) 100vw, 866px" data-no-retina=""></div>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-5783c8a"
                    data-id="5783c8a" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-background-overlay"></div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-a9b4bf5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="a9b4bf5" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-ecd1d3c"
                                    data-id="ecd1d3c" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-f5a242b elementor-widget elementor-widget-heading"
                                            data-id="f5a242b" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default">Nasıl Yardımcı Olabilirm</span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-b10a3a1 elementor-widget elementor-widget-heading"
                                            data-id="b10a3a1" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h1
                                                    class="elementor-heading-title elementor-size-default">
                                                    Sık Sorulan Sorular
                                                </h1></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-077dca9 faq-accodian elementor-widget elementor-widget-radiant-accordion"
                                            data-id="077dca9" data-element_type="widget"
                                            data-widget_type="radiant-accordion.default">
                                            <div class="elementor-widget-container">
                                                <div id="a2042288261" class="radiantthemes-accordion element-three">
                                                    <div class="card">
                                                        <div class="btn btn-link " data-toggle="collapse"
                                                             data-target="#ad21934b1" aria-expanded="true"
                                                             aria-controls="ad21934b" role="button">
                                                            <div class="card-header" id="ad21934b">
                                                                <div class="img-upload">
                                                                    <svg width="13" height="8" viewBox="0 0 13 8"
                                                                         fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M6.05556 8L0.0414906 0.5H12.0696L6.05556 8Z"
                                                                            fill="#262626"></path>
                                                                    </svg>
                                                                </div>
                                                                <p class="mb-0">
                                                                    Nasıl iletişime geçebilirim
                                                                </p></div>
                                                        </div>
                                                        <div id="ad21934b1" class="collapse show"
                                                             aria-labelledby="ad21934b" data-parent="#a2042288261">
                                                            <div class="card-body">Lorem ipsum dolor sit amet,
                                                                consectetur adipiscing elit. Magna malesuada etiam in in
                                                                faucibus quam pellentesque malesuada arcu. Velit vitae
                                                                id magna netus vulputate posuere turpis viverra et.
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card">
                                                        <div class="btn btn-link collapsed" data-toggle="collapse"
                                                             data-target="#a735561d1" aria-expanded="false"
                                                             aria-controls="a735561d" role="button">
                                                            <div class="card-header" id="a735561d">
                                                                <div class="img-upload">
                                                                    <svg width="13" height="8" viewBox="0 0 13 8"
                                                                         fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M6.05556 8L0.0414906 0.5H12.0696L6.05556 8Z"
                                                                            fill="#262626"></path>
                                                                    </svg>
                                                                </div>
                                                                <p class="mb-0">
                                                                    Destek Sistemi Nasıl Çalışır</p></div>
                                                        </div>
                                                        <div id="a735561d1" class="collapse " aria-labelledby="a735561d"
                                                             data-parent="#a2042288261">
                                                            <div class="card-body">Lorem ipsum dolor sit amet,
                                                                consectetur adipiscing elit. Magna malesuada etiam in in
                                                                faucibus quam pellentesque malesuada arcu. Velit vitae
                                                                id magna netus vulputate posuere turpis viverra etc.
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card">
                                                        <div class="btn btn-link collapsed" data-toggle="collapse"
                                                             data-target="#aecf44e01" aria-expanded="false"
                                                             aria-controls="aecf44e0" role="button">
                                                            <div class="card-header" id="aecf44e0">
                                                                <div class="img-upload">
                                                                    <svg width="13" height="8" viewBox="0 0 13 8"
                                                                         fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M6.05556 8L0.0414906 0.5H12.0696L6.05556 8Z"
                                                                            fill="#262626"></path>
                                                                    </svg>
                                                                </div>
                                                                <p class="mb-0">
                                                                    İşleriniz nasıl ilerliyor
                                                                </p></div>
                                                        </div>
                                                        <div id="aecf44e01" class="collapse " aria-labelledby="aecf44e0"
                                                             data-parent="#a2042288261">
                                                            <div class="card-body">Lorem ipsum dolor sit amet,
                                                                consectetur adipiscing elit. Magna malesuada etiam in in
                                                                faucibus quam pellentesque malesuada arcu. Velit vitae
                                                                id magna netus vulputate posuere turpis viverra etc.
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card">
                                                        <div class="btn btn-link collapsed" data-toggle="collapse"
                                                             data-target="#a1d02be91" aria-expanded="false"
                                                             aria-controls="a1d02be9" role="button">
                                                            <div class="card-header" id="a1d02be9">
                                                                <div class="img-upload">
                                                                    <svg width="13" height="8" viewBox="0 0 13 8"
                                                                         fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M6.05556 8L0.0414906 0.5H12.0696L6.05556 8Z"
                                                                            fill="#262626"></path>
                                                                    </svg>
                                                                </div>
                                                                <p class="mb-0">
                                                                 Nasıl Kayıt olurum
                                                                </p></div>
                                                        </div>
                                                        <div id="a1d02be91" class="collapse " aria-labelledby="a1d02be9"
                                                             data-parent="#a2042288261">
                                                            <div class="card-body">Lorem ipsum dolor sit amet,
                                                                consectetur adipiscing elit. Magna malesuada etiam in in
                                                                faucibus quam pellentesque malesuada arcu. Velit vitae
                                                                id magna netus vulputate posuere turpis viverra etc.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-project\evet\resources\views/faq.blade.php ENDPATH**/ ?>