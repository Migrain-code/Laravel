<?php $__env->startSection('title','Anasayfa'); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet"
          href="<?php echo e(asset('assets/wp-content/litespeed/css/b14cc47a1668d578e19539f42e5be3c2b4b8.css?ver=d9e91')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .elementor-30515 .elementor-element.elementor-element-667add9 > .elementor-element-populated {
            transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;
            margin: 0;
            --e-column-margin-right: 0px;
            --e-column-margin-left: 0px;
            padding-top:50px;
            padding-bottom: 220px;
            padding-right: 50px;
            padding-left: 50px;
        }
    </style>
    <div data-elementor-type="wp-page" data-elementor-id="30515" class="elementor elementor-30515">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-1686a2a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="1686a2a" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-01a62a6"
                    data-id="01a62a6" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-fbe17bd elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                            data-id="fbe17bd" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-12809dd"
                                    data-id="12809dd" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-1dc6e7e elementor-widget elementor-widget-heading"
                                            data-id="1dc6e7e" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default"><?php echo e($slider->title); ?></span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-3918426 elementor-widget elementor-widget-heading"
                                            data-id="3918426" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h1
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($slider->description); ?>

                                                </h1></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-dd9802e elementor-widget elementor-widget-heading"
                                            data-id="dd9802e" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default"><?php echo e($slider->sub_description); ?></span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-685206d elementor-widget elementor-widget-radiant-custom-button"
                                            data-id="685206d" data-element_type="widget"
                                            data-settings="{&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                                            data-widget_type="radiant-custom-button.default">
                                            <div class="elementor-widget-container">
                                                <div class="radiantthemes-custom-button element-one hover-style-five  "
                                                     data-button-direction="" data-button-fullwidth="false"
                                                     data-button-icon-position=""><a
                                                        class="radiantthemes-custom-button-main"
                                                        href="<?php echo e($slider->button_url); ?>">
                                                        <div class="placeholder"><?php echo e($slider->button_text); ?></div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-958cbca elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet elementor-hidden-laptop elementor-hidden-tablet_extra elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="958cbca" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="41" height="47"
                                                             viewBox="0 0 41 47" fill="none">
                                                            <path
                                                                d="M6.23345 40.6684L3.42545 5.96068L34.5166 21.6404L6.23345 40.6684Z"
                                                                stroke="url(#paint0_linear_103_716)"
                                                                stroke-width="6"></path>
                                                            <defs>
                                                                <linearGradient id="paint0_linear_103_716"
                                                                                x1="0.00423016" y1="0.87539"
                                                                                x2="29.3981" y2="44.5662"
                                                                                gradientUnits="userSpaceOnUse">
                                                                    <stop stop-color="#68C9E8"></stop>
                                                                    <stop offset="1" stop-color="#252DEF"></stop>
                                                                </linearGradient>
                                                            </defs>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-b4a487c"
                                    data-id="b4a487c" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-2f2901e moving-image-left-right elementor-widget elementor-widget-image"
                                            data-id="2f2901e" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="823" height="858"
                                                     src="<?php echo e(asset($slider->image)); ?>"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     sizes="(max-width: 823px) 100vw, 823px" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-d40c166 elementor-widget__width-auto elementor-absolute animated-fast elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-radiant-custom-image animated zoomIn"
                                            data-id="d40c166" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="radiant-custom-image.default">
                                            <div class="elementor-widget-container">
                                                <img alt="custom-image" src="/assets/wp-content/uploads/2022/06/demo-ten-section-three-side-img-2.png">
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-e011f31 elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="e011f31" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26"
                                                             viewBox="0 0 26 26" fill="none">
                                                            <path
                                                                d="M0.486045 16.5207C1.09317 18.6786 2.24801 20.6429 3.8384 22.2227C5.42879 23.8026 7.40069 24.9443 9.56261 25.5371C11.7245 26.1299 14.003 26.1535 16.1768 25.6058C18.3505 25.058 20.3457 23.9574 21.9685 22.4109C23.5914 20.8644 24.7868 18.9246 25.4385 16.7797C26.0903 14.6348 26.1764 12.3579 25.6884 10.1699C25.2004 7.98194 24.155 5.95736 22.6535 4.29274C21.1521 2.62813 19.2457 1.38006 17.1195 0.669734L15.0231 6.94462C16.0673 7.29345 17.0035 7.90637 17.7409 8.72385C18.4782 9.54133 18.9916 10.5356 19.2313 11.6101C19.4709 12.6846 19.4287 13.8028 19.1086 14.8561C18.7885 15.9094 18.2014 16.8621 17.4045 17.6216C16.6075 18.381 15.6277 18.9215 14.5602 19.1905C13.4927 19.4595 12.3737 19.4479 11.312 19.1568C10.2503 18.8657 9.28193 18.305 8.5009 17.5291C7.71987 16.7533 7.15274 15.7886 6.85459 14.7289L0.486045 16.5207Z"
                                                                fill="#236BE9"></path>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-5bc3456 elementor-widget__width-auto elementor-absolute animated-fast elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-radiant-custom-image animated zoomIn"
                                            data-id="5bc3456" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:400}"
                                            data-widget_type="radiant-custom-image.default">
                                            <div class="elementor-widget-container">
                                                <img alt="custom-image"
                                                     src="/assets/wp-content/uploads/2022/06/hm9-banner-img2.png" data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-a78326b elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="a78326b" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34"
                                                             viewBox="0 0 34 34" fill="#242879">
                                                            <circle cx="17" cy="17" r="17"></circle>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-83095b1 elementor-absolute icon-moveright elementor-widget__width-initial elementor-hidden-mobile animated-fast elementor-hidden-tablet_extra elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon animated zoomIn"
                                            data-id="83095b1" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:800}"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <div class="elementor-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34"
                                                             viewBox="0 0 34 34" fill="#242879">
                                                            <circle cx="17" cy="17" r="17"></circle>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4341d7a elementor-widget__width-auto elementor-absolute animated-fast elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-radiant-custom-image animated zoomIn"
                                            data-id="4341d7a" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;,&quot;_animation_delay&quot;:600}"
                                            data-widget_type="radiant-custom-image.default">
                                            <div class="elementor-widget-container">
                                                <img alt="custom-image"
                                                     src="/assets/wp-content/uploads/2022/06/hm9-banner-img3.png"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-34abe50 elementor-widget__width-initial elementor-absolute elementor-hidden-laptop elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image"
                                            data-id="34abe50" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="260" height="260"
                                                     src="/assets/wp-content/uploads/2022/06/dot.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     sizes="(max-width: 260px) 100vw, 260px" data-no-retina=""></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-7f161a6 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="7f161a6" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-508f6de"
                    data-id="508f6de" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-b48bf93 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="b48bf93" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-355457a"
                                    data-id="355457a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-1e39913 elementor-widget elementor-widget-radiant-client"
                                            data-id="1e39913" data-element_type="widget"
                                            data-widget_type="radiant-client.default">
                                            <div class="elementor-widget-container">
                                                <div
                                                    class="clients swiper-container allow-autoplay element-one swiper-container-initialized swiper-container-horizontal"
                                                    data-mobile-items="1" data-tab-items="3" data-desktop-items="5"
                                                    data-spacer="30" data-autoplay="true">
                                                    <div class="swiper-wrapper" style="transform: translate3d(-2640px, 0px, 0px); transition-duration: 0ms;">
                                                        <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="clients-item swiper-slide swiper-slide-prev"
                                                                 data-swiper-slide-index="4"
                                                                 style="width: 234px; margin-right: 30px;">
                                                                <div class="holder">
                                                                    <div class="table">
                                                                        <div class="table-cell">
                                                                            <div class="pic radiantthemes-retina">
                                                                                <a href="<?php echo e($sponsor->link); ?>" target="_blank"><img width="119" height="56" src="<?php echo e(asset($sponsor->image)); ?>" class="client-cover-img wp-post-image" alt="" loading="lazy"></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>
                                                    <div class="swiper-pagination3"></div>
                                                    <span class="swiper-notification" aria-live="assertive"
                                                          aria-atomic="true"></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-22c9241 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="22c9241" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-64ff10b"
                    data-id="64ff10b" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-ccf798e elementor-widget elementor-widget-heading"
                            data-id="ccf798e" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default"><?php echo e($mainPage->bannerTitle); ?></span>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-258fc0e elementor-widget elementor-widget-heading"
                            data-id="258fc0e" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h2
                                    class="elementor-heading-title elementor-size-default">
                                    <?php echo e($mainPage->bannerSubtitle); ?>


                                </h2></div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-61b7bfd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="61b7bfd" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-9c7576c animated fadeIn"
                                    data-id="9c7576c" data-element_type="column"
                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:300}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b836618 elementor-widget elementor-widget-image"
                                            data-id="b836618" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="124" height="107"
                                                     src="/assets/wp-content/uploads/2022/06/execution.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-88f5d75 elementor-widget elementor-widget-heading"
                                            data-id="88f5d75" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($mainPage->bannerBoxes->b1->title); ?>


                                                </h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-f3a5b83 elementor-widget elementor-widget-text-editor"
                                            data-id="f3a5b83" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($mainPage->bannerBoxes->b1->content); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7a056fa animated fadeIn"
                                    data-id="7a056fa" data-element_type="column"
                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:500}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b484fd5 elementor-widget elementor-widget-image"
                                            data-id="b484fd5" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="125" height="107"
                                                     src="/assets/wp-content/uploads/2022/06/demo-nine-project.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-e13ad92 elementor-widget elementor-widget-heading"
                                            data-id="e13ad92" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($mainPage->bannerBoxes->b2->title); ?>



                                                </h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-eaaad24 elementor-widget elementor-widget-text-editor"
                                            data-id="eaaad24" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($mainPage->bannerBoxes->b2->content); ?>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-003cc7f animated fadeIn"
                                    data-id="003cc7f" data-element_type="column"
                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:700}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-b2e3830 elementor-widget elementor-widget-image"
                                            data-id="b2e3830" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="119" height="107"
                                                     src="/assets/wp-content/uploads/2022/06/demo-nine-training-startegy.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-cbb9862 elementor-widget elementor-widget-heading"
                                            data-id="cbb9862" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h6
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($mainPage->bannerBoxes->b3->title); ?>


                                                </h6></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-459a089 elementor-widget elementor-widget-text-editor"
                                            data-id="459a089" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($mainPage->bannerBoxes->b3->content); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-4e47c7a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="4e47c7a" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-667add9"
                    data-id="667add9" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-24c4545 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="24c4545" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1a4bbaa"
                                    data-id="1a4bbaa" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-4faa9d9 elementor-widget elementor-widget-image animated fadeIn"
                                            data-id="4faa9d9" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container" style="height: 500px">
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-0cab71f elementor-widget__width-auto elementor-absolute elementor-hidden-tablet elementor-hidden-mobile elementor-widget elementor-widget-image"
                                            data-id="0cab71f" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="650" height="687"
                                                     src="<?php echo e($mainPage->sec1Image); ?>"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     sizes="(max-width: 650px) 100vw, 650px" data-no-retina=""></div>
                                        </div>
                                       
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-56606ed"
                                    data-id="56606ed" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-71d1612 elementor-widget elementor-widget-heading"
                                            data-id="71d1612" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default"><?php echo e($mainPage->sec1Title); ?></span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-4524ca4 elementor-widget elementor-widget-heading"
                                            data-id="4524ca4" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($mainPage->sec1SubTitle); ?>

                                                </h2></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-a5dee70 elementor-widget elementor-widget-text-editor"
                                            data-id="a5dee70" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($mainPage->sec1Description); ?>

                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-161e33d elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box"
                                            data-id="161e33d" data-element_type="widget"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img width="60" height="60"
                                                         src="/assets/wp-content/uploads/2022/05/business-solutions.svg"
                                                         class="attachment-full size-full"
                                                         alt="" loading="lazy"
                                                         data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5 class="elementor-image-box-title">
                                                            <?php echo e($mainPage->sec1Boxes->b1->title); ?>

                                                        </h5>
                                                        <p class="elementor-image-box-description"><?php echo e($mainPage->sec1Boxes->b1->content); ?></p></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-ed8dd05 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box"
                                            data-id="ed8dd05" data-element_type="widget"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img width="60" height="60"
                                                             src="/assets/wp-content/uploads/2022/05/markte-strategy.svg"
                                                             class="attachment-full size-full"
                                                             alt="" loading="lazy"
                                                             data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title"><?php echo e($mainPage->sec1Boxes->b2->title); ?></h5>
                                                        <p class="elementor-image-box-description"><?php echo e($mainPage->sec1Boxes->b2->content); ?></p></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-0c3f292 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="0c3f292" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-11bc34b animated fadeInUp"
                    data-id="11bc34b" data-element_type="column"
                    data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:100}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-880442b elementor-widget__width-initial elementor-widget elementor-widget-image"
                            data-id="880442b" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="82" height="82"
                                     src="/assets/wp-content/uploads/2022/06/demo-nine-ball.png"
                                     class="attachment-full size-full" alt="" loading="lazy" data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-fff95d0 elementor-widget__width-initial elementor-widget elementor-widget-counter"
                            data-id="fff95d0" data-element_type="widget" data-widget_type="counter.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-counter">
                                    <div class="elementor-counter-number-wrapper">
                                        <span class="elementor-counter-number-prefix"></span>
                                        <span class="elementor-counter-number" data-duration="2000" data-to-value="<?php echo e($promoter); ?>"
                                              data-from-value="0" data-delimiter=","><?php echo e($promoter); ?></span>
                                        <span class="elementor-counter-number-suffix">+</span></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-818fa73 elementor-widget__width-initial elementor-widget elementor-widget-text-editor"
                            data-id="818fa73" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container"><p>Girişimci</p></div>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3433505 animated fadeInUp"
                    data-id="3433505" data-element_type="column"
                    data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:200}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-40ae0d4 elementor-widget__width-initial elementor-widget elementor-widget-image"
                            data-id="40ae0d4" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="72" height="63"
                                     src="/assets/wp-content/uploads/2022/06/demo-nien-profile.png"
                                     class="attachment-full size-full" alt="" loading="lazy" data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-f34411a elementor-widget__width-initial elementor-widget elementor-widget-counter"
                            data-id="f34411a" data-element_type="widget" data-widget_type="counter.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-counter">
                                    <div class="elementor-counter-number-wrapper">
                                        <span class="elementor-counter-number-prefix"></span>
                                        <span class="elementor-counter-number" data-duration="2000" data-to-value="<?php echo e($investor); ?>"
                                              data-from-value="0" data-delimiter=","><?php echo e($investor); ?></span>
                                        <span class="elementor-counter-number-suffix"></span></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-96c3437 elementor-widget__width-initial elementor-widget elementor-widget-text-editor"
                            data-id="96c3437" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container"><p>Yatırımcı</p></div>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-a6f7f30 animated fadeInUp"
                    data-id="a6f7f30" data-element_type="column"
                    data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:300}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div
                            class="elementor-element elementor-element-1adef7e elementor-widget__width-initial elementor-widget elementor-widget-image"
                            data-id="1adef7e" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="70" height="63"
                                     src="/assets/wp-content/uploads/2022/06/demo-nine-bag.png"
                                     class="attachment-full size-full" alt="" loading="lazy" data-no-retina=""></div>
                        </div>
                        <div
                            class="elementor-element elementor-element-e1beee8 elementor-widget__width-initial elementor-widget elementor-widget-counter"
                            data-id="e1beee8" data-element_type="widget" data-widget_type="counter.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-counter">
                                    <div class="elementor-counter-number-wrapper">
                                        <span class="elementor-counter-number-prefix"></span>
                                        <span class="elementor-counter-number" data-duration="2000" data-to-value="<?php echo e($project); ?>"
                                              data-from-value="0" data-delimiter=","><?php echo e($project); ?></span>
                                        <span class="elementor-counter-number-suffix"></span></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-element elementor-element-528c6a3 elementor-widget__width-initial elementor-widget elementor-widget-text-editor"
                            data-id="528c6a3" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container"><p>Başarılı Proje</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-11e82d3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="11e82d3" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default">
                <div
                    class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5eb0672"
                    data-id="5eb0672" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-d5dd90d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="d5dd90d" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-282593a"
                                    data-id="282593a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-1ac56ef elementor-widget elementor-widget-heading animated fadeInUp"
                                            data-id="1ac56ef" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <span class="elementor-heading-title elementor-size-default"><?php echo e($mainPage->sec2Title); ?></span>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-c5a153e elementor-widget elementor-widget-heading animated fadeInUp"
                                            data-id="c5a153e" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($mainPage->sec2SubTitle); ?>

                                                </h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-ac2bf6a"
                                    data-id="ac2bf6a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-452b920 elementor-widget elementor-widget-text-editor"
                                            data-id="452b920" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                               <?php echo e($mainPage->sec2Description); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-4859d71 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="4859d71" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-76a52d8"
                                    data-id="76a52d8" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-ec97270 elementor-widget elementor-widget-image animated fadeIn"
                                            data-id="ec97270" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:400}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="652" height="671"
                                                     src="<?php echo e(asset($mainPage->sec2Image)); ?>"
                                                     class="attachment-full size-full" alt="" loading="lazy"></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-ce2ce75 elementor-widget__width-auto elementor-absolute elementor-hidden-mobile elementor-hidden-tablet elementor-widget elementor-widget-image animated zoomIn"
                                            data-id="ce2ce75" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="233" height="194"
                                                     src="/assets/wp-content/uploads/2022/06/demo-nine-section-5-draw-megaphone.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-e387afb elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-image"
                                            data-id="e387afb" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="29" height="32"
                                                     src="/assets/wp-content/uploads/2022/06/demo-nine-polygon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-c7d2ba4 elementor-widget__width-auto elementor-absolute elementor-hidden-mobile elementor-widget elementor-widget-image"
                                            data-id="c7d2ba4" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="15" height="15"
                                                     src="/assets/wp-content/uploads/2022/06/demo-nine-circle.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"
                                                     data-no-retina=""></div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-b361300 elementor-widget__width-auto elementor-absolute elementor-hidden-mobile elementor-widget elementor-widget-image animated zoomIn"
                                            data-id="b361300" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;zoomIn&quot;}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="144" height="144"
                                                     src="/assets/wp-content/uploads/2022/06/demo-nine-section-5-rocket.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6b9b551"
                                    data-id="6b9b551" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-28ea863 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box animated fadeInUp"
                                            data-id="28ea863" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img width="86" height="86"
                                                             src="/assets/wp-content/uploads/2022/06/demo-nine-discover.png"
                                                             class="attachment-full size-full"
                                                             alt="" loading="lazy"
                                                             data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">
                                                            <?php echo e($mainPage->sec2Boxes->b1->title); ?>


                                                        </h5>
                                                        <p class="elementor-image-box-description">
                                                            <?php echo e($mainPage->sec2Boxes->b1->content); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-0eeb553 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box animated fadeInUp"
                                            data-id="0eeb553" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img width="86" height="86"
                                                             src="/assets/wp-content/uploads/2022/06/demo-nine-best-feature.png"
                                                             class="attachment-full size-full"
                                                             alt="" loading="lazy"
                                                             data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content">
                                                        <h5 class="elementor-image-box-title">
                                                            <?php echo e($mainPage->sec2Boxes->b2->title); ?>

                                                        </h5>
                                                        <p class="elementor-image-box-description">
                                                            <?php echo e($mainPage->sec2Boxes->b2->content); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-element elementor-element-82720df elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box animated fadeInUp"
                                            data-id="82720df" data-element_type="widget"
                                            data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:300}"
                                            data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img width="86" height="86"
                                                             src="/assets/wp-content/uploads/2022/06/demo-nine-solutionregeneratiing.png"
                                                             class="attachment-full size-full"
                                                             alt="" loading="lazy"
                                                             data-no-retina="">
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5 class="elementor-image-box-title"><?php echo e($mainPage->sec2Boxes->b3->title); ?></h5>
                                                        <p class="elementor-image-box-description">
                                                            <?php echo e($mainPage->sec2Boxes->b3->content); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/home.blade.php ENDPATH**/ ?>