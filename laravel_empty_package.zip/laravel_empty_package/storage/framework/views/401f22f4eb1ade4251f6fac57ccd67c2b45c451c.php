<?php $__env->startSection('title','Galeri Kayıt'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Galeri Kayıt</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Galeri Listesi</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Galeri Kayıt</li>
                    </ol>
                </div>
            </div>
            <!-- End Breadcrumb-->


            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title text-success">Galeri Kayıt</div>
                            <form action="<?php echo e(route('admin.portfolio.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="description">Başlık</label>
                                        <input type="text" class="form-control form-control-rounded" name="description" required id="description" placeholder="Başlık">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="image">Resim</label>
                                        <input type="file" class="form-control form-control-rounded" name="image" required id="image" placeholder="">
                                    </div>

                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-success btn-round shadow-success px-5">Kaydet</button>
                                </div>


                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Row-->


        </div>
        <!-- End container-fluid-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\girisim\resources\views/admin/portfolio/create.blade.php ENDPATH**/ ?>