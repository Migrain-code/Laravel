<?php $__env->startSection('title','Kullanıcı Kayıt'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Kullanıcı Kayıt</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Kullanıcı Listesi</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Kullanıcı Kayıt</li>
                    </ol>
                </div>
            </div>
            <!-- End Breadcrumb-->


            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title text-success">Kullanıcı Kayıt</div>
                            <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="name">Ad</label>
                                        <input type="text" class="form-control form-control-rounded" name="name" value="<?php echo e($user->name); ?>"
                                               required id="name" placeholder="Ad">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="year">Soyad</label>
                                        <input type="text" class="form-control form-control-rounded" name="surname" value="<?php echo e($user->surname); ?>"
                                               required id="year" placeholder="Soyad">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="job">Meslek</label>
                                        <input type="text" class="form-control form-control-rounded" name="job" value="<?php echo e($user->job); ?>"
                                               required id="job" placeholder="Meslek">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="image">Fotoğraf <a href="<?php echo e(asset($user->image)); ?>" target="_blank">(Görüntüle)</a></label>
                                        <input type="file" class="form-control form-control-rounded" name="image"
                                               id="image" placeholder="">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="birthday">Doğum Tarihi</label>
                                        <input type="date" class="form-control form-control-rounded" name="birthday" value="<?php echo e($user->birthday); ?>"
                                               required id="birthday" placeholder="Parola">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="email">E-Posta Adresi</label>
                                        <input type="text" class="form-control form-control-rounded" name="email" value="<?php echo e($user->email); ?>"
                                               required id="email" placeholder="E-Posta Adresi">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="password">Parola</label>
                                        <input type="text" class="form-control form-control-rounded" name="password"
                                               id="password" placeholder="Parola">
                                    </div>
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-success btn-round shadow-success px-5">Kaydet
                                    </button>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Row-->


        </div>
        <!-- End container-fluid-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/admin/user/edit.blade.php ENDPATH**/ ?>