<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
    <div class="brand-logo">
        <a href="<?php echo e(route('admin.home')); ?>">
            <img src="<?php echo e(asset(config('settings.favicon'))); ?>" class="logo-icon" alt="logo icon">
            <h5 class="logo-text">HST.WORLD</h5>
        </a>
    </div>
    <ul class="sidebar-menu do-nicescrol">
        <li class="sidebar-header">Menü</li>

        <li <?php if(request()->routeIs('admin.home')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.home')); ?>"><i
                        class="zmdi zmdi-star-outline"></i> Anasayfa</a></li>

        <li <?php if(request()->routeIs('admin.promoter.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.promoter.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Girişimci İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.promoter.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Girişimci Listesi</a>
                </li>
                <li><a href="<?php echo e(route('admin.promoter.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Girişimci
                        Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.investor.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.investor.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Yatırımcı İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.investor.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Yatırımcı Listesi</a>
                </li>
                <li><a href="<?php echo e(route('admin.investor.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Yatırımcı
                        Ekle</a></li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.project-request.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.project-request.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Girişim İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.project-request.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Girişim
                        Talepleri</a></li>
                <li><a href="<?php echo e(route('admin.project.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Girişim
                        Listesi</a></li>
                <li><a href="<?php echo e(route('admin.interest.index')); ?>"><i class="zmdi zmdi-star-outline"></i> İlgilenenler</a></li>
            </ul>
        </li>
        <li <?php if(request()->routeIs('admin.slider.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.slider.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Site İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li <?php if(request()->routeIs('admin.slider.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.slider.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Slider İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.slider.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Slider
                                Listesi</a></li>
                        <li><a href="<?php echo e(route('admin.slider.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Slider
                                Ekle</a></li>
                    </ul>
                </li>
                <li <?php if(request()->routeIs('admin.about.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.about.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Hakkımızda İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.about.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Düzenle </a>
                        </li>

                    </ul>
                </li>
                <li <?php if(request()->routeIs('admin.main.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.main.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Anasayfa İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.main.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Düzenle </a>
                        </li>

                    </ul>
                </li>
                <li <?php if(request()->routeIs('admin.blog.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.blog.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Haber İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.blog.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Etkinlik Listesi</a>
                        </li>
                        <li><a href="<?php echo e(route('admin.blog.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Etkinlik
                                Ekle</a></li>
                    </ul>
                </li>
                <li <?php if(request()->routeIs('admin.sponsor.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.sponsor.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Sponsor İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.sponsor.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Sponsor Listesi </a></li>
                        <li><a href="<?php echo e(route('admin.sponsor.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Sponsor Ekle</a></li>
                    </ul>
                </li>
                <li <?php if(request()->routeIs('admin.page.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.page.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Sayfa İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.page.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Sayfa Listesi</a>
                        </li>
                        <li><a href="<?php echo e(route('admin.page.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Sayfa
                                Ekle</a></li>
                    </ul>
                </li>

                <li <?php if(request()->routeIs('admin.faq.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.faq.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Bilgi Bankası</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.faq.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Bilgi Bankası Listesi</a>
                        </li>
                        <li><a href="<?php echo e(route('admin.faq.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Bilgi Bankası
                                Ekle</a></li>
                    </ul>
                </li>
                <li <?php if(request()->routeIs('admin.committee.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.committee.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Yatırımcı Komitesi</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.committee.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Yatırımcı Komitesi Listesi</a>
                        </li>
                        <li><a href="<?php echo e(route('admin.committee.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Yatırımcı Komitesi
                                Ekle</a></li>
                    </ul>
                </li>

                <li <?php if(request()->routeIs('admin.portfolio.*')): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('admin.portfolio.index')); ?>" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Portföy İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="<?php echo e(route('admin.portfolio.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Portföy
                                Listesi</a></li>
                        <li><a href="<?php echo e(route('admin.portfolio.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Portföy
                                Ekle</a></li>
                    </ul>
                </li>
            </ul>
        </li>


        <li <?php if(request()->routeIs('admin.user.*')): ?> class="active" <?php endif; ?>>
            <a href="<?php echo e(route('admin.user.index')); ?>" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Kullanıcı İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(route('admin.user.index')); ?>"><i class="zmdi zmdi-star-outline"></i> Kullanıcı Listesi</a>
                </li>
                <li><a href="<?php echo e(route('admin.user.create')); ?>"><i class="zmdi zmdi-star-outline"></i> Kullanıcı Ekle</a>
                </li>
            </ul>
        </li>

        <li <?php if(request()->routeIs('admin.email')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.email.index')); ?>"><i
                        class="zmdi zmdi-view-dashboard"></i> E-Posta İşlemleri</a></li>
         <li <?php if(request()->routeIs('admin.email')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.email.index')); ?>"><i
        class="zmdi zmdi-view-dashboard"></i> Mesaj İşlemleri</a></li>

        <!--<li <?php if(request()->routeIs('admin.contact.index')): ?>
            class="active"
        <?php endif; ?>><a href="<?php echo e(route('admin.contact.index')); ?>"><i
                    class="zmdi zmdi-view-dashboard"></i> İletişim Mesajları</a></li>-->

        <li <?php if(request()->routeIs('admin.settings')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('admin.settings')); ?>"><i
                        class="zmdi zmdi-view-dashboard"></i> Ayarlar</a></li>

        <li><a href="<?php echo e(route('admin.logout')); ?>"><i class="zmdi zmdi-star-outline"></i>Çıkış Yap</a></li>
    </ul>

</div>
<?php /**PATH /home/u0833636/public_html/project/resources/views/admin/layouts/menu.blade.php ENDPATH**/ ?>