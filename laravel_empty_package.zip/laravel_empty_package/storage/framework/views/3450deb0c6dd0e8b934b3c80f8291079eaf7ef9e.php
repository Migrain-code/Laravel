<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title><?php echo $__env->yieldContent('title','İstanbul Yazılım'); ?></title>
    <!--favicon-->
    <link rel="icon" href="/backend/images/favicon.ico" type="image/x-icon">

    <?php echo $__env->make('admin.layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

<!-- Start wrapper-->
<div id="wrapper">
    <!--Start sidebar-wrapper-->
<?php echo $__env->make('admin.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--End sidebar-wrapper-->
<?php echo $__env->yieldContent('content'); ?>
    <!--Start topbar header-->
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--End topbar header-->

    <div class="clearfix"></div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH D:\xampp\htdocs\girisim\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>