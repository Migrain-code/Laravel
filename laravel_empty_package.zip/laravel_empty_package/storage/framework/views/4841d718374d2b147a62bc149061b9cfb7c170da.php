<?php $__env->startSection('title','S.S.S Listesi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">S.S.S Listesi</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">S.S.S Listesi</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div>
                                <div><i class="fa fa-table"></i> S.S.S Listesi</div>
                            </div>
                            <div>
                                <a href="<?php echo e(route('admin.faq.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> S.S.S Ekle</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Soru</th>
                                        <th>Cevap</th>
                                        <th>İşlemler</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- End Row-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-scripts'); ?>
    <script>
        let DATA_URL = "<?php echo e(route('admin.faq.datatable')); ?>";
        let DATA_COLUMNS = [
            {data: 'question'},
            {data: 'answer'},
            {data: 'action'},
        ];
    </script>
    <script src="/backend/js/datatable-init.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\girisim\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>