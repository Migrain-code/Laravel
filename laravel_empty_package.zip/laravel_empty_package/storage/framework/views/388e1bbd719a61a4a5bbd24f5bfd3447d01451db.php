
<?php $__env->startSection('title','Girişimci Paneli'); ?>
<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('assets/bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="site-content">
        <div id="content" class="site-content">
            <div data-elementor-type="wp-page" data-elementor-id="5403" class="elementor elementor-5403">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-0990d27 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="0990d27" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div
                            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a6937a"
                            data-id="5a6937a" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-312a8ac elementor-widget elementor-widget-radiant-custom-heading"
                                    data-id="312a8ac" data-element_type="widget"
                                    data-widget_type="radiant-custom-heading.default">
                                    <div class="elementor-widget-container">
                                        <div class="rt-hover-heading ">
                                            <h1 class="rt-title-heading"><span class="head-txt">
</span><span class="highlight-after-text"> </span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <div class="container">
                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <div class="card widget-item">
                                <div class="row g-0">
                                    <div class="col-md-2">
                                        <img src="<?php echo e(storage(auth()->user()->profile)); ?>"
                                             class="img-fluid rounded-start w-100" alt="...">
                                    </div>
                                    <div class="col-md-10">
                                        <div class="card-body">
                                            <h4 class="card-title"><?php echo e(auth()->user()->name.' '.auth()->user()->surname); ?></h4>
                                            <h6>Girişimci</h6>
                                            <p class="card-title"><?php echo e(auth()->user()->email); ?></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <?php if(session('response')): ?>
                                <div class="alert alert-<?php echo e(session('response.class')); ?>">
                                    <?php echo e(session('response.message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="about-description">
                                <div class="tab-content">
                                    <div class="tab-pane active show fade" id="create-project-request">
                                        <div class="work-zone">
                                            <form method="post" action="" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="author-desc-title d-flex">
                                                    <h6 class="author">Belgeler</h6>
                                                </div>
                                                <div class="row">
                                                    <div class="mb-3 col-md-12 col-12">
                                                        <label for="video" class="form-label">
                                                            Tanıtım Video
                                                            <?php if($projectRequest->video): ?>
                                                                <a href="<?php echo e(asset($projectRequest->video)); ?>" target="_blank">(Görüntüle)</a>
                                                            <?php endif; ?>
                                                        </label>
                                                        <input type="file" name="video" class="form-control" id="video">
                                                    </div>
                                                    <div class="mb-3 col-md-12 col-12">
                                                        <label for="sunum" class="form-label">
                                                            Tanıtım Sunum
                                                            <?php if($projectRequest->slide): ?>
                                                                <a href="<?php echo e(asset($projectRequest->slide)); ?>" target="_blank">(Görüntüle)</a>
                                                            <?php endif; ?>
                                                        </label>
                                                        <input type="file" name="slide" class="form-control" id="sunum">
                                                    </div>
                                                    <div class="mb-3 col-12 col-md-12">
                                                        <label for="belge" class="form-label">
                                                            Tanıtım Belge
                                                            <?php if($projectRequest->document): ?>
                                                                <a href="<?php echo e(asset($projectRequest->document)); ?>" target="_blank">(Görüntüle)</a>
                                                            <?php endif; ?>
                                                        </label>
                                                        <input type="file" name="document" class="form-control" id="belge">

                                                    </div>
                                                </div>
                                                <div class="w-100 text-right">
                                                    <button class="edit-btn mt-3 text-right text-white" type="submit">Kaydet</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
            crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/promoter/project/upload.blade.php ENDPATH**/ ?>