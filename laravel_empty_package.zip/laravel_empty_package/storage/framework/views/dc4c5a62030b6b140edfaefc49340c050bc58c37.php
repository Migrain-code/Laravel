<?php $__env->startSection('title','Girişimci Paneli'); ?>
<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('assets/bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="site-content">
        <div id="content" class="site-content">
            <div data-elementor-type="wp-page" data-elementor-id="5403" class="elementor elementor-5403">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-0990d27 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="0990d27" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div
                            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a6937a"
                            data-id="5a6937a" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-312a8ac elementor-widget elementor-widget-radiant-custom-heading"
                                    data-id="312a8ac" data-element_type="widget"
                                    data-widget_type="radiant-custom-heading.default">
                                    <div class="elementor-widget-container">
                                        <div class="rt-hover-heading ">
                                            <h1 class="rt-title-heading"><span class="head-txt"></span><span class="highlight-after-text"> </span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <div class="container">

                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <div class="card widget-item">
                                <div class="row g-0">
                                    <div class="col-md-2">
                                        <img src="<?php echo e(storage(auth()->user()->profile)); ?>"
                                             class="img-fluid rounded-start w-100" alt="...">
                                    </div>
                                    <div class="col-md-10">
                                        <div class="card-body">
                                            <h4 class="card-title"><?php echo e(auth()->user()->name.' '.auth()->user()->surname); ?></h4>
                                            <h6>Girişimci</h6>
                                            <p class="card-title"><?php echo e(auth()->user()->email); ?></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <?php if(session('response')): ?>
                            <div class="alert alert-<?php echo e(session('response.class')); ?>">
                                <?php echo e(session('response.message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="col-lg-3 mb-3">
                            <div class="card widget-item">
                                <div class="about-me">
                                    <ul class="nav flex-column about-author-menu">
                                        <li><a href="#one" data-bs-toggle="tab" class="active">Profilim</a></li>
                                        <li><a href="#two" data-bs-toggle="tab">Başvurularım</a></li>
                                        <li><a href="#create-project-request" data-bs-toggle="tab">Girişim Başvurusu</a></li>
                                        <li><a href="#three" data-bs-toggle="tab">Şifremi Güncelle</a></li>
                                        <li><a href="javascript:void(0)" onclick="$('#logout-form').submit()">Güvenli Çıkış</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="about-description">
                                <div class="tab-content">
                                    <div class="tab-pane fade active show" id="one">
                                        <div class="work-zone">
                                            <form method="post" action="<?php echo e(route('promoter.profile.update')); ?>"
                                                  enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="author-desc-title d-flex">
                                                    <h6 class="author">Profilim</h6>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1"
                                                           class="form-label">Adınız</label>
                                                    <input type="text" name="name" class="form-control"
                                                           id="exampleFormControlInput1"
                                                           value="<?php echo e(auth()->user()->name); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1"
                                                           class="form-label">Soyadınız</label>
                                                    <input type="text" name="surname" class="form-control"
                                                           id="exampleFormControlInput1"
                                                           value="<?php echo e(auth()->user()->surname); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">E-posta
                                                        Adresiniz</label>
                                                    <input type="email" name="email" class="form-control"
                                                           id="exampleFormControlInput1"
                                                           value="<?php echo e(auth()->user()->email); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="phone" class="form-label">Telefon Numaranız</label>
                                                    <input type="text" name="phone" class="form-control"
                                                           id="phone"
                                                           value="<?php echo e(auth()->user()->phone); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="formFile" class="form-label">Profil Fotoğrafını
                                                        Değiştir
                                                        (270x270)</label>
                                                    <input class="form-control" type="file" name="profile"
                                                           id="formFile">
                                                </div>
                                                <div class="w-100 text-right">
                                                    <button class="edit-btn mt-3 text-right" type="submit"
                                                            name="profile-update">Profil'i Güncelle
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="two">
                                        <div class="work-zone">
                                            <div class="author-desc-title d-flex">
                                                <h6 class="author">Başvurularım</h6>
                                            </div>
                                            <div class="row mt-2">
                                                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->projectRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <div class="col-md-6">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h5 class="card-title">
                                                                    <?php echo e($row->name); ?>

                                                                    <?php switch($row->status):
                                                                        case (0): ?>
                                                                            <span class="text-warning small">(<?php echo e($row->getStatus()); ?>)</span>
                                                                        <?php break; ?>
                                                                        <?php case (1): ?>
                                                                        <span class="text-success small">(<?php echo e($row->getStatus()); ?>)</span>
                                                                        <?php break; ?>
                                                                        <?php case (2): ?>
                                                                        <span class="text-danger small">(<?php echo e($row->getStatus()); ?>)</span>
                                                                        <?php break; ?>
                                                                    <?php endswitch; ?>
                                                                </h5>
                                                                <p class="card-text"><?php echo e(str($row->short_detail)->limit(85)); ?></p>
                                                                <a class="edit-btn mt-3 text-right" href="<?php echo e(route('promoter.project.show',$row->id)); ?>"
                                                                        name="profile-update">Başvuruyu İncele
                                                                </a>
                                                                <?php if($row->status==1): ?>
                                                                <a class="edit-btn mt-3 text-right" style="background-color:black;color:white" href="<?php echo e(route('promoter.project.uploadForm', $row->id)); ?>">Başvuru Belge
                                                                </a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <div class="alert alert-danger">Girişi talebiniz bulunamadı !</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="create-project-request">
                                        <div class="work-zone">
                                            <?php echo $__env->make('promoter.project.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="three">
                                        <div class="work-zone">
                                            <form method="POST" action="<?php echo e(route('promoter.profile.change-password')); ?>"
                                                  enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="author-desc-title d-flex">
                                                    <h6 class="author">Şifre Değiştir</h6>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Yeni
                                                        Şifrenizi Giriniz</label>
                                                    <input type="password" class="form-control" name="password"
                                                           id="exampleFormControlInput1" placeholder="">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Yeni
                                                        Şifrenizi Tekrar Giriniz</label>
                                                    <input type="password" class="form-control"
                                                           name="password_confirmation" id="exampleFormControlInput1"
                                                           placeholder="">
                                                    <div class="w-100 text-right">
                                                        <button class="edit-btn mt-3 text-right" type="submit"
                                                                name="password-update">Şifreyi Güncelle
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
            crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/promoter/home.blade.php ENDPATH**/ ?>