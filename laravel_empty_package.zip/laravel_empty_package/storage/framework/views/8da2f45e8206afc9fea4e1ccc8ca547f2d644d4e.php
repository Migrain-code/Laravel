
<?php $__env->startSection('title', 'Hakkımızda'); ?>
<?php $__env->startSection('content'); ?>
   <div class="content-wrapper">
      <div class="container-fluid">
         <!-- Breadcrumb-->
         <div class="row pt-2 pb-2">
            <div class="col-sm-9">
               <h4 class="page-title">Hakkımızda</h4>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="javascript:void(0)"> Hakkımızda Sayfası</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Düzenle</li>
               </ol>
            </div>
         </div>
         <!-- End Breadcrumb-->


         <div class="row">

            <div class="col-lg-12">
               <div class="card">
                  <div class="card-body">
                     <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                           <button type="button" class="close" data-dismiss="alert">×</button>
                           <div class="alert-icon">
                              <i class="fa fa-check"></i>
                           </div>
                           <div class="alert-message">
                              <span><strong>Başarılı!</strong> Hakkımızda Bilgileri Güncellendi</span>
                           </div>
                        </div>
                     <?php endif; ?>
                     <div class="card-title text-success">Hakkımızda Güncelle</div>
                     <div class="col-lg-12 text-center">
                        <div class="col-lg-12">
                           <div id="accordion1">
                              <div class="card mb-2">
                                 <form action="<?php echo e(route('admin.about.update', $about->id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <!--=====================================Banner Edit =======================================-->
                                       <div class="card-header bg-dark">
                                          <a onclick="javascript:void(0)" class="btn btn-link shadow-none collapsed text-white" data-toggle="collapse" data-target="#collapse-1" aria-expanded="false" aria-controls="collapse-1">
                                             Banner Düzenle
                                          </a>
                                       </div>
                                       <div id="collapse-1" class="collapse show" data-parent="#accordion1" style="">
                                          <div class="card-body text-left">
                                                <div class="row">
                                                   <div class="form-group col-md-6">
                                                      <label for="title">Banner Başlık</label>
                                                      <input type="text" class="form-control form-control-rounded" value="<?php echo e($about->bannerTitle); ?>" name="bannerTitle" required="" id="title" placeholder="Başlık">
                                                   </div>
                                                   <div class="form-group col-md-6">
                                                      <label for="subtitle">Banner Alt Başlık</label>
                                                      <input type="text" class="form-control form-control-rounded" name="bannerSubTitle" value="<?php echo e($about->bannerSubtitle); ?>" required="" id="subtitle" placeholder="Alt Başlık">
                                                   </div>
                                                   <div class="form-group col-md-6">
                                                      <label for="image">Banner Resim</label>
                                                      <input type="file" class="form-control form-control-rounded" name="bannerImage" id="image" placeholder="">
                                                   </div>
                                                </div>
                                          </div>
                                       </div>
                                    <!--=====================================Banner Edit End =======================================-->
                                    <!--=====================================Part 1 =======================================-->
                                       <div class="card-header bg-dark">
                                          <a class="btn btn-link shadow-none collapsed text-white" data-toggle="collapse" data-target="#collapse-2" aria-expanded="false" aria-controls="collapse-2">
                                             1.Bölüm Düzenle
                                          </a>
                                       </div>
                                       <div id="collapse-2" class="collapse" data-parent="#accordion1" style="">
                                          <div class="card-body text-left">
                                             <div class="row">
                                                <div class="form-group col-md-6">
                                                   <label for="title">1.Bölüm Başlık</label>
                                                   <input type="text" class="form-control form-control-rounded" name="sec1Title" value="<?php echo e($about->sec1Title); ?>" required id="title" placeholder="Başlık">
                                                   <div class="form-group">
                                                      <label for="sec1SubTitle">1.Bölüm Açıklama</label>
                                                      <textarea class="form-control" name="sec1SubTitle" required rows="7" cols="60" placeholder="Açıklama"><?php echo e($about->sec1SubTitle); ?></textarea>
                                                   </div>
                                                </div>

                                                <div class="col-lg-6">
                                                   <div id="accordion7">
                                                      <div class="card mb-2">
                                                         <div class="card-header">
                                                            <a class="btn btn-link text-primary shadow-none collapsed" data-toggle="collapse" data-target="#collapse-19" aria-expanded="false" aria-controls="collapse-19">
                                                               Kutu 1
                                                            </a>
                                                         </div>

                                                         <div id="collapse-19" class="collapse" data-parent="#accordion7" style="">
                                                            <div class="card-body">
                                                               <div class="card-body">
                                                                  <div class="form-group row">
                                                                     <label for="input-16" class="col-sm-2 col-form-label">Başlık</label>
                                                                     <div class="col-sm-10">
                                                                        <input type="text" name="box1[b1][title]" value="<?php echo e($about->sec1boxes->b1->title); ?>" class="form-control form-control-square" id="input-16" placeholder="Başlık">
                                                                     </div>
                                                                  </div>
                                                                  <div class="form-group row">
                                                                     <label for="input-17" class="col-sm-2 col-form-label">İçerik</label>
                                                                     <div class="col-sm-10">
                                                                        <input type="text" name="box1[b1][content]" value="<?php echo e($about->sec1boxes->b1->content); ?>" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                                     </div>
                                                                  </div>

                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                      <div class="card mb-2">
                                                         <div class="card-header">
                                                            <a class="btn btn-link text-warning shadow-none collapsed" data-toggle="collapse" data-target="#collapse-20" aria-expanded="false" aria-controls="collapse-20">
                                                               Kutu 2
                                                            </a>
                                                         </div>
                                                         <div id="collapse-20" class="collapse" data-parent="#accordion7">
                                                            <div class="card-body">
                                                               <div class="card-body">
                                                                  <div class="form-group row">
                                                                     <label for="input-16" class="col-sm-2 col-form-label">Başlık</label>
                                                                     <div class="col-sm-10">
                                                                        <input type="text" name="box1[b2][title]" value="<?php echo e($about->sec1boxes->b2->title); ?>" class="form-control form-control-square" id="input-16" placeholder="Başlık">
                                                                     </div>
                                                                  </div>
                                                                  <div class="form-group row">
                                                                     <label for="input-17" class="col-sm-2 col-form-label">İçerik</label>
                                                                     <div class="col-sm-10">
                                                                        <input type="text" name="box1[b2][content]" value="<?php echo e($about->sec1boxes->b2->content); ?>" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                                     </div>
                                                                  </div>

                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                      <div class="card" style="margin-bottom: 10px">
                                                         <div class="card-header">
                                                            <a class="btn btn-link text-dark shadow-none collapsed" data-toggle="collapse" data-target="#collapse-21" aria-expanded="false" aria-controls="collapse-21">
                                                               Kutu 3
                                                            </a>
                                                         </div>
                                                         <div id="collapse-21" class="collapse" data-parent="#accordion7">
                                                            <div class="card-body">
                                                                  <div class="form-group row">
                                                                     <label for="input-16" class="col-sm-2 col-form-label">Başlık</label>
                                                                     <div class="col-sm-10">
                                                                        <input type="text" name="box1[b3][title]" value="<?php echo e($about->sec1boxes->b3->title); ?>" class="form-control form-control-square" id="input-16" placeholder="Başlık">
                                                                     </div>
                                                                  </div>
                                                                  <div class="form-group row">
                                                                     <label for="input-17" class="col-sm-2 col-form-label">İçerik</label>
                                                                     <div class="col-sm-10">
                                                                        <input type="text" name="box1[b3][content]" value="<?php echo e($about->sec1boxes->b3->content); ?>" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                                     </div>
                                                                  </div>

                                                            </div>
                                                         </div>
                                                      </div>
                                                      <div class="card" style="margin-bottom: 10px">
                                                         <div class="card-header">
                                                            <a class="btn btn-link text-info shadow-none collapsed" data-toggle="collapse" data-target="#collapse-22" aria-expanded="false" aria-controls="collapse-22">
                                                               Kutu 4
                                                            </a>
                                                         </div>
                                                         <div id="collapse-22" class="collapse" data-parent="#accordion7">
                                                            <div class="card-body">
                                                               <div class="form-group row">
                                                                  <label for="input-16" class="col-sm-2 col-form-label">Başlık</label>
                                                                  <div class="col-sm-10">
                                                                     <input type="text" name="box1[b4][title]" value="<?php echo e($about->sec1boxes->b4->title); ?>" class="form-control form-control-square" id="input-16" placeholder="Başlık">
                                                                  </div>
                                                               </div>
                                                               <div class="form-group row">
                                                                  <label for="input-17" class="col-sm-2 col-form-label">İçerik</label>
                                                                  <div class="col-sm-10">
                                                                     <input type="text" name="box1[b4][content]" value="<?php echo e($about->sec1boxes->b4->content); ?>" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                                  </div>
                                                               </div>

                                                            </div>
                                                         </div>
                                                      </div>

                                                   </div>
                                                </div>

                                             </div>
                                          </div>
                                       </div>
                                    <!--=====================================Part 1 End =======================================-->

                                    <!--=====================================Part 2 =======================================-->
                                    <div class="card-header bg-dark">
                                       <a class="btn btn-link shadow-none collapsed text-white" data-toggle="collapse" data-target="#collapse-3" aria-expanded="false" aria-controls="collapse-3">
                                          2.Bölüm Düzenle
                                       </a>
                                    </div>
                                    <div id="collapse-3" class="collapse" data-parent="#accordion1" style="">
                                       <div class="card-body text-left">
                                          <div class="row">
                                             <div class="form-group col-md-6">
                                                <label for="title">2.Bölüm Başlık</label>
                                                <input type="text" class="form-control form-control-rounded" value="<?php echo e($about->sec2Title); ?>" name="sec2Title" required="" id="title" placeholder="Başlık">
                                                <div class="form-group mb-0 text-left">
                                                   <label for="subtitle">2.Bölüm Açıklama</label>
                                                   <textarea class="form-control" name="sec2description" required="" id="subtitle" placeholder="Açıklama"><?php echo e($about->sec2description); ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                   <label for="input-17"  class="col-sm-2 col-form-label">Görsel</label>
                                                   <input type="file" name="sec2Image" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                </div>
                                             </div>

                                             <div class="col-lg-6">
                                                <div id="accordion7">
                                                   <div class="card mb-2">
                                                      <div class="card-header">
                                                         <a class="btn btn-link text-primary shadow-none collapsed" data-toggle="collapse" data-target="#collapse-19" aria-expanded="false" aria-controls="collapse-19">
                                                            Kutu 1
                                                         </a>
                                                      </div>

                                                      <div id="collapse-19" class="collapse show" data-parent="#accordion7" style="">
                                                         <div class="card-body">
                                                            <div class="card-body">
                                                               <div class="form-group row">
                                                                  <label for="input-16" class="col-sm-2 col-form-label">Başlık</label>
                                                                  <div class="col-sm-10">
                                                                     <input type="text" name="box2[b1][title]" value="<?php echo e($about->sec2boxes->b1->title); ?>" class="form-control form-control-square" id="input-16" placeholder="Başlık">
                                                                  </div>
                                                               </div>
                                                               <div class="form-group row">
                                                                  <label for="input-17"  class="col-sm-2 col-form-label">İçerik</label>
                                                                  <div class="col-sm-10">
                                                                     <input type="text" name="box2[b1][content]" value="<?php echo e($about->sec2boxes->b1->title); ?>" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <div class="card mb-2">
                                                      <div class="card-header">
                                                         <a class="btn btn-link text-warning shadow-none collapsed" data-toggle="collapse" data-target="#collapse-20" aria-expanded="false" aria-controls="collapse-20">
                                                            Kutu 2
                                                         </a>
                                                      </div>
                                                      <div id="collapse-20" class="collapse" data-parent="#accordion7">
                                                         <div class="card-body">
                                                            <div class="card-body">
                                                               <div class="form-group row">
                                                                  <label for="input-16" class="col-sm-2 col-form-label">Başlık</label>
                                                                  <div class="col-sm-10">
                                                                     <input type="text" name="box2[b2][title]" value="<?php echo e($about->sec2boxes->b2->title); ?>" class="form-control form-control-square" id="input-16" placeholder="Başlık">
                                                                  </div>
                                                               </div>
                                                               <div class="form-group row">
                                                                  <label for="input-17" class="col-sm-2 col-form-label">İçerik</label>
                                                                  <div class="col-sm-10">
                                                                     <input type="text" name="box2[b2][content]" value="<?php echo e($about->sec2boxes->b2->title); ?>" class="form-control form-control-square" id="input-17" placeholder="İçerik">
                                                                  </div>
                                                               </div>

                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>

                                          </div>
                                       </div>
                                    </div>
                                    <!--=====================================Part 2 End=======================================-->
                                    <div class="form-group mt-3">
                                       <button type="submit" class="btn btn-success btn-round shadow-success px-5 w-50">Güncelle
                                       </button>
                                    </div>

                                 </form>
                              </div>
                           </div>
                        </div>

                     </div>

                  </div>
               </div>
            </div>
         </div>
         <!--End Row-->


      </div>
      <!-- End container-fluid-->
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammet\Desktop\girisimci_son_revize\resources\views/admin/about/edit.blade.php ENDPATH**/ ?>