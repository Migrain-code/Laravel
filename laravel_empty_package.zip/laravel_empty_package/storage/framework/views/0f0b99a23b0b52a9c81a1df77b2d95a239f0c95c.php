 <?php $__env->startSection('title','İletişim'); ?> <?php $__env->startSection('content'); ?>
    <div data-elementor-type="wp-page" data-elementor-id="5243" class="elementor elementor-5243" style="background-color: #f1f6ff;">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-551f258 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="551f258"
            data-element_type="section"
            data-settings='{"background_background":"gradient"}'
        >
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default about-left-area">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-85d17fc" data-id="85d17fc" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated" style="padding: 60px;">
                        <div class="elementor-element elementor-element-68f4dca elementor-widget elementor-widget-heading" data-id="68f4dca" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h1 class="elementor-heading-title elementor-size-default">İşinizi Birlikte Büyütelim</h1></div>
                        </div>
                        <div class="elementor-element elementor-element-ec52720 elementor-widget elementor-widget-text-editor" data-id="ec52720" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem risus pretium et odio montes,
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-7165fed elementor-widget elementor-widget-image" data-id="7165fed" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img
                                    width="552"
                                    height="353"
                                    src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/contact-img-2.0-1.png"
                                    class="attachment-full size-full"
                                    alt=""
                                    loading="lazy"
                                    srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/contact-img-2.0-1.png 552w, https://adventz.radiantthemes.com/wp-content/uploads/2022/06/contact-img-2.0-1-300x192.png 300w"
                                    sizes="(max-width: 552px) 100vw, 552px"
                                    data-no-retina=""
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-f99153b" data-id="f99153b" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated contact-right-area">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-d6ec024 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="d6ec024"
                            data-element_type="section"
                            data-settings='{"background_background":"classic"}'
                        >
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-ee1a2d8" data-id="ee1a2d8" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated" style="padding-top: 40px;">
                                        <div class="elementor-element elementor-element-54216ad elementor-widget elementor-widget-heading" data-id="54216ad" data-element_type="widget" data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h4 class="elementor-heading-title elementor-size-default" style="padding-bottom: 15px;">Bizimle İletişime geç</h4></div>
                                        </div>

                                        <div class="elementor-element elementor-element-4a8c936 elementor-widget elementor-widget-shortcode" data-id="4a8c936" data-element_type="widget" data-widget_type="shortcode.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-shortcode">
                                                    <div role="form" class="" id="">
                                                        <div class="screen-reader-response">
                                                            <?php if(session('response')): ?>
                                                                <div class="alert alert-<?php echo e(session('response.class')); ?>">
                                                                    <?php echo e(session('response.message')); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                            <?php if($errors->any()): ?>
                                                                <div class="alert alert-danger">
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li><?php echo e($error); ?></li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <form action="" method="post" class="wpcf7-form init" novalidate>
                                                            <?php echo csrf_field(); ?>
                                                            <div class="contact_us_two_frm">
                                                                <div class="row">
                                                                    <div class="col-lg-12 col-md-12 col-xs-12 no-padding">
                                                                        <div class="form-row">
                                                                        <span class="wpcf7-form-control-wrap text-160">
                                                                            <input

                                                                                type="text"
                                                                                name="name"
                                                                                value=""
                                                                                size="40"
                                                                                class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                                aria-required="true"
                                                                                aria-invalid="false"
                                                                                placeholder="Ad Soyad"
                                                                            />
                                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 col-md-6 col-xs-12 no-padding">
                                                                        <div class="form-row">
                                                                        <span class="wpcf7-form-control-wrap email-470">
                                                                            <input
                                                                                required
                                                                                type="email"
                                                                                name="email"
                                                                                value=""
                                                                                size="40"
                                                                                class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email"
                                                                                aria-required="true"
                                                                                aria-invalid="false"
                                                                                placeholder="E-Posta"
                                                                            />
                                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6 col-md-6 col-xs-12 no-padding">
                                                                        <div class="form-row">
                                                                        <span class="wpcf7-form-control-wrap text-161">
                                                                            <input
                                                                                required
                                                                                type="text"
                                                                                name="phone"
                                                                                value=""
                                                                                size="40"
                                                                                class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                                aria-required="true"
                                                                                aria-invalid="false"
                                                                                placeholder="Telefon"
                                                                            />
                                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-12 col-md-12 col-xs-12 no-padding">
                                                                        <div class="form-row">
                                                                        <span class="wpcf7-form-control-wrap textarea-739">
                                                                            <textarea
                                                                                required
                                                                                name="message"
                                                                                cols="40"
                                                                                rows="10"
                                                                                class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required"
                                                                                aria-required="true"
                                                                                aria-invalid="false"
                                                                                placeholder="Mesaj"
                                                                            ></textarea>
                                                                        </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-6 col-md-6 col-xs-12 no-padding p-btn ml-auto">
                                                                        <div class="form-row submit-btn" style="background-color: #0d66c2;">
                                                                        <span class="placeholder">
                                                                            <input type="submit" value="Gönder" class="wpcf7-form-controlr" style="background-color: #0d66c2;" />
                                                                            <span class="wpcf7-spinner"></span>
                                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            style="margin-bottom: 30px; margin-top: 40px;"
            class="elementor-section elementor-top-section elementor-element elementor-element-0b6adc6 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="0b6adc6"
            data-element_type="section"
        >
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-5a04eaf" data-id="5a04eaf" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            style="padding: 60px; background-color: #f6dca3; border-radius: 0px 56px 0px 56px;"
                            class="elementor-section elementor-inner-section elementor-element elementor-element-c7e09d0 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="c7e09d0"
                            data-element_type="section"
                            data-settings='{"background_background":"classic"}'
                        >
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-d0a97da" data-id="d0a97da" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-de44557 elementor-vertical-align-middle elementor-position-left elementor-widget elementor-widget-image-box"
                                            data-id="de44557"
                                            data-element_type="widget"
                                            data-widget_type="image-box.default"
                                        >
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper d-flex flex-column">
                                                    <figure class="elementor-image-box-img">
                                                        <img
                                                            width="51"
                                                            height="61"
                                                            src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/location-contact-us.png"
                                                            class="attachment-full size-full"
                                                            alt=""
                                                            loading="lazy"
                                                            data-no-retina=""
                                                        />
                                                    </figure>
                                                    <div class="elementor-image-box-content text-center mt-4">
                                                        <h5 class="elementor-image-box-title">Adresimiz</h5>
                                                        <span><?php echo e(config('settings.address')); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-1d3e0a9" data-id="1d3e0a9" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            style="padding: 75px; border-radius: 0px 56px 0px 56px; background-color: #eaf5e6;"
                            class="elementor-section elementor-inner-section elementor-element elementor-element-e2e0d18 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="e2e0d18"
                            data-element_type="section"
                            data-settings='{"background_background":"classic"}'
                        >
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-38c49b6" data-id="38c49b6" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-5e22070 elementor-vertical-align-middle elementor-position-left elementor-widget elementor-widget-image-box"
                                            data-id="5e22070"
                                            data-element_type="widget"
                                            data-widget_type="image-box.default"
                                        >
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper d-flex flex-column">
                                                    <figure class="elementor-image-box-img">
                                                        <img
                                                            width="75"
                                                            height="61"
                                                            src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/mail-contact-us.png"
                                                            class="attachment-full size-full"
                                                            alt=""
                                                            loading="lazy"
                                                            data-no-retina=""
                                                        />
                                                    </figure>
                                                    <div class="elementor-image-box-content text-center mt-4">
                                                        <h5 class="elementor-image-box-title">Mail Adresi</h5>
                                                        <span><a href="mailto:info@example.com"><?php echo e(config('settings.email')); ?></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-8184e98" data-id="8184e98" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-7992ad3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="7992ad3"
                            data-element_type="section"
                            data-settings='{"background_background":"classic"}'
                        >
                            <div class="elementor-container elementor-column-gap-default">
                                <div
                                    style="padding: 75px; background-color: #f3d4d8; border-radius: 0px 56px 0px 56px;"
                                    class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-a414d91"
                                    data-id="a414d91"
                                    data-element_type="column"
                                >
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div
                                            class="elementor-element elementor-element-54ead91 elementor-vertical-align-middle elementor-position-left elementor-widget elementor-widget-image-box"
                                            data-id="54ead91"
                                            data-element_type="widget"
                                            data-widget_type="image-box.default"
                                        >
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper d-flex flex-column">
                                                    <figure class="elementor-image-box-img">
                                                        <img
                                                            width="62"
                                                            height="61"
                                                            src="https://adventz.radiantthemes.com/wp-content/uploads/2022/06/call-contact-us.png"
                                                            class="attachment-full size-full"
                                                            alt=""
                                                            loading="lazy"
                                                            data-no-retina=""
                                                        />
                                                    </figure>
                                                    <div class="elementor-image-box-content text-center mt-4">
                                                        <h5 class="elementor-image-box-title">Telefon</h5>
                                                        <span><a href="tel:<?php echo e(config('settings.phone')); ?>"><?php echo e(config('settings.phone')); ?></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0833636/public_html/project/resources/views/contact.blade.php ENDPATH**/ ?>