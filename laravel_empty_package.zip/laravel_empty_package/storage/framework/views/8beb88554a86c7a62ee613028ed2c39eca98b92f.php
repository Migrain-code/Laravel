<?php $__env->startSection('title','Haberler'); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet"
          href="<?php echo e(asset('assets/wp-content/litespeed/css/6c771fb36b8b739154ed3e3b23d44849f15a.css?ver=76eeb')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wraper_blog_main style-one clasic-box-layout">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12 order-lg-1 order-sm-1">
                    <div class="blog_main">
                        <div class="row blog-posts">
                            <article id="post-1673" class="blog-item style-one post">
                                <div class="holder">
                                    <div class="pic">
                                        <a class="pic-main" href="https://adventz.radiantthemes.com/try-the-new-product/">
                                            <img src="<?php echo e(asset('assets/wp-content/uploads/2022/02/blog-img-15-2.j')); ?>pg" alt="Try the new Product" data-no-retina="">
                                        </a></div>
                                    <div class="data">
                                        <div class="post-meta">
                                            <span class="date">February 09, 2022</span></div>
                                        <h4 class="title">
                                            <a href="https://adventz.radiantthemes.com/try-the-new-product/">Try
                                                the new Product</a></h4>
                                        <div class="entry-content"><p>Curabitur at fermentum purus. Interdum et
                                                malesuada fames ac ante ipsum primis in faucibus...</p>
                                            <div class="entry-extra-item text-left">
                                                <div class="post-read-more">
                                                    <a class="btn" href="https://adventz.radiantthemes.com/try-the-new-product/" data-hover="Read More"><span>Read More</span></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article id="post-1678" class="blog-item style-one post">
                                <div class="holder">
                                    <div class="pic">
                                        <a class="pic-main" href="https://adventz.radiantthemes.com/cool-merchandise/">
                                            <img src="<?php echo e(asset('assets/wp-content/uploads/2022/02/blog-img-14-2-1.j')); ?>pg" alt="Cool Merchandise" data-no-retina="">
                                        </a></div>
                                    <div class="data">
                                        <div class="post-meta">
                                            <span class="date">February 09, 2022</span></div>
                                        <h4 class="title">
                                            <a href="https://adventz.radiantthemes.com/cool-merchandise/">Cool
                                                Merchandise</a></h4>
                                        <div class="entry-content"><p>Curabitur at fermentum purus. Interdum et
                                                malesuada fames ac ante ipsum primis in faucibus...</p>
                                            <div class="entry-extra-item text-left">
                                                <div class="post-read-more">
                                                    <a class="btn" href="https://adventz.radiantthemes.com/cool-merchandise/" data-hover="Read More"><span>Read More</span></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article id="post-1680" class="blog-item style-one post">
                                <div class="holder">
                                    <div class="pic">
                                        <a class="pic-main" href="https://adventz.radiantthemes.com/boost-your-business/">
                                            <img src="<?php echo e(asset('assets/wp-content/uploads/2022/02/blog-img-12-2.jpg')); ?>" alt="Boost Your Business" data-no-retina="">
                                        </a></div>
                                    <div class="data">
                                        <div class="post-meta">
                                            <span class="date">February 09, 2022</span></div>
                                        <h4 class="title">
                                            <a href="https://adventz.radiantthemes.com/boost-your-business/">Boost
                                                Your Business</a></h4>
                                        <div class="entry-content"><p>Proin vestibulum gravida nulla nec cursus.
                                                Fusce tincidunt, dignissim ex sit amet, loborti...</p>
                                            <div class="entry-extra-item text-left">
                                                <div class="post-read-more">
                                                    <a class="btn" href="https://adventz.radiantthemes.com/boost-your-business/" data-hover="Read More"><span>Read More</span></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article id="post-5618" class="blog-item style-one post">
                                <div class="holder">
                                    <div class="pic">
                                        <a class="pic-main" href="https://adventz.radiantthemes.com/online-fashion-store/">
                                            <img src="<?php echo e(asset('assets/wp-content/uploads/2022/02/blog-7-1.jpg')); ?>" alt="Online Fashion Store" data-no-retina="">
                                        </a></div>
                                    <div class="data">
                                        <div class="post-meta">
                                            <span class="date">February 22, 2022</span></div>
                                        <h4 class="title">
                                            <a href="https://adventz.radiantthemes.com/online-fashion-store/">Online
                                                Fashion Store</a></h4>
                                        <div class="entry-content"><p>Curabitur at fermentum purus. Interdum et
                                                malesuada fames ac ante ipsum primis in faucibus...</p>
                                            <div class="entry-extra-item text-left">
                                                <div class="post-read-more">
                                                    <a class="btn" href="https://adventz.radiantthemes.com/online-fashion-store/" data-hover="Read More"><span>Read More</span></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>


                        </div>
                    </div>
                    <div class="pagination clearfix">
                        <span class="page-numbers current">1</span>
                        <a class="page-numbers" href="page/2/index.html">2</a>
                        <a class="next page-numbers" href="page/2/index.html"><span class="lnr lnr-arrow-right"></span></a></div>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 order-lg-12 order-sm-12 right-sidebar">
                    <aside id="secondary" class="widget-area">
                        <section id="block-2" class="widget widget_block widget_search">
                            <form role="search" method="get" action="https://adventz.radiantthemes.com/" class="wp-block-search__button-outside wp-block-search__text-button wp-block-search">
                                <label for="wp-block-search__input-1" class="wp-block-search__label">Search</label>
                                <div class="wp-block-search__inside-wrapper " style="width: 666px"><input type="search" id="wp-block-search__input-1" class="wp-block-search__input " name="s" value="" placeholder="" required="">
                                    <button type="submit" class="wp-block-search__button  ">Search</button>
                                </div>
                            </form>
                        </section>
                        <section id="block-14" class="widget widget_block"><h5>About Us</h5></section>
                        <section id="block-13" class="widget widget_block widget_text"><p>Aliqm lorem ante,
                                dapibus in, viverra quis, feugiat Phasellus aut ms varius laoreet srtrum aenean
                                imperdiet. Etiam ult augue srtrum aenean.</p></section>
                        <section id="block-3" class="widget widget_block">
                            <div class="wp-container-1 wp-block-group">
                                <div class="wp-block-group__inner-container"><h5>Categories</h5></div>
                            </div>
                        </section>
                        <section id="block-5" class="widget widget_block">
                            <div class="wp-container-2 wp-block-group">
                                <div class="wp-block-group__inner-container">
                                    <ul class="wp-block-categories-list wp-block-categories">
                                        <li class="cat-item cat-item-56"><a href="https://adventz.radiantthemes.com/category/business/">Business</a>
                                            (6)
                                        </li>
                                        <li class="cat-item cat-item-7"><a href="https://adventz.radiantthemes.com/category/consulting/">Consulting</a>
                                            (2)
                                        </li>
                                        <li class="cat-item cat-item-54"><a href="https://adventz.radiantthemes.com/category/corporate/">Corporate</a>
                                            (1)
                                        </li>
                                        <li class="cat-item cat-item-55"><a href="https://adventz.radiantthemes.com/category/design/">Design</a>
                                            (2)
                                        </li>
                                        <li class="cat-item cat-item-93"><a href="https://adventz.radiantthemes.com/category/fashion/">Fashion</a>
                                            (5)
                                        </li>
                                        <li class="cat-item cat-item-57"><a href="https://adventz.radiantthemes.com/category/marketing/">Marketing</a>
                                            (3)
                                        </li>
                                        <li class="cat-item cat-item-92"><a href="https://adventz.radiantthemes.com/category/shopping/">Shopping</a>
                                            (7)
                                        </li>
                                        <li class="cat-item cat-item-38"><a href="https://adventz.radiantthemes.com/category/technology/">Technology</a>
                                            (5)
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </section>
                        <section id="block-10" class="widget widget_block"><h5><strong>Recent Post</strong></h5>
                        </section>
                        <section id="radiantthemes_recent_posts_widget-2" class="widget widget_radiantthemes_recent_posts_widget">
                            <div class="rt-recent-post-with-thumbnail element-one"><h6 class="widget-title"></h6>
                                <ul class="rt-recent-post-with-thumbnail-holder">
                                    <li class="rt-recent-post-with-thumbnail-post">
                                        <div class="blog-widget-post">
                                            <div class="blog-widget-post-img">
                                                <a href="https://adventz.radiantthemes.com/business-conference/"><img width="71" height="71" src="../wp-content/uploads/2022/02/blog-1-1-150x150.jpg" class="attachment-120x71 size-120x71 wp-post-image" alt="" loading="lazy" srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-1-1-150x150.jpg 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-1-1-300x300.jpg 300w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-1-1-100x100.jpg 100w" sizes="(max-width: 71px) 100vw, 71px" data-no-retina=""></a></div>
                                            <div class="blog-widget-post-content"><h6 class="blog-widget-title">
                                                    <a href="https://adventz.radiantthemes.com/business-conference/">
                                                        Easy To Create New </a></h6>
                                                <div class="blog-widget-date"><p class="excerpt">22 February,
                                                        2022</p></div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="rt-recent-post-with-thumbnail-post">
                                        <div class="blog-widget-post">
                                            <div class="blog-widget-post-img">
                                                <a href="https://adventz.radiantthemes.com/how-to-create-your-own-style/"><img width="71" height="71" src="../wp-content/uploads/2022/02/blog-4-1-150x150.jpg" class="attachment-120x71 size-120x71 wp-post-image" alt="" loading="lazy" srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-4-1-150x150.jpg 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-4-1-300x300.jpg 300w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-4-1-100x100.jpg 100w" sizes="(max-width: 71px) 100vw, 71px" data-no-retina=""></a></div>
                                            <div class="blog-widget-post-content"><h6 class="blog-widget-title">
                                                    <a href="https://adventz.radiantthemes.com/how-to-create-your-own-style/">
                                                        How to Create Your </a></h6>
                                                <div class="blog-widget-date"><p class="excerpt">22 February,
                                                        2022</p></div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="rt-recent-post-with-thumbnail-post">
                                        <div class="blog-widget-post">
                                            <div class="blog-widget-post-img">
                                                <a href="https://adventz.radiantthemes.com/unique-business-solutions/"><img width="71" height="71" src="../wp-content/uploads/2022/02/blog-2-1-150x150.jpg" class="attachment-120x71 size-120x71 wp-post-image" alt="" loading="lazy" srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-2-1-150x150.jpg 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-2-1-300x300.jpg 300w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-2-1-100x100.jpg 100w" sizes="(max-width: 71px) 100vw, 71px" data-no-retina=""></a></div>
                                            <div class="blog-widget-post-content"><h6 class="blog-widget-title">
                                                    <a href="https://adventz.radiantthemes.com/unique-business-solutions/">
                                                        Unique Business Solutions </a></h6>
                                                <div class="blog-widget-date"><p class="excerpt">22 February,
                                                        2022</p></div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="rt-recent-post-with-thumbnail-post">
                                        <div class="blog-widget-post">
                                            <div class="blog-widget-post-img">
                                                <a href="https://adventz.radiantthemes.com/unique-solution/"><img width="71" height="71" src="../wp-content/uploads/2022/02/blog-5-1-150x150.jpg" class="attachment-120x71 size-120x71 wp-post-image" alt="" loading="lazy" srcset="https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-5-1-150x150.jpg 150w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-5-1-300x300.jpg 300w, https://adventz.radiantthemes.com/wp-content/uploads/2022/02/blog-5-1-100x100.jpg 100w" sizes="(max-width: 71px) 100vw, 71px" data-no-retina=""></a></div>
                                            <div class="blog-widget-post-content"><h6 class="blog-widget-title">
                                                    <a href="https://adventz.radiantthemes.com/unique-solution/">
                                                        Unique Solution </a></h6>
                                                <div class="blog-widget-date"><p class="excerpt">22 February,
                                                        2022</p></div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </section>
                        <section id="block-9" class="widget widget_block"><h5>Tag</h5></section>
                        <section id="block-17" class="widget widget_block widget_tag_cloud"><p class="wp-block-tag-cloud"><a href="https://adventz.radiantthemes.com/tag/application/" class="tag-cloud-link tag-link-53 tag-link-position-1" style="font-size: 15.636363636364pt;" aria-label="Application (3 items)">Application</a>
                                <a href="https://adventz.radiantthemes.com/tag/corporate/" class="tag-cloud-link tag-link-50 tag-link-position-2" style="font-size: 22pt;" aria-label="Corporate (4 items)">Corporate</a>
                                <a href="https://adventz.radiantthemes.com/tag/design/" class="tag-cloud-link tag-link-49 tag-link-position-3" style="font-size: 8pt;" aria-label="Design (2 items)">Design</a>
                                <a href="https://adventz.radiantthemes.com/tag/technical/" class="tag-cloud-link tag-link-51 tag-link-position-4" style="font-size: 15.636363636364pt;" aria-label="Technical (3 items)">Technical</a></p></section>
                    </aside>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istanbulyazilim/public_html/girisim/resources/views/news.blade.php ENDPATH**/ ?>