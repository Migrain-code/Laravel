<?php $__env->startSection('title','Girişimci Paneli'); ?>
<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('assets/bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="site-content">
        <div id="content" class="site-content">
            <div data-elementor-type="wp-page" data-elementor-id="5403" class="elementor elementor-5403">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-0990d27 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="0990d27" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div
                            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a6937a"
                            data-id="5a6937a" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-312a8ac elementor-widget elementor-widget-radiant-custom-heading"
                                    data-id="312a8ac" data-element_type="widget"
                                    data-widget_type="radiant-custom-heading.default">
                                    <div class="elementor-widget-container">
                                        <div class="rt-hover-heading ">
                                            <h1 class="rt-title-heading"><span class="head-txt">
</span><span class="highlight-after-text"> </span></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <div class="container">
                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <div class="card widget-item">
                                <div class="row g-0">
                                    <div class="col-md-2">
                                        <img src="<?php echo e(storage(auth()->user()->profile)); ?>"
                                             class="img-fluid rounded-start w-100" alt="...">
                                    </div>
                                    <div class="col-md-10">
                                        <div class="card-body">
                                            <h4 class="card-title"><?php echo e(auth()->user()->name.' '.auth()->user()->surname); ?></h4>
                                            <h6>Girişimci</h6>
                                            <p class="card-title"><?php echo e(auth()->user()->email); ?></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <div class="alert alert-info">
                                <b>Başvuru Tarihi:</b> <?php echo e($projectRequest->created_at->format('d.m.Y H:i')); ?><br>
                                <b>Başvuru Durumu:</b> <?php echo e($projectRequest->getStatus('text')); ?><br>
                                <?php if($projectRequest->status == 2): ?>
                                    <b>Ret Nedeni:</b> <?php echo e($projectRequest->admin_message); ?><br>
                                <?php endif; ?>
                            </div>
                            <div class="about-description">
                                <div class="tab-content">
                                    <div class="tab-pane active show fade" id="create-project-request">
                                        <div class="work-zone">
                                            <form method="post" action="" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="author-desc-title d-flex">
                                                    <h6 class="author">Girişim Bilgileri</h6>
                                                </div>
                                                <div class="row">
                                                    <div class="mb-3 col-md-6 col-12">
                                                        <label for="name" class="form-label">Project Adı</label>
                                                        <input type="text" disabled name="name" value="<?php echo e($projectRequest->name); ?>" class="form-control" id="name">
                                                    </div>
                                                    <div class="mb-3 col-md-6 col-12">
                                                        <label for="website" class="form-label">Websitesi</label>
                                                        <input type="text" disabled name="website" value="<?php echo e($projectRequest->website); ?>" class="form-control" id="website">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="short_detail" class="form-label">Girşimin kısaca tanımı</label>
                                                        <textarea type="text" disabled name="short_detail" class="form-control" id="short_detail" cols="60" rows="10"><?php echo e($projectRequest->short_detail); ?></textarea>
                                                    </div>
                                                    <div class="mb-3 col-12 col-md-6">
                                                        <label for="purpose" class="form-label">Girişimin Yapım Amacı</label>
                                                        <select name="purpose[]" disabled class="form-control" multiple id="purpose">
                                                            <option  <?php if(in_array('Fikir',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Fikir">Fikir</option>
                                                            <option  <?php if(in_array('Prototip',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Prototip">Prototip</option>
                                                            <option  <?php if(in_array('Kullanılabilir',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Kullanılabilir">Kullanılabilir</option>
                                                            <option  <?php if(in_array('Kullanılıyor',$projectRequest->purpose)): echo 'selected'; endif; ?> value="Kullanılıyor">Kullanılıyor</option>
                                                        </select>
                                                    </div>

                                                    <div class="mb-3 col-12 col-md-6">
                                                        <label for="mission" class="form-label">Girişimdeki Göreviniz</label>
                                                        <select name="mission[]" disabled class="form-control" multiple id="mission">
                                                            <option <?php if(in_array('Kurucu',$projectRequest->mission)): echo 'selected'; endif; ?> value="Kurucu">Kurucu</option>
                                                            <option <?php if(in_array('Kurucu Ortağı',$projectRequest->mission)): echo 'selected'; endif; ?> value="Kurucu Ortağı">Kurucu Ortağı</option>
                                                            <option <?php if(in_array('Çalışan',$projectRequest->mission)): echo 'selected'; endif; ?> value="Çalışan">Çalışan</option>
                                                        </select>
                                                    </div>

                                                    <div class="mb-3 col-md-4 col-12">
                                                        <label for="degree" class="form-label">Girişimdeki Ünvanınız</label>
                                                        <input type="text" disabled class="form-control" name="degree" value="<?php echo e($projectRequest->degree); ?>" id="degree"/>
                                                    </div>
                                                    <div class="mb-3 col-12 col-md-4">
                                                        <label for="start_month" class="form-label">Projeye Ne Zaman Başladınız (Ay)</label>
                                                        <select name="start_month" disabled="" class="form-control" id="start_month">
                                                            <option value="01" <?php if($projectRequest->start_month == '01'): echo 'selected'; endif; ?>>01</option>
                                                            <option value="02" <?php if($projectRequest->start_month == '02'): echo 'selected'; endif; ?>>02</option>
                                                            <option value="03" <?php if($projectRequest->start_month == '03'): echo 'selected'; endif; ?>>03</option>
                                                            <option value="04" <?php if($projectRequest->start_month == '04'): echo 'selected'; endif; ?>>04</option>
                                                            <option value="05" <?php if($projectRequest->start_month == '05'): echo 'selected'; endif; ?>>05</option>
                                                            <option value="06" <?php if($projectRequest->start_month == '06'): echo 'selected'; endif; ?>>06</option>
                                                            <option value="07" <?php if($projectRequest->start_month == '07'): echo 'selected'; endif; ?>>07</option>
                                                            <option value="08" <?php if($projectRequest->start_month == '08'): echo 'selected'; endif; ?>>08</option>
                                                            <option value="09" <?php if($projectRequest->start_month == '09'): echo 'selected'; endif; ?>>09</option>
                                                            <option value="10" <?php if($projectRequest->start_month == '10'): echo 'selected'; endif; ?>>10</option>
                                                            <option value="11" <?php if($projectRequest->start_month == '11'): echo 'selected'; endif; ?>>11</option>
                                                            <option value="12" <?php if($projectRequest->start_month == '12'): echo 'selected'; endif; ?>>12</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3 col-12 col-md-4">
                                                        <label for="start_year" class="form-label">Projeye Ne Zaman Başladınız (Yıl)</label>
                                                        <select name="start_year" disabled class="form-control" id="start_year">
                                                            <?php for($i=now()->year-20;$i<=now()->year;$i++): ?>
                                                                <option value="<?php echo e($i); ?>" <?php if($projectRequest->start_year == $i): echo 'selected'; endif; ?>><?php echo e($i); ?></option>
                                                            <?php endfor; ?>
                                                        </select>
                                                    </div>

                                                    <div class="form-group col-md-6 col-12">
                                                        <label for="biography" class="form-label">KISA BİYOGRAFİ/ KENDİNİZİ TANITINIZ </label>
                                                        <textarea type="text" disabled class="form-control" name="biography" id="biography" cols="60" rows="10" style="width: 100%;resize: none"><?php echo e($projectRequest->biography); ?></textarea>
                                                    </div>
                                                    <div class="form-group col-md-6 col-12">
                                                        <label for="detail" class="form-label">NEDEN BAŞVURMAK İSTİYORSUNUZ ?</label>
                                                        <textarea type="text" disabled class="form-control" name="cause" id="detail" cols="60" rows="10" style="width: 100%;resize: none"><?php echo e($projectRequest->cause); ?></textarea>
                                                    </div>

                                                    <div class="form-group col-12">
                                                        <label for="detail" class="form-label">GİRİŞİM HAKKINDA ÖZET BİLGİ VERİNİZ </label>
                                                        <textarea type="text" disabled class="form-control" name="detail" id="detail" cols="60" rows="10" style="width: 100%;resize: none"><?php echo e($projectRequest->detail); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="w-100 text-right">
                                                    <a href="<?php echo e(route('promoter.home')); ?>" class="edit-btn mt-3 text-right" type="submit">Geri Dön</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
            crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\girisim\resources\views/promoter/project/show.blade.php ENDPATH**/ ?>