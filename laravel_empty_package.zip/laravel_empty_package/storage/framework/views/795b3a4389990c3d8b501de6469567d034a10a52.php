<?php $__env->startSection('title','Slider Kayıt'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Slider Kayıt</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Slider Listesi</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Slider Kayıt</li>
                    </ol>
                </div>
            </div>
            <!-- End Breadcrumb-->


            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title text-success">Slider Kayıt</div>
                            <form action="<?php echo e(route('admin.slider.update',$slider->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="title">Başlık</label>
                                        <input type="text" class="form-control form-control-rounded" name="title" value="<?php echo e($slider->title); ?>"
                                               required id="title" placeholder="Başlık">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="image">Resim <a href="<?php echo e(asset($slider->image)); ?>" target="_blank">(Görüntüle)</a></label>
                                        <input type="file" class="form-control form-control-rounded" name="image" id="image" placeholder="">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="description">Açıklama</label>
                                        <textarea name="description" id="description" class="form-control" cols="30"
                                                  rows="5"><?php echo e($slider->description); ?></textarea>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="sub_description">Alt Açıklama</label>
                                        <textarea name="sub_description" id="sub_description" class="form-control"
                                                  cols="30" rows="5"><?php echo e($slider->sub_description); ?></textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="button_text">Buton Metni</label>
                                        <input type="text" class="form-control form-control-rounded" name="button_text" value="<?php echo e($slider->button_text); ?>"
                                               required id="button_text" placeholder="Buton Metni">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="button_url">Buton Linki</label>
                                        <input type="text" class="form-control form-control-rounded" name="button_url" value="<?php echo e($slider->button_url); ?>"
                                               required id="button_url" placeholder="Buton Linki">
                                    </div>
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-success btn-round shadow-success px-5">Kaydet</button>
                                </div>


                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Row-->


        </div>
        <!-- End container-fluid-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0782468/public_html/project/resources/views/admin/slider/edit.blade.php ENDPATH**/ ?>