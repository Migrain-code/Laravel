<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
<footer class="footer position-fixed">
    <div class="container">
        <div class="text-center">
            Copyright © 2022 <a href="https://www.hst.world/" target="_blank"><b style="padding-left:5px">hst.world</b></a>
        </div>
    </div>
</footer>
<!--End footer-->
<?php /**PATH /home/u0782468/public_html/project/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>