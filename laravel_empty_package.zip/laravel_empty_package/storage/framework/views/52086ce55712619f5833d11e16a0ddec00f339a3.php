<?php $__env->startSection('title','deneme'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wraper_blog_main default-page">
        <div class="container page-container">
            <article id="post-2568" class="entry post-2568 page type-page status-publish hentry">
                <header class="entry-header">
                </header>
                <div class="entry-content">
                    <h2 class="entry-title">Girişimci Girişi</h2> <div class="woocommerce"><div class="woocommerce-notices-wrapper"></div>
                        <form class="woocommerce-form woocommerce-form-login login" method="post">
                            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                <label for="username">Eposta Adresi&nbsp;<span class="required">*</span></label>
                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value=""> </p>
                            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                <label for="password">Şifre&nbsp;<span class="required">*</span></label>
                                <span class="password-input">
                                    <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password">
                                </span>
                            </p>
                            <p class="form-row">

                                <input type="hidden" id="woocommerce-login-nonce" name="woocommerce-login-nonce" value="3b215ece13">
                                <input type="hidden" name="_wp_http_referer" value="/my-account/">
                                <button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="Log in">Giriş Yap</button>
                            </p>
                            <p class="woocommerce-LostPassword lost_password">
                                <a href="https://adventz.radiantthemes.com/my-account/lost-password/">Şifremi Unuttum</a>
                            </p>
                        </form>
                    </div>
                </div>
            </article>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istanbulyazilim/public_html/girisim/resources/views/promoter_login.blade.php ENDPATH**/ ?>