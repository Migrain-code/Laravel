<?php $__env->startSection('title','Evet'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .elementor-36153 .elementor-element.elementor-element-a466396 .elementor-image-box-wrapper .elementor-image-box-img {
            width: 55%;
        }
        .elementor-36153 .elementor-element.elementor-element-a466396.elementor-position-left .elementor-image-box-img {
             margin-right:0px;
        }
        .elementor-36153 .elementor-element.elementor-element-411e7a6 .elementor-image-box-wrapper .elementor-image-box-img {
            width: 55%;
        }
        .elementor-36153 .elementor-element.elementor-element-411e7a6.elementor-position-left .elementor-image-box-img {
            margin-right: 0px;
        }
        .elementor-36153 .elementor-element.elementor-element-a466396 > .elementor-widget-container {
            margin: 0 0 40px;
            padding: 19px 10px 13px 8px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0px 0px 40px 0px rgb(0 0 0 / 8%);
        }
        .elementor-36153 .elementor-element.elementor-element-411e7a6 > .elementor-widget-container {
            margin: 0 0 40px;
            padding: 19px 10px 13px 8px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0px 0px 40px 0px rgb(0 0 0 / 8%);
        }
</style>
    <div data-elementor-type="wp-page" data-elementor-id="36153" class="elementor elementor-36153">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-1579348 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="1579348" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-93385a3"
                     data-id="93385a3" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-c4e5f53 elementor-icon-list--layout-inline elementor-hidden-tablet elementor-hidden-mobile elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet_extra elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                             data-id="c4e5f53" data-element_type="widget" data-widget_type="icon-list.default">
                            <div class="elementor-widget-container">
                                <ul class="elementor-icon-list-items elementor-inline-items">
                                    <li class="elementor-icon-list-item elementor-inline-item">
                                <span class="elementor-icon-list-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="89" height="2" viewBox="0 0 89 2" fill="none">
                                    <path d="M88 1L1 1"
                                       stroke="#060815"
                                       stroke-width="1.5"
                                       stroke-linecap="round"></path></svg> </span>
                                        <span class="elementor-icon-list-text">Hakkımızda</span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-97de031 elementor-widget elementor-widget-heading"
                             data-id="97de031" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container"><h1
                                    class="elementor-heading-title elementor-size-default"><?php echo e($about->bannerTitle); ?></h1></div>
                        </div>
                        <div class="elementor-element elementor-element-13e169b elementor-widget elementor-widget-heading"
                             data-id="13e169b" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <span class="elementor-heading-title elementor-size-default"><?php echo e($about->bannerSubtitle); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4546be3 elementor-hidden-tablet elementor-hidden-mobile"
                     data-id="4546be3" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-c90f61e elementor-widget elementor-widget-image"
                             data-id="c90f61e" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <img width="1035" height="819"
                                     src="<?php echo e(asset($about->bannerImage)); ?>"
                                     class="attachment-full size-full" alt="about-banner" loading="lazy"/></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-e6620b1 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="e6620b1" data-element_type="section"
            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a0e36c2"
                     data-id="a0e36c2" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-797ebe7 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="797ebe7" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-bd4d1c3"
                                     data-id="bd4d1c3" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-c7fa795 elementor-invisible elementor-widget elementor-widget-heading"
                                             data-id="c7fa795" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default"><?php echo e($about->sec1Title); ?>

                                                </h2></div>
                                        </div>
                                        <div class="elementor-element elementor-element-b03c769 elementor-invisible elementor-widget elementor-widget-text-editor"
                                             data-id="b03c769" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($about->sec1SubTitle); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7cf66f7"
                                     data-id="7cf66f7" data-element_type="column">
                                    <div class="elementor-widget-wrap"></div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-6cf7688 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="6cf7688" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-9f1de1d img-box-hover-effect elementor-invisible"
                                     data-id="9f1de1d" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:100}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-947b0ac elementor-widget elementor-widget-image"
                                             data-id="947b0ac" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="/assets/wp-content/uploads/2022/06/demo-six-section-two-sun-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-057c5e1 elementor-widget elementor-widget-heading"
                                             data-id="057c5e1" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($about->sec1boxes->b1->title); ?>

                                                </h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-0a68893 elementor-widget elementor-widget-text-editor"
                                             data-id="0a68893" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($about->sec1boxes->b1->content); ?>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2e3f7ea img-box-hover-effect elementor-invisible"
                                     data-id="2e3f7ea" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:200}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-1b206e8 elementor-widget elementor-widget-image"
                                             data-id="1b206e8" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="/assets/wp-content/uploads/2022/06/demo-six-section-two-flower-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-353d180 elementor-widget elementor-widget-heading"
                                             data-id="353d180" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($about->sec1boxes->b2->title); ?></h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-ebe3c18 elementor-widget elementor-widget-text-editor"
                                             data-id="ebe3c18" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($about->sec1boxes->b2->content); ?>

                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-38764bc elementor-widget elementor-widget-radiant-custom-button"
                                             data-id="38764bc" data-element_type="widget"
                                             data-settings="{&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                                             data-widget_type="radiant-custom-button.default">

                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6851577 img-box-hover-effect elementor-invisible"
                                     data-id="6851577" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:300}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-e7667b6 elementor-widget elementor-widget-image"
                                             data-id="e7667b6" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="/assets/wp-content/uploads/2022/06/demo-six-section-two-stack-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-1c94f12 elementor-widget elementor-widget-heading"
                                             data-id="1c94f12" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($about->sec1boxes->b3->title); ?>

                                                </h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-61d8d13 elementor-widget elementor-widget-text-editor"
                                             data-id="61d8d13" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($about->sec1boxes->b3->content); ?>

                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-9a08d3c elementor-widget elementor-widget-radiant-custom-button"
                                             data-id="9a08d3c" data-element_type="widget"
                                             data-settings="{&quot;radiant_custom_btn_align&quot;:&quot;left&quot;}"
                                             data-widget_type="radiant-custom-button.default">

                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-211183b img-box-hover-effect elementor-invisible"
                                     data-id="211183b" data-element_type="column"
                                     data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:400}">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-77baf39 elementor-widget elementor-widget-image"
                                             data-id="77baf39" data-element_type="widget"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="156" height="156"
                                                     src="/assets/wp-content/uploads/2022/06/demo-six-section-two-cog-icon.png"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                        <div class="elementor-element elementor-element-8733daa elementor-widget elementor-widget-heading"
                                             data-id="8733daa" data-element_type="widget"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h5
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($about->sec1boxes->b4->title); ?>

                                                </h5></div>
                                        </div>
                                        <div class="elementor-element elementor-element-864b70d elementor-widget elementor-widget-text-editor"
                                             data-id="864b70d" data-element_type="widget"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($about->sec1boxes->b4->content); ?>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-dc24a44 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="dc24a44" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-16f2111"
                     data-id="16f2111" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-607c075 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="607c075" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-b8955f9"
                                     data-id="b8955f9" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-4940da2 elementor-invisible elementor-widget elementor-widget-heading"
                                             data-id="4940da2" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="heading.default">
                                            <div class="elementor-widget-container"><h2
                                                    class="elementor-heading-title elementor-size-default">
                                                    <?php echo e($about->sec2Title); ?>


                                                </h2>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-381c652 elementor-invisible elementor-widget elementor-widget-text-editor"
                                             data-id="381c652" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <?php echo e($about->sec2description); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-ada91ba elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="ada91ba" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5ac64bd"
                                     data-id="5ac64bd" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-38d2caf elementor-invisible elementor-widget elementor-widget-image"
                                             data-id="38d2caf" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:300}"
                                             data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img width="773" height="693"
                                                     src="<?php echo e(asset($about->sec2Image)); ?>"
                                                     class="attachment-full size-full" alt="" loading="lazy"/></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d325549"
                                     data-id="d325549" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-a466396 elementor-position-left moving-image-left-right elementor-vertical-align-top elementor-invisible elementor-widget elementor-widget-image-box"
                                             data-id="a466396" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100}"
                                             data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img src="/assets/wp-content/uploads/2022/06/demo-six-section-two-sun-icon.png"
                                                             class="attachment-full size-full"
                                                             alt=""
                                                             loading="lazy"/>
                                                    </figure>
                                                    <div class="elementor-image-box-content">
                                                        <h5 class="elementor-image-box-title"><?php echo e($about->sec2boxes->b1->title); ?>

                                                        </h5>
                                                        <p class="elementor-image-box-description">
                                                            <?php echo e($about->sec2boxes->b1->content); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-411e7a6 elementor-position-left moving-image-left-right elementor-vertical-align-top elementor-invisible elementor-widget elementor-widget-image-box"
                                             data-id="411e7a6" data-element_type="widget"
                                             data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                             data-widget_type="image-box.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-image-box-wrapper">
                                                    <figure class="elementor-image-box-img">
                                                        <img
                                                         src="/assets/wp-content/uploads/2022/06/demo-six-section-two-stack-icon.png"
                                                         class="attachment-full size-full"
                                                         alt=""
                                                         loading="lazy"/>
                                                    </figure>
                                                    <div class="elementor-image-box-content"><h5
                                                            class="elementor-image-box-title">
                                                            <?php echo e($about->sec2boxes->b2->title); ?>

                                                        </h5>
                                                        <p class="elementor-image-box-description">
                                                            <?php echo e($about->sec2boxes->b1->content); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-12f0128 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="12f0128" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-15a1efa"
                     data-id="15a1efa" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-widget-container"><h2 class="elementor-heading-title elementor-size-default">
                                Sponsorlarımız
                            </h2>
                        </div>
                        <div class="elementor-element elementor-element-7d1130f elementor-widget elementor-widget-radiant-client"
                             data-id="7d1130f" data-element_type="widget"
                             data-widget_type="radiant-client.default">
                            <div class="elementor-widget-container">
                                <div
                                        class="clients swiper-container allow-autoplay element-one swiper-container-initialized swiper-container-horizontal"
                                        data-mobile-items="1" data-tab-items="3" data-desktop-items="5"
                                        data-spacer="30" data-autoplay="true">
                                    <div class="swiper-wrapper" style="transform: translate3d(-2640px, 0px, 0px); transition-duration: 0ms;">
                                        <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="clients-item swiper-slide swiper-slide-prev"
                                                 data-swiper-slide-index="4"
                                                 style="width: 234px; margin-right: 30px;">
                                                <div class="holder">
                                                    <div class="table">
                                                        <div class="table-cell">
                                                            <div class="pic radiantthemes-retina">
                                                                <a href="<?php echo e($sponsor->link); ?>" target="_blank"><img width="119" height="56" src="<?php echo e(asset($sponsor->image)); ?>" class="client-cover-img wp-post-image" alt="" loading="lazy"></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                    <div class="swiper-pagination3"></div>
                                    <span class="swiper-notification" aria-live="assertive"
                                          aria-atomic="true"></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u0833636/public_html/project/resources/views/about.blade.php ENDPATH**/ ?>