<?php $__env->startSection('title','Portföy'); ?>
<?php $__env->startSection('links'); ?>
    <link data-optimized="2" rel="stylesheet"
          href="<?php echo e(asset('assets/wp-content/litespeed/css/253821830f6bb1284e7e35d55c9f0298b4b8.css?ver=d9e91')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="site-content">
        <div data-elementor-type="wp-page" data-elementor-id="5403" class="elementor elementor-5403">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-0990d27 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="0990d27" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div
                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a6937a"
                        data-id="5a6937a" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div
                                class="elementor-element elementor-element-312a8ac elementor-widget elementor-widget-radiant-custom-heading"
                                data-id="312a8ac" data-element_type="widget"
                                data-widget_type="radiant-custom-heading.default">
                                <div class="elementor-widget-container">
                                    <div class="rt-hover-heading ">
                                        <h1 class="rt-title-heading"><span class="head-txt">
<span class="rt-highlight-txt">Portföy<span id="underlinetxtone" class="rt-underline-txt"><svg width="100%" height="7"
                                                                                             viewBox="0 0 100% 7"
                                                                                             fill="#FFE5B4"
                                                                                             xmlns="http://www.w3.org/2000/svg">
<rect width="100%" height="7"></rect>
</svg></span></span></span><span class="highlight-after-text"> </span></h1>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="elementor-element elementor-element-abf58ab elementor-widget elementor-widget-text-editor"
                                data-id="abf58ab" data-element_type="widget" data-widget_type="text-editor.default">
                                <div class="elementor-widget-container"><p></p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-2b29c81 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                data-id="2b29c81" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div
                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0ed83a5"
                        data-id="0ed83a5" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-ce85bb0 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="ce85bb0" data-element_type="section">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div
                                        class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-89e23df"
                                        data-id="89e23df" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div
                                                class="elementor-element elementor-element-a393e0c elementor-widget elementor-widget-radiant-portfolio"
                                                data-id="a393e0c" data-element_type="widget"
                                                data-widget_type="radiant-portfolio.default">
                                                <div class="elementor-widget-container">
                                                    <div class="rt-portfolio-box rt-port-metro-element-three">
                                                        <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="rt-portfolio-box-item ">
                                                                <div class="holder">
                                                                    <div class="pic">
                                                                        <img
                                                                            src="<?php echo e(asset($row->image)); ?>"
                                                                            alt="metro" data-no-retina=""></div>
                                                                    <div class="overlay"></div>
                                                                    <div class="rt-portfolio-box-content">
                                                                        <div class="rt-portfolio-box-content-inner"><p
                                                                                class="portfolio-category"><?php echo e($row->description); ?></p><h5
                                                                                class="portfolio-title">
                                                                            </h5></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\girisim\resources\views/portfolio.blade.php ENDPATH**/ ?>