<form method="post" action="<?php echo e(route('promoter.project.store')); ?>"
      enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="author-desc-title d-flex">
        <h6 class="author">Girişim Başvurusu</h6>
    </div>
    <div class="row">
        <div class="mb-3 col-md-6 col-12">
            <label for="name" class="form-label">Project Adı</label>
            <input type="text" required name="name" class="form-control" id="name">
        </div>
        <div class="mb-3 col-md-6 col-12">
            <label for="website" class="form-label">Websitesi</label>
            <input type="text" required name="website" class="form-control" id="website">
        </div>
        <div class="mb-3">
            <label for="short_detail" class="form-label">Girşimin kısaca tanımı</label>
            <textarea type="text" required name="short_detail" class="form-control" id="short_detail" cols="60" rows="10"></textarea>
        </div>
        <div class="mb-3 col-12 col-md-6">
            <label for="purpose" class="form-label">Girişimin Yapım Amacı</label>
            <select name="purpose[]" required class="form-control" multiple id="purpose">
                <option value="Fikir">Fikir</option>
                <option value="Prototip">Prototip</option>
                <option value="Kullanılabilir">Kullanılabilir</option>
                <option value="Kullanılıyor">Kullanılıyor</option>
            </select>
        </div>

        <div class="mb-3 col-12 col-md-6">
            <label for="mission" class="form-label">Girişimdeki Göreviniz</label>
            <select name="mission[]" required class="form-control" multiple id="mission">
                <option value="Kurucu">Kurucu</option>
                <option value="Kurucu Ortağı">Kurucu Ortağı</option>
                <option value="Çalışan">Çalışan</option>
            </select>
        </div>

        <div class="mb-3 col-md-4 col-12">
            <label for="degree" class="form-label">Girişimdeki Ünvanınız</label>
            <input type="text" required class="form-control" name="degree" id="degree"/>
        </div>
        <div class="mb-3 col-12 col-md-4">
            <label for="start_month" class="form-label">Projeye Ne Zaman Başladınız (Ay)</label>
            <select name="start_month" class="form-control" id="start_month">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
        </div>
        <div class="mb-3 col-12 col-md-4">
            <label for="start_year" class="form-label">Projeye Ne Zaman Başladınız (Yıl)</label>
            <select name="start_year" class="form-control" id="start_year">
                <?php for($i=now()->year-20;$i<=now()->year;$i++): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group col-md-6 col-12">
            <label for="biography" class="form-label">KISA BİYOGRAFİ/ KENDİNİZİ TANITINIZ </label>
            <textarea type="text" required class="form-control" name="biography" id="biography" cols="60" rows="10" style="width: 100%;resize: none"></textarea>
        </div>
        <div class="form-group col-md-6 col-12">
            <label for="detail" class="form-label">NEDEN BAŞVURMAK İSTİYORSUNUZ ?</label>
            <textarea type="text" required class="form-control" name="cause" id="detail" cols="60" rows="10" style="width: 100%;resize: none"></textarea>
        </div>

        <div class="form-group col-12">
            <label for="detail" class="form-label">GİRİŞİM HAKKINDA ÖZET BİLGİ VERİNİZ </label>
            <textarea type="text" required class="form-control" name="detail" id="detail" cols="60" rows="10" style="width: 100%;resize: none"></textarea>
        </div>
    </div>
    <div class="w-100 text-right">
        <button class="edit-btn mt-3 text-right" type="submit">Girişimi Gönder
        </button>
    </div>
</form>
<?php /**PATH D:\xampp\htdocs\girisim\resources\views/promoter/project/create.blade.php ENDPATH**/ ?>