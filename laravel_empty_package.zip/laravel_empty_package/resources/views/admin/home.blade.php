@extends('admin.layouts.master')

@section('content')
    <div class="content-wrapper">
      <div class="container-fluid">
          <!-- Breadcrumb-->
          <div class="row pt-2 pb-2">
              <div class="col-sm-9">
                  <h4 class="page-title">Girişim Talebi Listesi</h4>
                  <ol class="breadcrumb">
                      <li class="breadcrumb-item active" aria-current="page">Girişim Talebi Listesi</li>
                  </ol>
              </div>
          </div>

          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-header d-flex justify-content-between">
                          <div>
                              <div><i class="fa fa-table"></i> Girişim Talebi Listesi</div>
                          </div>
                      </div>
                      <div class="card-body">
                          <div class="table-responsive">
                              <table id="datatable" class="table table-bordered">
                                  <thead>
                                  <tr>
                                      <th>Girişimci</th>
                                      <th>Proje Adı</th>
                                      <th>Başlangıç Tarihi</th>
                                      <th>Görev</th>
                                      <th>Durum</th>
                                      <th>İşlemler</th>
                                  </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>

                              </table>
                          </div>
                      </div>

                  </div>
              </div>
          </div><!-- End Row-->
      </div>
        <!-- End container-fluid-->

    </div>
@endsection


@section('page-scripts')
    <script>
        let DATA_URL = "{{route('admin.project-request.datatable')}}";
        let DATA_COLUMNS = [
            {data: 'promoter'},
            {data: 'name'},
            {data: 'start_date'},
            {data: 'mission'},
            {data: 'status'},
            {data: 'action'},
        ];
    </script>
    <script src="/backend/js/datatable-init.js"></script>
@endsection
