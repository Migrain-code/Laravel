@extends('admin.layouts.master')
@section('title','Slider Kayıt')
@section('content')
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Sponsor Güncelle</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Sponsor Bilgileri</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Sponsor Güncelle</li>
                    </ol>
                </div>
            </div>
            <!-- End Breadcrumb-->


            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title text-success">Slider Kayıt</div>
                            <form action="{{route('admin.sponsor.update', $sponsor->id)}}" method="post" enctype="multipart/form-data">
                                @method('PUT')
                                @csrf
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="title">Başlık</label>
                                        <input type="text" class="form-control form-control-rounded" value="{{$sponsor->name}}" name="name"
                                               required id="title" placeholder="Başlık">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="image">Logo</label>
                                        <input type="file" class="form-control form-control-rounded" name="image"
                                               id="image" placeholder="">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="button_text">Sponsor Linki</label>
                                        <input type="text" class="form-control form-control-rounded" value="{{$sponsor->link}}" name="link"
                                               required id="button_text" placeholder="Suponsorun Varsa site linki">
                                    </div>
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-success btn-round shadow-success px-5">Kaydet
                                    </button>
                                </div>


                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Row-->


        </div>
        <!-- End container-fluid-->
    </div>
@endsection
