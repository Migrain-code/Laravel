@extends('admin.layouts.master')
@section('title','Sayfa Listesi')
@section('content')
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">Sayfa Listesi</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">Sayfa Listesi</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div>
                                <div><i class="fa fa-table"></i> Sayfa Listesi</div>
                            </div>
                            <div>
                                <a href="{{route('admin.page.create')}}" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Sayfa Ekle</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Başlık</th>
                                        <th>İşlemler</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- End Row-->
        </div>
    </div>
@endsection

@section('page-scripts')
    <script>
        let DATA_URL = "{{route('admin.page.datatable')}}";
        let DATA_COLUMNS = [
            {data: 'title'},
            {data: 'action'},
        ];
    </script>
    <script src="/backend/js/datatable-init.js"></script>
@endsection
