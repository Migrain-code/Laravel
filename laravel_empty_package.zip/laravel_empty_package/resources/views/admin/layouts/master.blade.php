<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>@yield('title','hst.world | Admin')</title>
    <!--favicon-->
    <link rel="icon" href="{{asset(config('settings.favicon'))}}" type="icon">


    @include('admin.layouts.styles')
</head>

<body>

<!-- Start wrapper-->
<div id="wrapper">
    <!--Start sidebar-wrapper-->
@include('admin.layouts.menu')
<!--End sidebar-wrapper-->
@yield('content')
    <!--Start topbar header-->
@include('admin.layouts.header')
<!--End topbar header-->

    <div class="clearfix"></div>
</div>

@include('admin.layouts.footer')

@include('admin.layouts.scripts')

</body>

</html>
