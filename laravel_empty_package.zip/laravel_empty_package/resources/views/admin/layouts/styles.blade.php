<!-- simplebar CSS-->
<link href="/backend/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
<!-- Bootstrap core CSS-->
<link href="/backend/css/bootstrap.min.css" rel="stylesheet" />
<!-- animate CSS-->
<link href="/backend/css/animate.css" rel="stylesheet" type="text/css" />
<!-- Icons CSS-->
<link href="/backend/css/icons.css" rel="stylesheet" type="text/css" />
<!-- Sidebar CSS-->
<link href="/backend/css/sidebar-menu.css" rel="stylesheet" />
<!-- Custom Style-->
<link href="/backend/css/app-style.css" rel="stylesheet" />

<link href="/backend/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="/backend/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">

@yield('page-styles')
