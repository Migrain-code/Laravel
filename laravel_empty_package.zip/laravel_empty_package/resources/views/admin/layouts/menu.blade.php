<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
    <div class="brand-logo">
        <a href="{{route('admin.home')}}">
            <img src="{{asset(config('settings.favicon'))}}" class="logo-icon" alt="logo icon">
            <h5 class="logo-text">HST.WORLD</h5>
        </a>
    </div>
    <ul class="sidebar-menu do-nicescrol">
        <li class="sidebar-header">Menü</li>

        <li @if(request()->routeIs('admin.home')) class="active" @endif><a href="{{route('admin.home')}}"><i
                        class="zmdi zmdi-star-outline"></i> Anasayfa</a></li>

        <li @if(request()->routeIs('admin.promoter.*')) class="active" @endif>
            <a href="{{route('admin.promoter.index')}}" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Girişimci İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="{{route('admin.promoter.index')}}"><i class="zmdi zmdi-star-outline"></i> Girişimci Listesi</a>
                </li>
                <li><a href="{{route('admin.promoter.create')}}"><i class="zmdi zmdi-star-outline"></i> Girişimci
                        Ekle</a></li>
            </ul>
        </li>

        <li @if(request()->routeIs('admin.investor.*')) class="active" @endif>
            <a href="{{route('admin.investor.index')}}" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Yatırımcı İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="{{route('admin.investor.index')}}"><i class="zmdi zmdi-star-outline"></i> Yatırımcı Listesi</a>
                </li>
                <li><a href="{{route('admin.investor.create')}}"><i class="zmdi zmdi-star-outline"></i> Yatırımcı
                        Ekle</a></li>
            </ul>
        </li>

        <li @if(request()->routeIs('admin.project-request.*')) class="active" @endif>
            <a href="{{route('admin.project-request.index')}}" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Girişim İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="{{route('admin.project-request.index')}}"><i class="zmdi zmdi-star-outline"></i> Girişim
                        Talepleri</a></li>
                <li><a href="{{route('admin.project.index')}}"><i class="zmdi zmdi-star-outline"></i> Girişim
                        Listesi</a></li>
                <li><a href="{{route('admin.interest.index')}}"><i class="zmdi zmdi-star-outline"></i> İlgilenenler</a></li>
            </ul>
        </li>
        <li @if(request()->routeIs('admin.slider.*')) class="active" @endif>
            <a href="{{route('admin.slider.index')}}" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Site İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li @if(request()->routeIs('admin.slider.*')) class="active" @endif>

                    <a href="{{route('admin.slider.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Slider İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.slider.index')}}"><i class="zmdi zmdi-star-outline"></i> Slider
                                Listesi</a></li>
                        <li><a href="{{route('admin.slider.create')}}"><i class="zmdi zmdi-star-outline"></i> Slider
                                Ekle</a></li>
                    </ul>
                </li>
                <li @if(request()->routeIs('admin.image.*')) class="active" @endif>

                    <a href="{{route('admin.image.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Görsel İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.image.index')}}"><i class="zmdi zmdi-star-outline"></i> Görsel
                                Listesi</a></li>
                    </ul>
                </li>
                <li @if(request()->routeIs('admin.editContact.*')) class="active" @endif>

                    <a href="{{route('admin.editContact.edit', 1)}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>İletişim Sayfası</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.editContact.edit', 1)}}"><i class="zmdi zmdi-star-outline"></i> Düzenle</a></li>
                    </ul>
                </li>
                <li @if(request()->routeIs('admin.about.*')) class="active" @endif>
                    <a href="{{route('admin.about.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Hakkımızda İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li>
                            <a href="{{route('admin.about.index')}}"><i class="zmdi zmdi-star-outline"></i> Düzenle </a>
                        </li>

                    </ul>
                </li>
                <li @if(request()->routeIs('admin.main.*')) class="active" @endif>
                    <a href="{{route('admin.main.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Anasayfa İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li>
                            <a href="{{route('admin.main.index')}}"><i class="zmdi zmdi-star-outline"></i> Düzenle </a>
                        </li>

                    </ul>
                </li>
                <li @if(request()->routeIs('admin.blog.*')) class="active" @endif>
                    <a href="{{route('admin.blog.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Haber İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.blog.index')}}"><i class="zmdi zmdi-star-outline"></i> Etkinlik Listesi</a>
                        </li>
                        <li><a href="{{route('admin.blog.create')}}"><i class="zmdi zmdi-star-outline"></i> Etkinlik
                                Ekle</a></li>
                    </ul>
                </li>
                <li @if(request()->routeIs('admin.sponsor.*')) class="active" @endif>
                    <a href="{{route('admin.sponsor.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Sponsor İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.sponsor.index')}}"><i class="zmdi zmdi-star-outline"></i> Sponsor Listesi </a></li>
                        <li><a href="{{route('admin.sponsor.create')}}"><i class="zmdi zmdi-star-outline"></i> Sponsor Ekle</a></li>
                    </ul>
                </li>
                <li @if(request()->routeIs('admin.page.*')) class="active" @endif>
                    <a href="{{route('admin.page.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Sayfa İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.page.index')}}"><i class="zmdi zmdi-star-outline"></i> Sayfa Listesi</a>
                        </li>
                        <li><a href="{{route('admin.page.create')}}"><i class="zmdi zmdi-star-outline"></i> Sayfa
                                Ekle</a></li>
                    </ul>
                </li>

                <li @if(request()->routeIs('admin.faq.*')) class="active" @endif>
                    <a href="{{route('admin.faq.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Bilgi Bankası</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.faq.index')}}"><i class="zmdi zmdi-star-outline"></i> Bilgi Bankası Listesi</a>
                        </li>
                        <li><a href="{{route('admin.faq.create')}}"><i class="zmdi zmdi-star-outline"></i> Bilgi Bankası
                                Ekle</a></li>
                    </ul>
                </li>
                <li @if(request()->routeIs('admin.committee.*')) class="active" @endif>
                    <a href="{{route('admin.committee.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Yatırımcı Komitesi</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.committee.index')}}"><i class="zmdi zmdi-star-outline"></i> Yatırımcı Komitesi Listesi</a>
                        </li>
                        <li><a href="{{route('admin.committee.create')}}"><i class="zmdi zmdi-star-outline"></i> Yatırımcı Komitesi
                                Ekle</a></li>
                    </ul>
                </li>

                <li @if(request()->routeIs('admin.portfolio.*')) class="active" @endif>
                    <a href="{{route('admin.portfolio.index')}}" class="waves-effect">
                        <i class="zmdi zmdi-view-dashboard"></i> <span>Portföy İşlemleri</span> <i
                                class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="sidebar-submenu">
                        <li><a href="{{route('admin.portfolio.index')}}"><i class="zmdi zmdi-star-outline"></i> Portföy
                                Listesi</a></li>
                        <li><a href="{{route('admin.portfolio.create')}}"><i class="zmdi zmdi-star-outline"></i> Portföy
                                Ekle</a></li>
                    </ul>
                </li>
            </ul>
        </li>


        <li @if(request()->routeIs('admin.user.*')) class="active" @endif>
            <a href="{{route('admin.user.index')}}" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Kullanıcı İşlemleri</span> <i
                        class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="{{route('admin.user.index')}}"><i class="zmdi zmdi-star-outline"></i> Kullanıcı Listesi</a>
                </li>
                <li><a href="{{route('admin.user.create')}}"><i class="zmdi zmdi-star-outline"></i> Kullanıcı Ekle</a>
                </li>
            </ul>
        </li>

        <li @if(request()->routeIs('admin.email')) class="active" @endif><a href="{{route('admin.email.index')}}"><i
                        class="zmdi zmdi-view-dashboard"></i> E-Posta İşlemleri</a></li>
         <li @if(request()->routeIs('admin.email')) class="active" @endif><a href="{{route('admin.email.index')}}"><i
        class="zmdi zmdi-view-dashboard"></i> Mesaj İşlemleri</a></li>

        <!--<li @if(request()->routeIs('admin.contact.index'))
            class="active"
        @endif><a href="{{route('admin.contact.index')}}"><i
                    class="zmdi zmdi-view-dashboard"></i> İletişim Mesajları</a></li>-->

        <li @if(request()->routeIs('admin.settings')) class="active" @endif><a href="{{route('admin.settings')}}"><i
                        class="zmdi zmdi-view-dashboard"></i> Ayarlar</a></li>

        <li><a href="{{route('admin.logout')}}"><i class="zmdi zmdi-star-outline"></i>Çıkış Yap</a></li>
    </ul>

</div>
