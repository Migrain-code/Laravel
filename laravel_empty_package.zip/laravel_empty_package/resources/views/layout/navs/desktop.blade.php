    <header class="rt-header logo-left  style3 mobile-header-style1" style="background-color: #f1f6ff">
    <div class="rt-header-holder mobile-logo-column">
        <div
            class="menu-icon rt-mobile-hamburger rt-column hidden-lg visible-md visible-sm visible-xs">
            <div class="rt-mobile-toggle-holder">
                <div class="rt-mobile-toggle">
                    <span></span><span></span><span></span></div>
            </div>
        </div>
        <div class="logo-holder">
            <div class="logo radiantthemes-retina">
                <a href="{{route('home')}}">
                    <span class="logo-default test-retina-three">
                        <img alt="logo" src="{{asset(config('settings.logo'))}}" width="161" height="30">
                    </span>
                </a>
            </div>
        </div>
        <div class="rt-navbar-menu menu-center">
            <nav
                class="apr-nav-menu--main apr-nav-menu--layout-horizontal hover-underline e--pointer-none">
                <ul id="menu-main-menu-1" class="mega-menu">
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children rt-dropdown">
                        <a href="{{route('home')}}" data-description="">Anasayfa<span
                                class="arrow"></span></a>
                    </li>
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5342 rt-dropdown">
                        <a href="{{route('about')}}" data-description="">
                            Hakkımızda
                            <span class="arrow">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                  width="16" height="16"
                                  viewBox="0 0 24 24" fill="none"
                                  stroke="currentColor"
                                  stroke-width="1.5"
                                  stroke-linecap="round"
                                  stroke-linejoin="round"
                                  class="feather feather-chevron-down">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </span>
                        </a>
                        <ul class="sub-menu  menu-odd  menu-depth-1">
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="{{route('committee.index')}}" data-description="">
                                    Yatırımcı Komitesi
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="1.5" stroke-linecap="round"
                                             stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="{{route('page.promoter')}}" data-description="">
                                    Girişimci
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                           viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                           stroke-width="1.5" stroke-linecap="round"
                                           stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="{{route('page.investor')}}" data-description="">
                                    Yatırımcı
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                           viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                           stroke-width="1.5" stroke-linecap="round"
                                           stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="{{route('contact')}}" data-description="">
                                    İletişim
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="1.5" stroke-linecap="round"
                                             stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>
<!--                            <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-36629">
                                <a href="{{route('portfolio')}}" data-description="">
                                    Porföy
                                    <span class="arrow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="1.5" stroke-linecap="round"
                                             stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </span>
                                </a>
                            </li>-->

                        </ul>
                    </li>

                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="{{route('sss')}}" data-description="">Bilgi Bankası<span
                                class="arrow"></span></a>
                    </li>
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="{{route('blog.index')}}" data-description="">Etkinlikler<span
                                class="arrow"></span></a>
                    </li>
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="{{route('contact')}}" data-description="">İletişim<span
                                class="arrow"></span></a>
                    </li>
                    <!--@if(auth('investor')->check())
                    <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-25 rt-dropdown">
                        <a href="{{route('project.index')}}" data-description="">Girişimler<span
                                    class="arrow"></span></a>
                    </li>
                    @endif-->
                </ul>
            </nav>
        </div>
        <div class="rt-search-cart-holder"></div>
        <div class="rt-right-menu-holder">
            @if(auth('promoter')->check())
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button"><a
                            class="radiantthemes-menu-custom-button-main"
                            style="padding:10px;background-color: #0d66c2;color:white"
                            href="{{route('promoter.home')}}"><span>Panelim</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button "><a onclick="$('#logout-form').submit()"
                                                                      class="radiantthemes-menu-custom-button-main"
                                                                      style="padding: 10px;border: 1px solid #0d66c2"
                                                                      href="javascript:void(0)"><span>Çıkış Yap</span></a>
                    </div>
                </div>
                <form id="logout-form" method="post" action="{{route('promoter.logout')}}">@csrf</form>
            @elseif(auth('investor')->check())
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button"><a
                                class="radiantthemes-menu-custom-button-main"
                                style="padding:10px;background-color: #0d66c2;color:white"
                                href="{{route('investor.home')}}"><span>Panelim</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button "><a onclick="$('#logout-form').submit()"
                                                                      class="radiantthemes-menu-custom-button-main"
                                                                      style="padding: 10px;border: 1px solid #0d66c2"
                                                                      href="javascript:void(0)"><span>Çıkış Yap</span></a>
                    </div>
                </div>
                <form id="logout-form" method="post" action="{{route('investor.logout')}}">@csrf</form>
            @else
            <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button"><a
                            class="radiantthemes-menu-custom-button-main"
                            style="padding:10px;background-color: #0d66c2;color:white"
                            href="{{route('investor.login')}}"><span>Yatırımcı</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button"><a
                            class="radiantthemes-menu-custom-button-main"
                            style="padding:10px;background-color: #0d66c2;color:white"
                            href="{{route('promoter.login')}}"><span>Girişimci</span></a>
                    </div>
                </div>
                <div class="rt-desktop-hamburger header-elem-desk-hamburger  ">
                    <div class="radiantthemes-menu-custom-button "><a
                            class="radiantthemes-menu-custom-button-main"
                            style="padding: 10px;border: 1px solid #0d66c2"
                            href="{{route('register')}}"><span>Kayıt Ol</span></a>
                    </div>
                </div>
            @endif
        </div>
    </div>
</header>
