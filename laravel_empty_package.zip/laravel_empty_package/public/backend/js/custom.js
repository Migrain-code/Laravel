$('.summernote').summernote({
    'height': 350,
    callbacks: {
        onImageUpload: function(image) {
            uploadImage(image[0]);
        }
    }
})

function sendFile(file, editor, welEditable) {
    data = new FormData();
    data.append("file", file);
    data.append("_token", csrf_token);
    $.ajax({
      data: data,
      type: "POST",
      url: "/admin/upload",
      cache: false,
      contentType: false,
      processData: false,
      success: function(url) {
        editor.insertImage(welEditable, url);
      }
    });
  }
  
  function uploadImage(image) {
    var data = new FormData();
    data.append("file", image);
    data.append("_token", csrf_token);
    $.ajax({
        url: "/admin/upload",
        cache: false,
        contentType: false,
        processData: false,
        data: data,
        type: "post",
        success: function(url) {
            var image = $('<img>').attr('src', url);
            $('.summernote').summernote("insertNode", image[0]);
        },
        error: function(data) {
            console.log(data);
        }
    });
}

function areYouSure(url, text = "Bu veriyi silmek istediğinize emin misiniz?") {
    Swal.fire({
        title: 'İşlemi Onaylayın',
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Evet',
        cancelButtonText: 'İptal',
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: "POST",
                data: {
                    "_token": csrf_token,
                    '_method': 'delete'
                },
                success: function (res) {
                    Swal.fire({
                        icon: res.status,
                        text: res.text ? res.text : res.message,
                    })
                    if (res.status === 'success') {
                        table.ajax.reload(null, false);
                    }
                }
            });
        }
    })
}

$(document).on('click', '.verifyAction', function (e) {
    e.preventDefault();
    let url = $(this).attr('href');
    let text = $(this).attr('alert-text');
    areYouSure(url, text);
})
