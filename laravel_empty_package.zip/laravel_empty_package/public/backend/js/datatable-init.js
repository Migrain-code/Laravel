const table = $('#datatable').DataTable(
    {
        "language": {
            "url": "https://cdn.datatables.net/plug-ins/1.11.2/i18n/tr.json"
        },
        info:0,
        order: [],
        serverSide: true,
        columns: DATA_COLUMNS,
        columnDefs: [
            {
                targets: -1,
                className: "text-end"
            }
        ],
        ajax: {
            url: DATA_URL
        },
        buttons: ['copy', 'excel', 'pdf', 'print', 'colvis'],
        lengthChange: false,
    }
);

$('#datatable-search').on("keyup", (function () {
    table.search($(this).val()).draw()
}))

$(document).keydown(function (e) {
    if (e.keyCode == '82') {
        table.ajax.reload(null, false);
    }
})

setTimeout(function (){
    table.buttons().container().appendTo('#datatable_wrapper .col-md-6:eq(0)');
},2000)

