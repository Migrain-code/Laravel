$(function () {
    "use strict";


// chart 1

    let incomeExpenseChart = document.getElementById("dashboard-chart-1").getContext('2d');

    let incomeExpenseChartData = new Chart(incomeExpenseChart, {
        type: 'bar',
        data: {
            labels: ['Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi','Pazar'],
            datasets: [
                {
                    label: 'Gelir',
                    data: weeklyIncome,
                    borderColor: '#11cdef',
                    backgroundColor: '#11cdef',
                    hoverBackgroundColor: '#11cdef',
                    pointRadius: 0,
                    fill: false,
                    borderWidth: 1
                },
                {
                    label: 'Gider',
                    data: weeklyExpense,
                    borderColor: '#e8e8e8',
                    backgroundColor: '#e8e8e8',
                    hoverBackgroundColor: '#e8e8e8',
                    pointRadius: 0,
                    fill: false,
                    borderWidth: 1
                }]
        },
        options: {
            legend: {
                position: 'bottom',
                display: true,
                labels: {
                    boxWidth: 12
                }
            },
            scales: {
                xAxes: [{
                    stacked: true,
                    barPercentage: .5
                }],
                yAxes: [{
                    stacked: true
                }]
            },
            tooltips: {
                displayColors: false,
            }
        }
    });


// chart 2

    var ctx = document.getElementById("dashboard-chart-2").getContext('2d');

    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: stockItems,
            datasets: [{
                backgroundColor: stockChartColors,
                hoverBackgroundColor: stockChartColors,
                data: stockRentCounts,
                borderWidth: stockBorderWidths
            }]
        },
        options: {
            cutoutPercentage: 25,
            legend: {
                position: 'right',
                display: true,
                labels: {
                    boxWidth: 12
                }
            },
            tooltips: {
                displayColors: false,
            }
        }
    });

});
