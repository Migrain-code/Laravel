<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\Page;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class PageController extends Controller
{
    public function index()
    {
        return view('admin.page.index');
    }

    public function create()
    {
        return view('admin.page.create');
    }

    public function store(Request $request)
    {
        $page = new Page();
        $page->title = $request->title;
        $page->slug = str($page->title)->slug();
        $page->detail = $request->detail;
        $page->save();

        return to_route('admin.page.index')->with('status', 'Sayfa başarıyla eklendi');
    }

    public function edit(Page $page)
    {
        return view('admin.page.edit', compact('page'));
    }

    public function update(Request $request, Page $page)
    {
        $page->title = $request->title;
        $page->slug = str($page->title)->slug();
        $page->detail = $request->detail;
        $page->save();

        return to_route('admin.page.index')->with('status', 'Sayfa başarıyla güncellendi');
    }

    public function destroy(Page $page)
    {
        $page->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Sayfa başarıyla silindi.'
        ]);
    }

    public function datatable()
    {
        $query = Page::query();

        return DataTables::of($query)
            ->addColumn('action', function ($q) {
                $html = '';
                $html .= html()->a(route('admin.page.edit', $q->id), html()->i()->class('fa fa-edit'))->class('btn btn-primary mr-2');
                $html .= html()->a(route('admin.page.destroy', $q->id), html()->i()->class('fa fa-trash'))->class('btn btn-danger verifyAction mr-2');

                return $html;
            })
            ->rawColumns(['action'])
            ->make(true);

    }
}
