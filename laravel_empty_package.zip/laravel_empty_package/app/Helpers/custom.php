<?php

function storage($path): string
{
    return asset('storage/' . $path);
}
