<?php

namespace App\Providers;

use App\Core\CustomResourceRegistrar;
use App\Models\Page;
use App\Models\Setting;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        if ($this->app->isLocal()) {
            $this->app->register(\Barryvdh\LaravelIdeHelper\IdeHelperServiceProvider::class);
        }
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);
        $registrar = new CustomResourceRegistrar($this->app['router']);

        $this->app->bind('Illuminate\Routing\ResourceRegistrar', function () use ($registrar) {
            return $registrar;
        });

        $settings = [];

       /* foreach (Setting::all() as $item) {
            $settings[$item->name] = $item->value;
        }
        \Config::set('settings', $settings);
        $globalData = [
            'pages' => Page::latest()->get()
        ];
        \View::share('globalData', $globalData);

        Paginator::useBootstrapFour();*/
    }
}
